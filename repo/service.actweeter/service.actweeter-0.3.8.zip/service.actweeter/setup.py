"""Kodi-native onboarding and on-demand service diagnostics.

All credentials remain in the official add-on settings screens. This UI only
checks whether required fields are present and displays non-sensitive status.
"""

from __future__ import annotations

import base64
import json
import os
import re
import sys
from urllib.parse import parse_qs, urlparse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
LIB_PATH = os.path.join(ADDON_PATH, "resources", "lib")
if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)

from first_run import (
    INTRO_OPTIONS,
    OPTIONAL_ADDON_SOURCES,
    OPTIONAL_ADDONS,
    REQUIRED_ADDON_IDS,
    REQUIRED_EXTERNAL_ADDON_MINIMUMS,
    REQUIRED_REPAIR_SOURCES,
    addon_version_satisfies,
    claim_process_session,
    completion_blockers,
    has_xtream_configuration,
    home_diagnostic_snapshot,
    intro_mode_for_selection,
    load_state,
    mark_completed,
    mark_component_offer_seen,
    mark_prompted,
    mark_setup_check,
    mark_started,
    mark_step,
    optional_addon_action,
    save_state,
    service_rows,
    should_offer_component_completion,
    should_offer_first_run,
    tvos_xstream_dependency_status,
)
from xstream_setup import (
    SetupError,
    parse_xtream_input,
    prepare_https_endpoint,
    save_native_profile,
    validate_xtream_credentials,
)

SETTINGS_ADDONS = {
    "xstream": "plugin.video.xstream-pro",
    "pvr": "pvr.iptvsimple",
    "slyguy": "slyguy.trailers",
    "youtube": "plugin.video.youtube",
    "trakt": "script.trakt",
}
METADATA_ADDONS = ("plugin.video.tmdb.bingie.helper",
                   "plugin.video.themoviedb.helper")


def _state_path():
    root = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    xbmcvfs.mkdirs(root)
    return os.path.join(root, "setup_state.json")


def _read_state():
    return load_state(_state_path())


def _write_state(state):
    save_state(_state_path(), state)


def _intro_session_path():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    xbmcvfs.mkdirs(profile)
    return os.path.join(profile, "intro_session.json")


def _first_run_session_path():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    xbmcvfs.mkdirs(profile)
    return os.path.join(profile, "first_run_session.json")


def _addon_installed(addon_id):
    return bool(xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id))


def _addon_enabled(addon_id):
    return bool(xbmc.getCondVisibility("System.AddonIsEnabled(%s)" % addon_id))


def _addon_ready(addon_id):
    return _addon_installed(addon_id) and _addon_enabled(addon_id)


def _set_xstream_profile_url(addon, setting_id, new_url):
    """Update only XStream's verified URL setting and confirm the write."""
    previous = addon.getSetting(setting_id)
    try:
        addon.setSetting(setting_id, new_url)
        if addon.getSetting(setting_id) == new_url:
            return True
    except Exception as exc:  # noqa: BLE001 - settings API errors must not expose values.
        xbmc.log("[AcTweeteR] HTTPS_MIGRATION status=write_error type=%s" %
                 type(exc).__name__, xbmc.LOGWARNING)
    try:
        addon.setSetting(setting_id, previous)
        restored = addon.getSetting(setting_id) == previous
    except Exception:  # noqa: BLE001 - report only a safe failure state.
        restored = False
    xbmc.log("[AcTweeteR] HTTPS_MIGRATION status=unconfirmed rollback=%s" %
             ("ok" if restored else "failed"), xbmc.LOGWARNING)
    return False


def _set_addon_enabled(addon_id, enabled=True):
    """Toggle an installed add-on through Kodi's JSON-RPC API and verify it."""
    response = json.loads(xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": "Addons.SetAddonEnabled",
        "params": {"addonid": addon_id, "enabled": bool(enabled)},
    })))
    return "error" not in response and _addon_enabled(addon_id) is bool(enabled)


def _addon_requirement_ready(addon_id):
    if not _addon_ready(addon_id):
        return False
    minimum = REQUIRED_EXTERNAL_ADDON_MINIMUMS.get(addon_id)
    return minimum is None or addon_version_satisfies(_addon_version(addon_id), minimum)


def _wait_for_addon_ready(addon_id, timeout=120, *, required=False):
    """Yield to Kodi while waiting for its asynchronous package transaction."""
    import time

    monitor = xbmc.Monitor()
    stop_at = time.monotonic() + timeout
    while time.monotonic() < stop_at:
        if (_addon_requirement_ready(addon_id) if required
                else _addon_ready(addon_id)):
            return True
        if monitor.waitForAbort(0.5):
            return False
    return (_addon_requirement_ready(addon_id) if required
            else _addon_ready(addon_id))


def _mandatory_addons_ready():
    if not all(_addon_ready(addon_id) for addon_id in REQUIRED_ADDON_IDS):
        return False
    for addon_id, minimum in REQUIRED_EXTERNAL_ADDON_MINIMUMS.items():
        if not _addon_ready(addon_id) or not addon_version_satisfies(
                _addon_version(addon_id), minimum):
            return False
    # SlyGuy is the primary trailer provider. YouTube is also installed and
    # enabled for the skin's explicit search/fallback actions; account/API
    # authorization is not implied by add-on readiness.
    return (_addon_ready(OPTIONAL_ADDONS["slyguy"])
            and _addon_ready(OPTIONAL_ADDONS["youtube"]))


def _addon_version(addon_id):
    """Return only Kodi's addon version metadata; never inspect settings."""
    try:
        return xbmcaddon.Addon(addon_id).getAddonInfo("version") or ""
    except Exception:
        return ""


def _tvos_xstream_dependency_status():
    return tvos_xstream_dependency_status(
        _addon_installed("pvr.iptvsimple"),
        _addon_enabled("pvr.iptvsimple"),
        _addon_version("pvr.iptvsimple"),
    )


def _explain_tvos_xstream_dependency(dialog, *, offer_enable=True):
    """Gate XStream until this Kodi app actually exposes a compatible PVR."""
    status = _tvos_xstream_dependency_status()
    if status == "READY":
        return True
    if status == "PVR_DISABLED" and offer_enable:
        result = _request_native_addon_install(
            dialog, "pvr.iptvsimple", "complemento ya integrado en Kodi tvOS",
            required=True)
        if result == "INSTALLED" and _tvos_xstream_dependency_status() == "READY":
            return True
        status = _tvos_xstream_dependency_status()
    messages = {
        "PVR_MISSING": (
            "Esta instalación de Kodi para Apple TV no incluye IPTV Simple. "
            "XStream Pro declara ese complemento como dependencia obligatoria. "
            "Usa una compilación de Kodi tvOS que lo integre y vuelve a intentarlo; "
            "AcTweeteR no descargará ni instalará binarios por su cuenta."),
        "PVR_DISABLED": (
            "IPTV Simple sigue deshabilitado. Habilítalo desde Complementos → "
            "Mis complementos → Clientes PVR y vuelve a intentarlo."),
        "PVR_VERSION_INSUFFICIENT": (
            "La versión instalada de IPTV Simple es anterior a 21.4.0. "
            "XStream Pro no se instalará hasta que Kodi incluya una versión "
            "compatible."),
        "PVR_VERSION_UNKNOWN": (
            "Kodi no permite confirmar la versión de IPTV Simple. Para evitar "
            "una instalación incompleta, XStream Pro queda pendiente."),
    }
    dialog.ok("Requisito de XStream Pro", messages.get(status, messages["PVR_VERSION_UNKNOWN"]))
    return False


def _ensure_repository_enabled(dialog, repository_id):
    """Enable only an already-installed repository, after explicit consent."""
    if not repository_id or _addon_enabled(repository_id):
        return bool(repository_id and _addon_enabled(repository_id))
    if not _addon_installed(repository_id):
        return False
    if not dialog.yesno(
            "Activar repositorio",
            "%s ya está instalado, pero deshabilitado. ¿Quieres habilitarlo para que Kodi pueda resolver el complemento solicitado? No se instalará ningún repositorio nuevo." % repository_id,
            "Ahora no", "Habilitar"):
        return False
    try:
        if not _set_addon_enabled(repository_id, True):
            raise RuntimeError("Kodi did not confirm repository enablement")
    except Exception as exc:
        xbmc.log("[AcTweeteR] REPOSITORY_ENABLE status=error type=%s" %
                 type(exc).__name__, xbmc.LOGWARNING)
    return _addon_enabled(repository_id)


def _is_tvos():
    return bool(xbmc.getCondVisibility("System.Platform.TVOS"))


def _request_native_addon_install(dialog, addon_id, source_id, *, required=False,
                                  consent_granted=False):
    """Use Kodi's native resolver and wait for a verified installed state."""
    heading = "Componente obligatorio de AcTweeteR" if required else "Instalar integración opcional"
    role = "dependencia de la skin" if required else "integración adicional"
    if not consent_granted and not dialog.yesno(
            heading,
            "¿Pedir a Kodi que instale %s (%s) desde %s? Kodi gestiona las dependencias y confirmaciones; AcTweeteR no configura credenciales." %
            (addon_id, role, source_id),
            "Ahora no", "Instalar"):
        return "DECLINED"

    attempts = 0
    while attempts < 2:
        try:
            # Kodi's native installer handles dependency resolution, licenses,
            # platform packages, and its own confirmation UI.
            minimum = REQUIRED_EXTERNAL_ADDON_MINIMUMS.get(addon_id)
            update_needed = (required and _addon_installed(addon_id)
                             and minimum is not None
                             and not addon_version_satisfies(_addon_version(addon_id), minimum))
            if update_needed or not _addon_installed(addon_id):
                xbmc.executebuiltin("InstallAddon(%s)" % addon_id, True)
            elif not _addon_enabled(addon_id):
                if not _set_addon_enabled(addon_id, True):
                    raise RuntimeError("Kodi did not confirm add-on enablement")
        except Exception as exc:
            xbmc.log("[AcTweeteR] ADDON_INSTALL status=error addon=%s type=%s" %
                     (addon_id, type(exc).__name__), xbmc.LOGWARNING)
        # Kodi's package transaction and dependency prompts are asynchronous
        # relative to the Python built-in call. Never issue a second install
        # while the first transaction may still be running.
        if _wait_for_addon_ready(addon_id, required=required):
            return "INSTALLED"
        if attempts >= 1:
            return "FAILED"
        if not dialog.yesno(
                "Instalación no confirmada",
                "Kodi no confirma que %s esté instalado y habilitado. Comprueba la conexión, la compatibilidad y el repositorio; ¿quieres volver a intentarlo ahora?" % addon_id,
                "Dejar pendiente", "Reintentar"):
            return "FAILED"
        attempts += 1
    return "FAILED"
def _installed_addons():
    installed = {key: _addon_ready(addon_id)
                 for key, addon_id in OPTIONAL_ADDONS.items() if key != "metadata"}
    installed["required"] = _mandatory_addons_ready()
    installed["metadata"] = any(_addon_installed(addon_id)
                                for addon_id in METADATA_ADDONS)
    return installed


def _jsonrpc(method, params=None):
    """Return Kodi JSON-RPC result or None without leaking response data."""
    try:
        payload = {"jsonrpc": "2.0", "id": 1, "method": method}
        if params is not None:
            payload["params"] = params
        response = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
        if "error" in response:
            return None
        return response.get("result")
    except Exception:  # Kodi JSON-RPC errors are non-fatal and never expose payloads.
        return None


def _xstream_catalog_status():
    """Count provider category entries through Kodi's own plugin directory API."""
    counts = {}
    for kind, mode in (("movies", "movies_menu"), ("series", "series_menu")):
        result = _jsonrpc("Files.GetDirectory", {
            "directory": "plugin://plugin.video.xstream-pro/?mode=%s" % mode,
            "media": "files",
        })
        files = result.get("files") if isinstance(result, dict) else None
        counts[kind] = len(files) if isinstance(files, list) else None
    return counts


def _pvr_status():
    """Verify Kodi PVR state, channel groups/channels, and whether any EPG exists."""
    properties = _jsonrpc("PVR.GetProperties", {
        "properties": ["available", "scanning"],
    })
    if not isinstance(properties, dict):
        return {"error": True, "available": False, "scanning": False,
                "groups": 0, "channels": 0, "broadcasts": 0}

    groups_result = _jsonrpc("PVR.GetChannelGroups", {"channeltype": "tv"})
    groups = groups_result.get("channelgroups", []) if isinstance(groups_result, dict) else []
    channel_count = 0
    broadcast_count = 0
    # Kodi may return a custom/empty group first. Probe only a bounded prefix,
    # stop as soon as one group contains channels, and keep all IDs transient.
    if isinstance(groups, list):
        for group in groups[:10]:
            group_id = group.get("channelgroupid") if isinstance(group, dict) else None
            if group_id is None:
                continue
            channels_result = _jsonrpc("PVR.GetChannels", {
                "channelgroupid": group_id,
                "limits": {"start": 0, "end": 20000},
            })
            channels = (channels_result.get("channels", [])
                        if isinstance(channels_result, dict) else [])
            if isinstance(channels, list) and channels:
                channel_count = len(channels)
                break

    if channel_count:
        # One small sample suffices to tell whether the guide currently has data;
        # no channel names, IDs, programme titles, or paths are retained.
        channels_result = _jsonrpc("PVR.GetChannels", {
            "channelgroupid": group_id,
            "limits": {"start": 0, "end": 5},
        })
        channels = channels_result.get("channels", []) if isinstance(channels_result, dict) else []
        if isinstance(channels, list):
            for channel in channels[:5]:
                channel_id = channel.get("channelid") if isinstance(channel, dict) else None
                if channel_id is None:
                    continue
                broadcasts_result = _jsonrpc("PVR.GetBroadcasts", {
                    "channelid": channel_id,
                    "limits": {"start": 0, "end": 1},
                })
                broadcasts = (broadcasts_result.get("broadcasts", [])
                              if isinstance(broadcasts_result, dict) else [])
                if isinstance(broadcasts, list):
                    broadcast_count += len(broadcasts)
                if broadcast_count:
                    break
    return {
        "error": False,
        "available": bool(properties.get("available")),
        "scanning": bool(properties.get("scanning")),
        "groups": len(groups) if isinstance(groups, list) else 0,
        "channels": channel_count,
        "broadcasts": broadcast_count,
    }


def _pvr_ready(status):
    return bool(
        isinstance(status, dict) and not status.get("error")
        and status.get("available") and not status.get("scanning")
        and status.get("groups", 0) > 0 and status.get("channels", 0) > 0
    )


def _configure_pvr_from_xstream(dialog):
    """Ask XStream Pro to sync its own IPTV Simple instances via its native route.

    This deliberately does not copy credentials or write IPTV Simple settings.
    XStream's supported route owns the generated M3U/XMLTV and preserves foreign
    IPTV Simple instances. The provider's own confirmation and Kodi progress UI
    remain in control of the operation.
    """
    xstream_id = OPTIONAL_ADDONS["xstream"]
    pvr_id = OPTIONAL_ADDONS["pvr"]
    if not _addon_ready(xstream_id):
        dialog.ok("TV todavía no está preparada",
                  "Instala y habilita XStream Pro antes de preparar los canales.")
        return False
    if not _addon_requirement_ready(pvr_id):
        dialog.ok("PVR no disponible",
                  "Kodi no tiene una versión compatible de IPTV Simple. No se modificó ninguna configuración PVR.")
        return False
    status = _pvr_status()
    if _pvr_ready(status):
        return True
    state = _read_state()
    if state.get("setup_checks", {}).get("provider_authentication") != "PASS_RUNTIME":
        dialog.ok("Conecta primero tu proveedor",
                  "La sincronización PVR requiere que AcTweeteR haya validado el perfil de XStream en esta sesión de configuración.")
        return False
    if not dialog.yesno(
            "Preparar TV y canales",
            "XStream Pro sincronizará sus propios canales y, si el proveedor facilita datos, la guía de programación. Se actualizará el servicio PVR de Kodi; las demás instancias IPTV Simple se conservarán. ¿Continuar?",
            nolabel="Ahora no", yeslabel="Preparar TV"):
        return False
    try:
        xbmc.executebuiltin(
            "RunPlugin(plugin://plugin.video.xstream-pro/?mode=force_reload_pvr)",
            True,
        )
    except Exception as exc:  # Do not expose provider paths or exception text.
        xbmc.log("[AcTweeteR] PVR_AUTOCONFIG status=dispatch_error type=%s" %
                 type(exc).__name__, xbmc.LOGWARNING)
        dialog.ok("No se pudo iniciar la sincronización",
                  "XStream Pro no pudo iniciar la preparación de TV. No se marcará este paso como completado.")
        return False
    result = _pvr_status()
    if _pvr_ready(result):
        xbmc.log("[AcTweeteR] PVR_AUTOCONFIG status=verified groups=%d channels=%d epg=%s" %
                 (result["groups"], result["channels"],
                  "available" if result.get("broadcasts", 0) else "not_observed"),
                 xbmc.LOGINFO)
        return True
    xbmc.log("[AcTweeteR] PVR_AUTOCONFIG status=pending available=%s scanning=%s groups=%d channels=%d" %
             (bool(result.get("available")), bool(result.get("scanning")),
              result.get("groups", 0), result.get("channels", 0)), xbmc.LOGWARNING)
    dialog.ok("TV todavía se está preparando",
              "Kodi no ha confirmado grupos y canales disponibles. La instalación sigue incompleta; vuelve a comprobar cuando termine la carga de PVR.")
    return False


def _evaluate_setup_gates(state):
    """Refresh the core install/configuration gates; playback QA stays optional."""
    state = mark_setup_check(
        state, "mandatory_addons",
        "PASS_RUNTIME" if _mandatory_addons_ready() else "FAIL")

    provider_addon = None
    provider_https = False
    provider_ready = state.get("setup_checks", {}).get("provider_authentication") == "PASS_RUNTIME"
    if provider_ready and _addon_ready(OPTIONAL_ADDONS["xstream"]):
        try:
            provider_addon = xbmcaddon.Addon(OPTIONAL_ADDONS["xstream"])
            provider_ready = has_xtream_configuration(provider_addon)
            active = provider_addon.getSetting("active_pvr_profile") or "Profile 1"
            digits = "".join(char for char in active if char.isdigit())
            profile = int(digits or "1")
            base, username, password = parse_xtream_input(
                provider_addon.getSetting("profile_%d_xtream_url" % profile),
                provider_addon.getSetting("profile_%d_xtream_username" % profile),
                provider_addon.getSetting("profile_%d_xtream_password" % profile),
            )
            provider_ready = (provider_ready and bool(username and password)
                              and urlparse(base).scheme in ("http", "https"))
            provider_https = provider_ready and urlparse(base).scheme == "https"
        except Exception:
            provider_ready = False
    state = mark_setup_check(
        state, "provider_authentication",
        "PASS_RUNTIME" if provider_ready else "FAIL")

    catalog = _xstream_catalog_status() if provider_ready else {"movies": None, "series": None}
    movies_ok = isinstance(catalog.get("movies"), int) and catalog["movies"] > 0
    series_ok = isinstance(catalog.get("series"), int) and catalog["series"] > 0
    state = mark_setup_check(state, "movies_catalog",
                             "PASS_RUNTIME" if movies_ok else "FAIL")
    state = mark_setup_check(state, "series_catalog",
                             "PASS_RUNTIME" if series_ok else "FAIL")

    pvr = _pvr_status() if _addon_ready(OPTIONAL_ADDONS["pvr"]) else {
        "error": True, "available": False, "scanning": False,
        "groups": 0, "channels": 0, "broadcasts": 0,
    }
    tv_ready = _pvr_ready(pvr)
    state = mark_setup_check(state, "live_tv_ready",
                             "PASS_RUNTIME" if tv_ready else "FAIL")
    state = mark_setup_check(state, "pvr_configuration",
                             "PASS_RUNTIME" if tv_ready else "FAIL")
    # EPG is observed but deliberately non-blocking. Empty data is NOT called
    # “not provided”: that would require provider-specific proof.
    epg_status = "PASS_RUNTIME" if pvr["broadcasts"] > 0 else "NOT_TESTED"
    state = mark_setup_check(state, "epg_ready_or_not_provided", epg_status)
    return state, {"movies": catalog.get("movies"), "series": catalog.get("series"),
                   "pvr": pvr, "https_persisted": provider_https}


def _collect_status():
    installed = _installed_addons()
    configured = None
    if installed.get("xstream"):
        try:
            configured = has_xtream_configuration(xbmcaddon.Addon(OPTIONAL_ADDONS["xstream"]))
        except Exception:
            configured = False
    pvr = _pvr_status() if installed.get("pvr") else None
    return service_rows(installed, pvr=pvr, xstream_configured=configured)


def _show_status(dialog):
    rows = _collect_status()
    translated = {
        "CONFIGURED": "Datos presentes; conexión no probada",
        "SETUP_REQUIRED": "Requiere configuración",
        "INSTALLED_NOT_CHECKED": "Instalado; disponibilidad no comprobada",
        "INTEGRATION_NOT_CHECKED_NOW": "Integración incluida; proveedor no comprobado ahora",
        "DEPENDENCY_MISSING": "No disponible: falta SlyGuy Trailers",
        "NOT_REQUIRED_FOR_SLYGUY": "No necesario para trailers SlyGuy; OAuth no se comprobó",
        "OPTIONAL_MISSING": "Opcional; no instalado",
        "MISSING": "No instalado",
        "ERROR": "Kodi devolvió un error",
        "AVAILABLE": "Disponible en Kodi",
        "INITIALIZING_OR_UNAVAILABLE": "Inicializando o no disponible",
    }
    lines = ["%s: %s%s" % (
        row["service"], translated.get(row["status"], row["status"]),
        " (opcional)" if row["optional"] else ""
    ) for row in rows]
    lines.append("XStream Pro y los tráilers son requisitos para completar el asistente; su instalación no demuestra autenticación ni reproducción.")
    lines.append("El complemento YouTube puede requerir API/OAuth del usuario. AcTweeteR no lee, almacena ni comparte tokens.")
    lines.append("PVR disponible no confirma canales, EPG completa ni reproducción; compruébalos en Kodi.")
    dialog.textviewer("Estado de servicios de AcTweeteR", "\n".join(lines))


def _open_settings(dialog, key):
    addon_id = SETTINGS_ADDONS.get(key)
    if not addon_id:
        return
    installed = _addon_installed(addon_id)
    enabled = _addon_enabled(addon_id)
    if installed and enabled:
        # Kodi owns each add-on's official configuration UI and secret storage.
        xbmc.executebuiltin("Addon.OpenSettings(%s)" % addon_id, True)
        return

    if key == "xstream" and _is_tvos():
        if not _explain_tvos_xstream_dependency(dialog):
            return

    source_id = OPTIONAL_ADDON_SOURCES.get(key)
    source_enabled = _ensure_repository_enabled(dialog, source_id)
    action = optional_addon_action(
        key, installed, source_enabled, tvos=_is_tvos(), addon_enabled=enabled)
    if action == "ENABLE":
        result = _request_native_addon_install(
            dialog, addon_id, "instalación existente de Kodi")
        if result == "INSTALLED":
            xbmc.executebuiltin("Addon.OpenSettings(%s)" % addon_id, True)
        else:
            dialog.ok("Complemento deshabilitado",
                      "%s sigue deshabilitado. Puedes reintentar más tarde; Home no depende de este servicio." % addon_id)
        return
    if action == "PLATFORM_UNAVAILABLE":
        if key == "xstream":
            dialog.ok(
                "XStream no disponible en tvOS",
                "XStream Pro declara IPTV Simple como dependencia obligatoria. Este Kodi no presenta ahora pvr.iptvsimple instalado y habilitado en una versión compatible; AcTweeteR no descargará binarios ni modificará Kodi.app. Si esta distribución incluye PVR integrado, habilítalo desde la interfaz oficial de Kodi y vuelve a comprobar. La configuración seguirá incompleta mientras falte.")
            return
        dialog.ok(
            "No disponible en tvOS",
            "Este Kodi no presenta pvr.iptvsimple como complemento instalable. AcTweeteR no descargará ni instalará binarios externos; consulta la distribución de Kodi de este dispositivo. La TV/PVR no se verificará como lista, pero puedes seguir usando Kodi."
        )
        return
    if action == "REPOSITORY_REQUIRED":
        if source_id and _addon_installed(source_id):
            dialog.ok("Repositorio deshabilitado",
                      "%s no se habilitó. Puedes activarlo desde Complementos → Mis complementos → Repositorios y volver a intentarlo." % source_id)
            return
        dialog.ok(
            "Repositorio necesario",
            "Kodi no encuentra %s. AcTweeteR necesita su repositorio Kodi 1.0.3 habilitado para resolver esta dependencia sin un ZIP manual. Completa primero la instalación del repositorio AcTweeteR y vuelve a reparar los componentes." % source_id,
        )
        return
    if action != "OFFER_INSTALL":
        dialog.ok("Componente requerido", "No hay una vía de instalación autorizada configurada para este complemento. El asistente seguirá incompleto.")
        return

    result = _request_native_addon_install(
        dialog, addon_id, source_id,
        required=key in ("xstream", "pvr", "slyguy", "youtube"))
    if result != "INSTALLED":
        dialog.ok(
            "Instalación pendiente",
            ("Has omitido %s. Puedes volver a intentarlo desde este asistente." if result == "DECLINED" else
             "No se confirmó la instalación de %s. La opción sigue disponible para reintentar desde este asistente.") % addon_id,
        )
        return
    dialog.ok(
        "Componente instalado",
        "%s está instalado. La instalación sola no completa la configuración; vuelve al asistente para abrir sus ajustes oficiales y verificar las funciones. AcTweeteR no añade credenciales automáticamente." % addon_id,
    )


def _configure_xstream_provider(dialog):
    """Collect credentials once, validate them, then write only XStream settings."""
    addon_id = OPTIONAL_ADDONS["xstream"]
    if not _addon_ready(addon_id):
        _open_settings(dialog, "xstream")
        return False
    if _addon_version(addon_id) != "1.1.2":
        dialog.ok(
            "XStream Pro no compatible",
            "La configuración automática solo está verificada para XStream Pro 1.1.2. Actualiza o configura el complemento desde su interfaz oficial; AcTweeteR no modificará un esquema desconocido.",
        )
        return False
    try:
        addon = xbmcaddon.Addon(addon_id)
    except Exception as exc:  # noqa: BLE001 - avoid surfacing external add-on details.
        xbmc.log(f"[AcTweeteR] XSTREAM_SETUP status=addon_api_error type={type(exc).__name__}",
                 xbmc.LOGWARNING)
        dialog.ok("XStream no disponible", "Kodi no pudo abrir los ajustes del complemento. Reinténtalo desde el asistente.")
        return False
    try:
        already_configured = has_xtream_configuration(addon)
    except Exception:  # noqa: BLE001 - upstream add-on settings API is implementation-specific.
        already_configured = False
    if already_configured:
        keep_existing = dialog.yesno(
            "Proveedor IPTV ya configurado",
            "El perfil activo de XStream ya contiene datos. Puedes conservarlo y comprobar la conexión, o cambiar el proveedor. AcTweeteR no mostrará ni copiará los valores existentes.",
            nolabel="Cambiar proveedor",
            yeslabel="Conservar y comprobar")
        if keep_existing:
            try:
                profile_name = addon.getSetting("active_pvr_profile") or "Profile 1"
                digits = "".join(char for char in profile_name if char.isdigit())
                profile_number = int(digits or "1")
                if not 1 <= profile_number <= 10:
                    raise SetupError("PROFILE_UNAVAILABLE")
                prefix = "profile_%d_" % profile_number
                base, username, password = parse_xtream_input(
                    addon.getSetting(prefix + "xtream_url"),
                    addon.getSetting(prefix + "xtream_username"),
                    addon.getSetting(prefix + "xtream_password"),
                )
                if not username or not password:
                    raise SetupError("CREDENTIALS_REQUIRED")
                allow_insecure = False
                if urlparse(base).scheme == "http":
                    transport, secure_base = prepare_https_endpoint(base)
                    if transport == "HTTPS_READY":
                        if not _set_xstream_profile_url(
                                addon, prefix + "xtream_url", secure_base):
                            raise SetupError("XSTREAM_SETTINGS_WRITE_FAILED")
                        base = secure_base
                    elif transport == "HTTP_ONLY":
                        allow_insecure = dialog.yesno(
                            "Proveedor sin HTTPS",
                            "No se encontró un endpoint HTTPS válido. Si continúas, el proveedor recibirá el usuario y la contraseña sin cifrado de transporte. ¿Autorizas esa conexión insegura?",
                            nolabel="Cancelar", yeslabel="Enviar sin cifrar")
                        if not allow_insecure:
                            return False
                    else:
                        raise SetupError(transport)
                status = validate_xtream_credentials(
                    base, username, password, allow_insecure=allow_insecure,
                    user_agent=addon.getSetting("custom_user_agent"))
            except SetupError as exc:
                status = str(exc)
            except Exception as exc:  # noqa: BLE001 - never expose external values.
                xbmc.log("[AcTweeteR] XSTREAM_SETUP status=existing_profile_error type=%s" %
                         type(exc).__name__, xbmc.LOGWARNING)
                status = "SERVER_UNAVAILABLE"
            if status != "AUTHENTICATED":
                messages = {
                    "SERVER_REJECTED": "El servidor rechazó la solicitud.",
                    "REDIRECT_REFUSED": "El servidor intentó redirigir a otro host. Por seguridad, AcTweeteR no envió allí las credenciales.",
                    "HTTPS_UNAVAILABLE": "No se pudo confirmar una conexión HTTPS segura con el mismo servidor.",
                    "HTTP_ONLY": "El proveedor solo responde por HTTP.",
                    "SERVER_UNAVAILABLE": "No se pudo conectar con el servidor.",
                    "INVALID_RESPONSE": "El servidor respondió con un formato no reconocido.",
                    "INVALID_CREDENTIALS": "El proveedor no aceptó la configuración guardada.",
                    "ACCOUNT_UNAVAILABLE": "El proveedor indica que la cuenta no está disponible.",
                    "CREDENTIALS_REQUIRED": "Faltan datos en el perfil activo.",
                    "PROFILE_UNAVAILABLE": "El perfil activo de XStream no es válido.",
                    "SERVER_INVALID": "La dirección guardada no es válida.",
                }
                dialog.ok("No se pudo comprobar el proveedor",
                          messages.get(status, "No se pudo validar el perfil guardado."))
                return False
            state = _read_state()
            _write_state(mark_setup_check(state, "provider_authentication", "PASS_RUNTIME"))
            dialog.ok("Proveedor conectado",
                      "XStream Pro ha aceptado el perfil existente. No se reescribieron sus ajustes. Se actualizarán los catálogos para verificar películas, series y servicios asociados.")
            try:
                xbmc.executebuiltin(
                    "RunPlugin(plugin://plugin.video.xstream-pro/?mode=actweeter_refresh_profile&pnum=%d)" %
                    profile_number,
                    True,
                )
            except Exception as exc:  # noqa: BLE001 - suppress provider details.
                xbmc.log("[AcTweeteR] XSTREAM_REFRESH status=error type=%s" %
                         type(exc).__name__, xbmc.LOGWARNING)
                dialog.ok("Catálogo pendiente",
                          "La cuenta está validada, pero no se pudo iniciar la actualización automática. Los catálogos siguen pendientes.")
            return True

    server = dialog.input("Servidor o URL Xtream", type=xbmcgui.INPUT_ALPHANUM)
    if not server:
        return False
    embedded = False
    try:
        parsed = parse_xtream_input(server)
        embedded = bool(parsed[1] and parsed[2])
    except SetupError as exc:
        if str(exc) != "CREDENTIALS_REQUIRED":
            dialog.ok("Datos no válidos", "La dirección debe ser una URL HTTP/HTTPS válida del proveedor.")
            return False
    if embedded:
        base, username, password = parsed
    else:
        base = server
        username = dialog.input("Usuario", type=xbmcgui.INPUT_ALPHANUM)
        if not username:
            return False
        password = dialog.input(
            "Contraseña", type=xbmcgui.INPUT_ALPHANUM,
            option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if not password:
            return False

    try:
        base, username, password = parse_xtream_input(base, username, password)
    except SetupError:
        dialog.ok("Datos no válidos", "Comprueba el servidor, usuario y contraseña e inténtalo de nuevo.")
        return False
    allow_insecure = False
    if urlparse(base).scheme == "http":
        transport, secure_base = prepare_https_endpoint(base)
        if transport == "HTTPS_READY":
            base = secure_base
        elif transport == "HTTP_ONLY":
            allow_insecure = dialog.yesno(
                "Proveedor sin HTTPS",
                "No se encontró un endpoint HTTPS válido. Si continúas, el proveedor recibirá el usuario y la contraseña sin cifrado de transporte. ¿Autorizas esa conexión insegura?",
                nolabel="Cancelar", yeslabel="Enviar sin cifrar")
            if not allow_insecure:
                return False
        else:
            dialog.ok(
                "No se pudo verificar HTTPS",
                "AcTweeteR no enviará credenciales porque la respuesta HTTPS no pudo verificarse de forma segura.")
            return False

    try:
        status = validate_xtream_credentials(
            base, username, password, allow_insecure=allow_insecure,
            user_agent=addon.getSetting("custom_user_agent"))
    except Exception as exc:  # noqa: BLE001 - never emit provider URL or credentials.
        xbmc.log(f"[AcTweeteR] XSTREAM_SETUP status=validation_error type={type(exc).__name__}",
                 xbmc.LOGWARNING)
        status = "SERVER_UNAVAILABLE"
    messages = {
        "SERVER_REJECTED": "El servidor rechazó la solicitud. Comprueba la dirección y vuelve a intentarlo.",
        "REDIRECT_REFUSED": "El servidor intentó redirigir a otro host. Por seguridad, AcTweeteR no envió allí las credenciales.",
        "HTTPS_UNAVAILABLE": "No se pudo confirmar una conexión HTTPS segura con el mismo servidor.",
        "HTTP_ONLY": "El proveedor solo responde por HTTP.",
        "SERVER_UNAVAILABLE": "No se pudo conectar con el servidor. Comprueba la conexión e inténtalo de nuevo.",
        "INVALID_RESPONSE": "El servidor respondió con un formato no reconocido por Xtream Codes.",
        "INVALID_CREDENTIALS": "El proveedor no aceptó estas credenciales.",
        "ACCOUNT_UNAVAILABLE": "El proveedor indica que la cuenta está caducada o deshabilitada.",
    }
    if status != "AUTHENTICATED":
        dialog.ok("No se pudo conectar", messages.get(status, "No se pudo validar la cuenta."))
        return False
    try:
        save_native_profile(
            addon, base, username, password,
            translated_addon_path=xbmcvfs.translatePath(
                addon.getAddonInfo("path")))
    except Exception as exc:  # noqa: BLE001 - Kodi settings bridge errors may be implementation-specific.
        code = (str(exc) if isinstance(exc, SetupError)
                else "XSTREAM_SETTINGS_WRITE_FAILED")
        dialog.ok(
            "No se guardó la configuración",
            f"XStream Pro no coincide con el esquema comprobado o Kodi no confirmó el guardado ({code}). No se guardó una copia en AcTweeteR.",
        )
        return False

    state = _read_state()
    _write_state(mark_setup_check(state, "provider_authentication", "PASS_RUNTIME"))
    dialog.ok(
        "Proveedor conectado",
        "XStream Pro ha aceptado la cuenta y los datos se guardaron en sus propios ajustes. A continuación se abrirá la actualización de contenido de XStream para preparar los catálogos. La instalación seguirá incompleta hasta verificar películas, series, TV, guía y reproducción.",
    )
    try:
        xbmc.executebuiltin(
            "RunPlugin(plugin://plugin.video.xstream-pro/?mode=actweeter_refresh_profile&pnum=1)",
            True,
        )
    except Exception as exc:  # noqa: BLE001 - log only exception type, never URL or credentials.
        xbmc.log("[AcTweeteR] XSTREAM_REFRESH status=error type=%s" %
                 type(exc).__name__, xbmc.LOGWARNING)
        dialog.ok("Catálogo pendiente",
                  "La cuenta está validada y guardada en XStream. No se pudo iniciar la actualización automática; abre XStream Pro y actualiza el Perfil 1. Los catálogos siguen pendientes de verificación.")
    return True


def _missing_components():
    missing = [addon_id for addon_id in REQUIRED_REPAIR_SOURCES
               if not _addon_requirement_ready(addon_id)]
    # On tvOS, inspect the PVR binary already supplied by that Kodi build
    # before asking Kodi to install XStream, which declares PVR as mandatory.
    return sorted(missing, key=lambda addon_id: (
        0 if addon_id == "pvr.iptvsimple" else
        1 if addon_id == "plugin.video.xstream-pro" else 2))


def _complete_missing_components(dialog, *, consent_granted=False):
    """Repair the mandatory add-on graph through Kodi, with one consent step."""
    missing = _missing_components()
    if not missing:
        dialog.ok("Componentes preparados", "Los complementos obligatorios están instalados y habilitados. La autenticación, los catálogos, PVR/EPG y la reproducción todavía requieren verificación real.")
        return

    if not consent_granted and not dialog.yesno(
            "Preparar componentes de AcTweeteR",
            "Kodi instalará los componentes necesarios desde el repositorio AcTweeteR, el catálogo oficial Kodi y los índices originales conectados por el repositorio. Kodi mostrará sus propias confirmaciones de confianza/licencia. No se instalará ni configurará ningún servicio opcional.",
            "Ahora no", "Continuar"):
        return

    labels = {
        "plugin.video.xstream-pro": "XStream Pro",
        "pvr.iptvsimple": "PVR IPTV Simple",
        "slyguy.trailers": "SlyGuy Trailers",
        "script.bingie.helper": "BINGIE Helper",
        "script.bingie.toolbox": "BINGIE Toolbox",
        "script.bingie.widgets": "BINGIE Widgets",
        "script.skinshortcuts": "Skin Shortcuts",
        "resource.images.studios.coloured": "Studio artwork",
        "plugin.video.tmdb.bingie.helper": "BINGIE metadata helper",
        "plugin.program.autocompletion": "Search keyboard support",
        "plugin.video.youtube": "YouTube search and trailer fallback",
    }
    outcomes = []
    for addon_id in missing:
        if _is_tvos() and addon_id == "pvr.iptvsimple" and not _addon_installed(addon_id):
            outcomes.append(
                "PVR IPTV Simple: este Kodi tvOS no lo presenta instalado; no se descargará ni instalará un binario tvOS genérico.")
            continue
        if (_is_tvos() and addon_id == "plugin.video.xstream-pro"
                and _tvos_xstream_dependency_status() != "READY"):
            outcomes.append(
                "XStream Pro: pendiente; primero debe existir IPTV Simple tvOS habilitado y >=21.4.0.")
            continue
        sources = REQUIRED_REPAIR_SOURCES[addon_id]
        for source in sources:
            if _addon_enabled(source):
                break
            if _addon_installed(source) and not _addon_enabled(source):
                _ensure_repository_enabled(dialog, source)
        enabled_sources = [source for source in sources if _addon_enabled(source)]
        if not enabled_sources and not _addon_installed(addon_id):
            outcomes.append("%s: fuente requerida no disponible (%s)." %
                            (labels.get(addon_id, addon_id), ", ".join(sources)))
            continue
        result = _request_native_addon_install(
            dialog, addon_id, ", ".join(enabled_sources) or "instalación existente de Kodi",
            required=True, consent_granted=True)
        outcomes.append("%s: %s." % (
            labels.get(addon_id, addon_id),
            "instalado y habilitado" if result == "INSTALLED" else
            "pendiente; puedes reintentar desde este asistente"))
    outcomes.append(
        "Se usa el resolvedor nativo de Kodi; cada add-on conserva su configuración. "
        "La instalación de componentes no prueba proveedor, catálogo, EPG ni reproducción.")
    dialog.textviewer("Instalación de complementos", "\n\n".join(outcomes))


def _home_diagnostic():
    """Log a one-shot, secret-free snapshot; never records labels or paths."""
    window_id = focus_id = -1
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "GUI.GetProperties",
            "params": {"properties": ["currentwindow"]},
        })))
        window_id = response.get("result", {}).get("currentwindow", {}).get("id", -1)
        if isinstance(window_id, int) and window_id >= 0:
            focus_id = xbmcgui.Window(window_id).getFocusId()
    except Exception:
        pass
    missing_required = sum(not _addon_ready(addon_id)
                           for addon_id in REQUIRED_ADDON_IDS)
    widgets_count = xbmc.getInfoLabel("Container(77777).NumItems")
    snapshot = home_diagnostic_snapshot(
        window_id=window_id,
        focus_id=focus_id,
        menu_visible=xbmc.getCondVisibility("Control.IsVisible(900)"),
        widgets_count=widgets_count,
        widgets_updating=xbmc.getCondVisibility("Container(77777).IsUpdating"),
        startup_mask=xbmc.getInfoLabel("Window(Home).Property(StartupMask)"),
        intro_playback=xbmc.getInfoLabel("Window(Home).Property(AcTweeteRIntroPlayback)"),
        missing_required_count=missing_required,
    )
    xbmc.log(
        "[AcTweeteR] HOME_DIAGNOSTIC window=%d focus=%d menu_visible=%d widgets=%d updating=%d startup_mask=%d intro=%d missing_required=%d" % (
            snapshot["window_id"], snapshot["focus_id"], snapshot["menu_visible"],
            snapshot["widgets_count"], snapshot["widgets_updating"],
            snapshot["startup_mask"], snapshot["intro_playback"],
            snapshot["missing_required_count"]), xbmc.LOGINFO)
    return snapshot


def _set_intro(dialog):
    selected = dialog.select("Introducción", [label for label, _ in INTRO_OPTIONS])
    mode = intro_mode_for_selection(selected)
    if mode is None:
        return False
    xbmc.executebuiltin("Skin.SetString(splash_screen,%s)" % mode)
    return True


def _preview_notify(action, payload):
    encoded = base64.b64encode(json.dumps(
        {"action": action, **payload}, separators=(",", ":")
    ).encode("utf-8")).decode("ascii")
    request = {"jsonrpc": "2.0", "id": 1, "method": "JSONRPC.NotifyAll",
               "params": {"sender": "service.actweeter.SIGNAL",
                          "message": "actweeter_auto_preview", "data": [encoded]}}
    try:
        response = json.loads(xbmc.executeJSONRPC(
            json.dumps(request, separators=(",", ":"))))
        status = "accepted" if "error" not in response else "rejected"
    except Exception as exc:
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_SIGNAL action=%s status=error type=%s" %
                 (action, type(exc).__name__), xbmc.LOGWARNING)
        return False
    xbmc.log("[AcTweeteR] AUTO_PREVIEW_SIGNAL action=%s status=%s" %
             (action, status), xbmc.LOGINFO)
    return status == "accepted"


def _auto_preview_focus(args):
    if len(args) < 1:
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_FOCUS status=invalid_args", xbmc.LOGWARNING)
        return
    try:
        container = int(args[0])
        delay = float(args[1]) if len(args) > 1 else 3.0
        if container <= 0 or not (0.0 <= delay <= 60.0):
            xbmc.log("[AcTweeteR] AUTO_PREVIEW_FOCUS status=invalid_target", xbmc.LOGWARNING)
            return
        result = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "GUI.GetProperties",
            "params": {"properties": ["currentwindow"]},
        })))
        window = int(result["result"]["currentwindow"]["id"])
        focus = int(xbmcgui.Window(window).getFocusId())
        prefix = "Container(%d).ListItem." % container
        trailer = xbmc.getInfoLabel(prefix + "Trailer")
        trailer_id = ""
        try:
            parsed = urlparse(trailer)
            query = parse_qs(parsed.query)
            if parsed.hostname in ("youtube.com", "www.youtube.com", "m.youtube.com",
                                  "youtu.be", "plugin.video.youtube"):
                candidate = ((query.get("v") or query.get("video_id") or [""])[0]
                             if parsed.hostname != "youtu.be" else
                             parsed.path.strip("/"))
                if re.fullmatch(r"[A-Za-z0-9_-]{6,64}", candidate):
                    trailer_id = candidate
        except (TypeError, ValueError):
            trailer_id = ""
        payload = {
            "window": window,
            "container": container,
            "focus": focus,
            "position": int(xbmc.getInfoLabel("Container(%d).CurrentItem" % container) or "-1"),
            "media_type": xbmc.getInfoLabel(prefix + "DBType").lower(),
            "imdb": xbmc.getInfoLabel(prefix + "UniqueID(imdb)"),
            "tmdb": xbmc.getInfoLabel(prefix + "UniqueID(tmdb)"),
            "dbid": xbmc.getInfoLabel(prefix + "DBID"),
            "title": xbmc.getInfoLabel(prefix + "Title"),
            "year": xbmc.getInfoLabel(prefix + "Year"),
            "trailer_id": trailer_id,
            "delay": delay,
        }
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_FOCUS status=captured window=%d container=%d focus=%d media=%s identity=%s trailer=%s" %
                 (window, container, focus, payload["media_type"],
                  "present" if payload["imdb"] or payload["tmdb"] or payload["dbid"] else "missing",
                  "present" if trailer_id else "missing"), xbmc.LOGINFO)
        _preview_notify("focus", payload)
    except (KeyError, TypeError, ValueError):
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_FOCUS status=state_unavailable", xbmc.LOGWARNING)
        return
    except Exception as exc:
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_FOCUS status=error type=%s" %
                 type(exc).__name__, xbmc.LOGWARNING)
        return


def _auto_preview_cancel(args):
    try:
        container = int(args[0]) if args else 0
        payload = {}
        if container > 0:
            result = json.loads(xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0", "id": 1, "method": "GUI.GetProperties",
                "params": {"properties": ["currentwindow"]},
            })))
            window = int(result["result"]["currentwindow"]["id"])
            focus = int(xbmcgui.Window(window).getFocusId())
            prefix = "Container(%d).ListItem." % container
            payload = {
                "container": container, "window": window, "focus": focus,
                "position": int(xbmc.getInfoLabel(
                    "Container(%d).CurrentItem" % container) or "-1"),
                "media_type": xbmc.getInfoLabel(prefix + "DBType").lower(),
                "imdb": xbmc.getInfoLabel(prefix + "UniqueID(imdb)"),
                "tmdb": xbmc.getInfoLabel(prefix + "UniqueID(tmdb)"),
                "dbid": xbmc.getInfoLabel(prefix + "DBID"),
            }
        _preview_notify("cancel", payload)
    except (TypeError, ValueError):
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_CANCEL status=state_unavailable", xbmc.LOGWARNING)
        return
    except Exception as exc:
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_CANCEL status=error type=%s" %
                 type(exc).__name__, xbmc.LOGWARNING)
        return


def _auto_preview_preempt(owner):
    if owner in ("MANUAL_DETAIL", "MANUAL_SPOTLIGHT", "VOD", "OTHER"):
        _preview_notify("preempt", {"owner": owner})


def _play_intro():
    """Open the existing skin mask once per Kodi process for AcTweeteR modes."""
    mode = xbmc.getInfoLabel("Skin.String(splash_screen)")
    if mode not in ("actweeter_video", "actweeter_image"):
        return
    session_path = _intro_session_path()
    if not claim_process_session(session_path, os.getpid()):
        xbmc.log("[AcTweeteR] INTRO_SESSION_GUARD status=not_claimed",
                 xbmc.LOGINFO)
        return
    xbmc.log("[AcTweeteR] INTRO_SESSION_GUARD status=claimed",
             xbmc.LOGINFO)
    # Claim before inspecting playback: on startup the mask/player can become
    # active before this Home onload script runs. That must still consume the
    # process-wide attempt, or a later Home activation can replay the intro.
    if xbmc.getCondVisibility("Player.HasMedia"):
        return
    xbmc.executebuiltin("SetProperty(AcTweeteRIntroShown,1,Home)")
    xbmc.executebuiltin("SetProperty(StartupMask,1,Home)")
    if mode == "actweeter_video":
        # Establish ownership before opening the modal so menu focus cannot
        # clear the startup mask during the window-creation transition.
        xbmc.executebuiltin("SetProperty(AcTweeteRIntroPlayback,1,Home)")
    xbmc.executebuiltin("ActivateWindow(1103)")


def _intro_watchdog():
    """Release the visible splash only when the local intro never started."""
    if not xbmc.getInfoLabel("Window(Home).Property(AcTweeteRIntroPlayback)"):
        return
    if xbmc.getCondVisibility("Player.HasVideo"):
        xbmc.log("[AcTweeteR] INTRO_WATCHDOG status=player_active", xbmc.LOGINFO)
        return
    xbmc.log("[AcTweeteR] INTRO_WATCHDOG status=playback_not_started", xbmc.LOGWARNING)
    xbmc.executebuiltin("ClearProperty(AcTweeteRIntroPlayback,Home)")
    xbmc.executebuiltin("ClearProperty(StartupMask,Home)")
    xbmc.executebuiltin("Dialog.Close(1103,true)")


def _wizard(dialog, *, first_run=False):
    if first_run:
        answer = dialog.yesno(
            "Configuración inicial de AcTweeteR",
            "AcTweeteR preparará los componentes necesarios usando el instalador oficial de Kodi. Kodi puede mostrar sus propias confirmaciones de confianza o licencia. Después conectarás tu proveedor IPTV y verificaremos los servicios.\n"
            "Puedes introducir servidor, usuario y contraseña desde este asistente. Se validarán con tu proveedor y se guardarán únicamente en los ajustes nativos de XStream Pro; AcTweeteR no conserva una copia.\n\n¿Quieres empezar ahora?",
            "Ahora no", "Empezar",
        )
        state = _read_state()
        if not answer:
            _write_state(mark_prompted(state))
            return
        _write_state(mark_started(state))
        _complete_missing_components(dialog, consent_granted=True)
        state = _read_state()
        _write_state(mark_step(
            state, "Preparar componentes automáticamente",
            "REVIEWED" if not _missing_components() else "RETURNED"))

    options = [
        "Preparar componentes automáticamente",
        "Conectar proveedor IPTV",
        "Autorizaciones externas",
        "Configurar y verificar servicios",
        "Finalizar configuración",
        "Reparar componentes",
    ]
    while True:
        state = _read_state()
        start_at = int(state.get("last_step_index", 0)) if str(state.get("last_step_index", "0")).isdigit() else 0
        choice = dialog.select("Configuración inicial de AcTweeteR", options,
                               preselect=min(start_at, len(options) - 1))
        if choice < 0:
            break
        if choice == 4:
            state, evidence = _evaluate_setup_gates(state)
            if not completion_blockers(state):
                state = mark_completed(state)
            blockers = completion_blockers(state)
            if blockers:
                state = mark_step(state, options[choice], "REVIEWED")
                _write_state(state)
                reasons = {
                    "mandatory_addons": "faltan componentes obligatorios instalados/habilitados",
                    "provider_authentication": "el perfil activo de XStream no tiene autenticación runtime vigente",
                    "movies_catalog": "Kodi no pudo confirmar categorías de películas",
                    "series_catalog": "Kodi no pudo confirmar categorías de series",
                    "live_tv_ready": "PVR aún no ofrece grupos/canales listos",
                    "pvr_configuration": "PVR IPTV Simple no está configurado con grupos y canales disponibles",
                }
                details = [reasons.get(item, item) for item in blockers]
                dialog.ok(
                    "Configuración incompleta",
                    "AcTweeteR no guardará SETUP_COMPLETE todavía.\n• %s\n\n"
                    "Comprobación actual: %s categorías de películas, %s de series, %s grupos y %s canales. "
                    "Perfil HTTPS persistente: %s. La EPG y las pruebas de reproducción no bloquean la instalación. Puedes actualizar el proveedor/PVR y volver a comprobar."
                    % ("\n• ".join(details),
                       evidence["movies"] if evidence["movies"] is not None else "sin datos",
                       evidence["series"] if evidence["series"] is not None else "sin datos",
                       evidence["pvr"]["groups"], evidence["pvr"]["channels"],
                       "sí" if evidence["https_persisted"] else "no/pendiente"),
                )
            else:
                _write_state(state)
                dialog.ok("AcTweeteR", "AcTweeteR está preparado. El perfil IPTV persistido usa HTTPS: %s. La reproducción de películas, episodios y tráilers se valida por separado." % (
                    "sí" if evidence["https_persisted"] else "no; usa HTTP autorizado por el usuario"))
            return
        if choice == 5:
            _complete_missing_components(dialog)
            state = _read_state()
            _write_state(mark_step(state, options[choice], "REVIEWED"))
            continue
        _write_state(mark_step(state, options[choice], "IN_PROGRESS"))
        if choice == 0:
            _complete_missing_components(dialog)
            state = _read_state()
            _write_state(mark_step(state, options[choice], "REVIEWED"))
            continue
        if choice == 3:
            pvr_ready = False
            if _addon_ready(OPTIONAL_ADDONS["pvr"]):
                pvr_ready = _pvr_ready(_pvr_status())
            if not pvr_ready:
                _configure_pvr_from_xstream(dialog)
                state = _read_state()
                state, _ = _evaluate_setup_gates(state)
                _write_state(state)
            _show_status(dialog)
        elif choice == 1:
            _configure_xstream_provider(dialog)
        elif choice == 2:
            dialog.ok(
                "Autorizaciones externas",
                "SlyGuy/youtube-dl es la ruta principal de tráileres. YouTube también está instalado para las acciones de búsqueda y compatibilidad de AcTweeteR. No necesitas iniciar sesión en Google para terminar la instalación; si una función concreta lo requiere, YouTube mostrará su propio flujo oficial. AcTweeteR no lee ni guarda claves o tokens de Google.",
            )
        else:
            _show_status(dialog)
        state = _read_state()
        state["last_step_index"] = choice
        result = "REVIEWED" if choice in (2, 3) else "RETURNED"
        _write_state(mark_step(state, options[choice], result))


def main():
    dialog = xbmcgui.Dialog()
    action = sys.argv[1].strip().casefold() if len(sys.argv) > 1 else "wizard"
    args = [part.strip() for part in sys.argv[2:]]
    if action == "preview_focus":
        _auto_preview_focus(args)
    elif action == "preview_cancel":
        _auto_preview_cancel(args)
    elif action == "preview_manual":
        _auto_preview_preempt("MANUAL_DETAIL")
    elif action == "preview_spotlight":
        _auto_preview_preempt("MANUAL_SPOTLIGHT")
    elif action == "preview_vod":
        _auto_preview_preempt("VOD")
    elif action == "preview_exit":
        # Leaving a skin surface cancels its own preview work; it does not
        # imply that an unrelated/external player has taken ownership.
        _preview_notify("exit", {})
    elif action in ("first_run", "firstrun"):
        xbmc.log("[AcTweeteR] FIRST_RUN_FLOW status=entered", xbmc.LOGINFO)
        installed = _installed_addons()
        configured = False
        if installed.get("xstream"):
            try:
                configured = has_xtream_configuration(xbmcaddon.Addon(OPTIONAL_ADDONS["xstream"]))
            except Exception:
                configured = False
        state = _read_state()
        if should_offer_first_run(state, configured):
            if claim_process_session(_first_run_session_path(), os.getpid()):
                xbmc.log("[AcTweeteR] FIRST_RUN_WIZARD status=offered", xbmc.LOGINFO)
                _wizard(dialog, first_run=True)
            else:
                xbmc.log("[AcTweeteR] FIRST_RUN_WIZARD status=not_claimed",
                         xbmc.LOGINFO)
        else:
            reason = "prompted" if state.get("prompted") else "core_configured"
            xbmc.log("[AcTweeteR] FIRST_RUN_WIZARD status=skipped reason=%s" % reason,
                     xbmc.LOGINFO)
            missing = _missing_components()
            if should_offer_component_completion(state, missing, configured):
                # Persist before opening UI so repeated Home loads cannot stack
                # prompts. A declined offer remains available from Settings.
                _write_state(mark_component_offer_seen(state))
                required_missing = any(item in REQUIRED_REPAIR_SOURCES for item in missing)
                offer_text = (
                    "Esta actualización detectó componentes requeridos que faltan. ¿Abrir el asistente para pedir a Kodi que los instale desde repositorios autorizados? Puedes posponerlo, pero la configuración seguirá incompleta."
                    if required_missing else
                    "Esta actualización puede ayudarte a instalar los complementos opcionales que faltan. No son necesarios para Home y no se configurarán automáticamente. ¿Abrir el asistente?"
                )
                if dialog.yesno(
                        "Revisión de complementos de AcTweeteR",
                        offer_text,
                        "Ahora no", "Abrir asistente"):
                    _wizard(dialog)
        _play_intro()
    elif action in ("services", "status"):
        _show_status(dialog)
    elif action == "intro":
        _play_intro()
    elif action == "intro_watchdog":
        _intro_watchdog()
    else:
        _wizard(dialog)


if __name__ == "__main__":
    main()
