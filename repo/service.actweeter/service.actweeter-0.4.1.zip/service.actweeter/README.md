# AcTweeteR Service

Private Kodi helper add-on used by AcTweeteR for search coordination,
first-run setup, service status, and preview lifecycle integration.

The service does not contain account credentials. IPTV, YouTube/OAuth, Trakt,
and provider settings remain in their respective Kodi add-ons. Status checks
are on demand and intentionally report configuration presence separately from
connectivity or playback validation.

SlyGuy Trailers is the preferred, optional trailer provider. It is installed
from the connected upstream repository on demand through the setup wizard, so
its transitive dependency chain cannot prevent the skin or service from being
installed. If unavailable, AcTweeteR's interface remains usable and the trailer
integration can be retried later. YouTube and OAuth keep their existing roles.

The service is distributed through the AcTweeteR Kodi repository.
