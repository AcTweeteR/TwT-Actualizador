"""Kodi service lifecycle and background refresh coordinator."""

from __future__ import annotations

import os
import time
import sys
import json
import uuid
from pathlib import Path

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
LIB_PATH = os.path.join(ADDON_PATH, "resources", "lib")
if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)

from search_background import (last_successful_sync, plugin_refresh_url,
                               RefreshGate, xstream_profile_number)  # noqa: E402
from profile_sync import profile_sync_targets, sync_profiles  # noqa: E402
from profile_provisioning import provision_active_consumer  # noqa: E402


def sync_structural_profiles(vfs, addon_path):
    """Reconcile the six versioned Skin Shortcuts files across Kodi profiles."""
    master_root = Path(vfs.translatePath("special://masterprofile/")).resolve()
    profiles_file = master_root / "profiles.xml"
    manifest_file = Path(addon_path) / "resources" / "structural_manifest.json"
    profiles_xml = profiles_file.read_bytes()
    manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
    if manifest.get("schema_version") != 1 or not isinstance(manifest.get("files"), list):
        raise ValueError("unsupported structural manifest")
    targets = profile_sync_targets(profiles_xml, master_root)
    state_path = (master_root / "addon_data" / "service.actweeter" /
                  "profile_sync_state.json")
    return sync_profiles(master_root, targets, manifest["files"], state_path=state_path)


def provision_current_profile(kodi, addon_factory, vfs, addon_path):
    """Consumer-only first-run provisioner; Master remains the private source."""
    def set_skin(skin_id):
        if kodi.getSkinDir() == skin_id:
            return
        response = json.loads(kodi.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Settings.SetSettingValue",
            "params": {"setting": "lookandfeel.skin", "value": skin_id},
        })))
        if "error" in response or response.get("result") is not True:
            raise RuntimeError("Kodi rejected active-profile skin selection")
        # Kodi deliberately presents a timed Yes/No confirmation after a skin
        # switch. Confirm only that exact native dialog; never send Select to
        # an arbitrary foreground window. Without this, a clean Consumer
        # silently falls back to Estuary when the confirmation expires.
        for _ in range(150):
            if kodi.getSkinDir() == skin_id and xbmcgui.getCurrentWindowDialogId() == 10100:
                kodi.executebuiltin("Action(Select)", False)
                for _ in range(20):
                    if (kodi.getSkinDir() == skin_id and
                            xbmcgui.getCurrentWindowDialogId() != 10100):
                        return
                    kodi.sleep(100)
                break
            if kodi.getSkinDir() == skin_id and xbmcgui.getCurrentWindowDialogId() != 10100:
                # Kodi may not require confirmation (for example after the
                # preference was already accepted in this profile).
                return
            kodi.sleep(100)
        if kodi.getSkinDir() != skin_id:
            raise RuntimeError("Kodi reverted the requested profile skin")
        if xbmcgui.getCurrentWindowDialogId() == 10100:
            raise RuntimeError("Kodi skin confirmation was not accepted")

    return provision_active_consumer(
        kodi, addon_factory, vfs, addon_path,
        run_plugin=lambda url: kodi.executebuiltin("RunPlugin(%s)" % url, False),
        set_skin=set_skin,
    )


def _run_coordinator(kodi, addon_factory, vfs, clock=time.time, structure_sync=None):
    """Run one Kodi-owned coordinator loop; all provider I/O stays in XStream."""
    monitor = kodi.Monitor()
    refresh_gate = RefreshGate()
    service_started_at = clock()
    last_missing_addon_log = 0.0
    try:
        provision_status = provision_current_profile(
            kodi, addon_factory, vfs, ADDON_PATH
        )
        if provision_status not in ("NOT_CONSUMER", "ALREADY_PROVISIONED"):
            kodi.log("[AcTweeteR] PROFILE_PROVISIONING status=%s" % provision_status,
                     kodi.LOGINFO)
    except Exception as exc:
        kodi.log("[AcTweeteR] PROFILE_PROVISIONING status=ERROR error_type=%s" %
                 type(exc).__name__, kodi.LOGERROR)
    while not monitor.abortRequested():
        now = clock()
        if structure_sync is not None:
            try:
                outcome = structure_sync(vfs, ADDON_PATH)
                if outcome["files_updated"] or outcome["conflicts"] or outcome["errors"]:
                    kodi.log("[AcTweeteR] PROFILE_SYNC profiles=%d updated=%d conflicts=%d errors=%d" % (
                        outcome["profiles"], outcome["files_updated"],
                        outcome["conflicts"], outcome["errors"]), kodi.LOGINFO)
            except Exception as exc:
                kodi.log("[AcTweeteR] Profile structure sync unavailable error_type=%s" %
                         type(exc).__name__, kodi.LOGINFO)
        try:
            xstream = addon_factory("plugin.video.xstream-pro")
            xstream_profile = vfs.translatePath(xstream.getAddonInfo("profile"))
            profile_number = xstream_profile_number(xstream.getSetting("active_pvr_profile"))
            last_sync = last_successful_sync(xstream_profile, profile_number)
            # XStream builds a new profile's initial index during its own
            # startup. Give that bootstrap time to finish before this hourly
            # coordinator can request a stale/missing-index refresh.
            if last_sync <= 0 and now - service_started_at < 120:
                if monitor.waitForAbort(60):
                    break
                continue
            if refresh_gate.should_request(last_sync, now, abort=monitor.abortRequested()):
                # RunPlugin executes in Kodi's plugin runtime; this service only
                # schedules it and never reads provider settings or credentials.
                kodi.log("[AcTweeteR] SEARCH_REFRESH_START profile=%d" % profile_number,
                         kodi.LOGINFO)
                kodi.executebuiltin("RunPlugin(%s)" % plugin_refresh_url(profile_number), False)
                refresh_gate.mark_requested(now)
        except Exception as exc:
            # Add-on may be absent on a clean install before private provisioning.
            if now - last_missing_addon_log >= 3600:
                kodi.log("[AcTweeteR] Search refresh unavailable error_type=%s" %
                         type(exc).__name__, kodi.LOGINFO)
                last_missing_addon_log = now
        if monitor.waitForAbort(60):
            break


def _profile_kind(kodi):
    """Return a non-identifying profile class for lifecycle diagnostics."""
    try:
        response = json.loads(kodi.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Profiles.GetCurrentProfile",
            "params": {},
        })))
        label = str(response.get("result", {}).get("label", "")).casefold()
        if label == "consumer":
            return "consumer"
        if label:
            return "master"
    except Exception:
        pass
    return "unknown"


def run_service(kodi, addon_factory, vfs, clock=time.time, structure_sync=None):
    """Log one opaque lifecycle identity around the sole coordinator loop."""
    instance_id = uuid.uuid4().hex
    profile = _profile_kind(kodi)
    kodi.log("[AcTweeteR] SERVICE_INSTANCE_START profile=%s instance=%s" %
             (profile, instance_id), kodi.LOGINFO)
    kodi.log("[AcTweeteR] COORDINATOR_START profile=%s instance=%s" %
             (profile, instance_id), kodi.LOGINFO)
    try:
        return _run_coordinator(kodi, addon_factory, vfs, clock=clock,
                                structure_sync=structure_sync)
    finally:
        kodi.log("[AcTweeteR] COORDINATOR_STOP profile=%s instance=%s" %
                 (profile, instance_id), kodi.LOGINFO)
        kodi.log("[AcTweeteR] SERVICE_INSTANCE_STOP profile=%s instance=%s" %
                 (profile, instance_id), kodi.LOGINFO)


run_service(xbmc, xbmcaddon.Addon, xbmcvfs,
            structure_sync=sync_structural_profiles)
