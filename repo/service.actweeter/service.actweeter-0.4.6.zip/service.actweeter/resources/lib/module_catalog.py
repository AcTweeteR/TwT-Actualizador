"""Declarative AcTweeteR module catalog for Kodi-managed components.

This catalog records provenance and lifecycle policy; it never downloads or
redistributes third-party packages itself. Kodi's repositories remain the
installer and update authority.
"""

from __future__ import annotations

import re


CATALOG_VERSION = 2

MODULES = (
    {
        "id": "core",
        "name": "AcTweeteR Core",
        "required": True,
        "addons": (
            {"id": "skin.actweeter", "minimum": "1.2.8", "source": "repository.actweeter",
             "license": "GPL-2.0-or-later", "platforms": ("macos", "android", "tvos"),
             "dependencies": ("service.actweeter", "script.bingie.helper", "script.bingie.toolbox",
                              "script.bingie.widgets", "script.skinshortcuts"),
             "configuration": "Skin shortcuts and user preferences",
             "update": "Kodi add-on repository automatic updates",
             "recovery": "Kodi reinstall/update; preserve Kodi userdata"},
            {"id": "service.actweeter", "minimum": "0.4.3", "source": "repository.actweeter",
             "license": "GPL-2.0-or-later", "platforms": ("macos", "android", "tvos"),
             "dependencies": ("plugin.video.xstream-pro", "pvr.iptvsimple", "plugin.video.youtube", "slyguy.trailers"),
             "configuration": "Resumable setup state in add-on profile",
             "update": "Kodi add-on repository automatic updates",
             "recovery": "Rerun AcTweeteR setup/repair"},
            {"id": "xbmc.gui", "minimum": "5.17.0", "source": "Kodi application",
             "license": "Kodi upstream", "platforms": ("macos", "android", "tvos"),
             "dependencies": (), "configuration": "Provided by Kodi; not independently configured",
             "update": "Kodi application update", "recovery": "Update/reinstall compatible Kodi build"},
            {"id": "script.bingie.helper", "minimum": "1.1.2", "source": "repository.actweeter / Matke Omega",
             "license": "upstream metadata", "platforms": ("macos", "android", "tvos"),
             "dependencies": (), "configuration": "Skin helper actions",
             "update": "Original repository catalog", "recovery": "Kodi native reinstall"},
            {"id": "script.bingie.toolbox", "minimum": "1.0.0", "source": "repository.actweeter / Matke Omega",
             "license": "upstream metadata", "platforms": ("macos", "android", "tvos"),
             "dependencies": (), "configuration": "Skin tools and shortcuts",
             "update": "Original repository catalog", "recovery": "Kodi native reinstall"},
            {"id": "script.bingie.widgets", "minimum": "1.0.1", "source": "repository.actweeter / Matke Omega",
             "license": "upstream metadata", "platforms": ("macos", "android", "tvos"),
             "dependencies": (), "configuration": "Widget providers and skin settings",
             "update": "Original repository catalog", "recovery": "Kodi native reinstall"},
            {"id": "script.skinshortcuts", "minimum": "2.0.3", "source": "Kodi official repository",
             "license": "upstream metadata", "platforms": ("macos", "android", "tvos"),
             "dependencies": (), "configuration": "Generated menu in Kodi profile",
             "update": "Kodi official repository", "recovery": "Rerun skin shortcut generation"},
            {"id": "resource.images.studios.coloured", "minimum": "0.0.24", "source": "repository.actweeter / Kodi official",
             "license": "upstream metadata", "platforms": ("macos", "android", "tvos"),
             "dependencies": (), "configuration": "Image resource package",
             "update": "Original repository catalog", "recovery": "Kodi native reinstall"},
            {"id": "plugin.video.tmdb.bingie.helper", "minimum": "1.0.1", "source": "repository.actweeter / Matke Omega",
             "license": "upstream metadata", "platforms": ("macos", "android", "tvos"),
             "dependencies": (), "configuration": "Metadata and widget integration",
             "update": "Original repository catalog", "recovery": "Kodi native reinstall"},
            {"id": "plugin.program.autocompletion", "minimum": "2.1.2", "source": "repository.actweeter / Kodi official",
             "license": "upstream metadata", "platforms": ("macos", "android", "tvos"),
             "dependencies": (), "configuration": "Search keyboard support",
             "update": "Original repository catalog", "recovery": "Kodi native reinstall"},
        ),
    },
    {
        "id": "iptv",
        "name": "IPTV",
        "required": True,
        "addons": (
            {"id": "plugin.video.xstream-pro", "minimum": "1.1.2", "source": "repository.actweeter",
             "license": "CC-BY-NC-4.0", "platforms": ("macos", "android", "tvos"),
             "dependencies": ("pvr.iptvsimple",),
             "configuration": "Provider credentials stay in XStream settings; not copied into AcTweeteR",
             "update": "Kodi repository origin; AcTweeteR must maintain its package source",
             "recovery": "Rerun provider repair without resetting profile"},
            {"id": "pvr.iptvsimple", "minimum": "21.4.0", "source": "Kodi official or platform-bundled",
             "license": "upstream metadata", "platforms": ("macos", "android", "tvos"),
             "dependencies": (), "configuration": "PVR settings configured only after user/provider consent",
             "update": "Kodi official/platform binary update channel",
             "recovery": "Enable or repair through Kodi's native add-on manager"},
        ),
    },
    {
        "id": "trailers",
        "name": "Trailers (SlyGuy)",
        "required": True,
        "addons": (
            {"id": "repository.slyguy", "minimum": "0.0.9", "source": "official SlyGuy repository package, bootstrapped from its live catalog",
             "license": "upstream metadata; no AcTweeteR redistribution", "platforms": ("macos", "android", "tvos"),
             "dependencies": (), "configuration": "Kodi repository trust/install confirmation",
             "update": "SlyGuy repository", "recovery": "Re-enable repository and refresh Kodi repositories"},
            {"id": "slyguy.dependencies", "minimum": "0.0.30", "source": "repository.slyguy",
             "license": "upstream metadata; no AcTweeteR redistribution", "platforms": ("macos", "android", "tvos"),
             "dependencies": ("repository.slyguy",), "configuration": "None verified",
             "update": "SlyGuy repository", "recovery": "Kodi native reinstall from repository.slyguy"},
            {"id": "script.module.slyguy", "minimum": "0.86.96", "source": "repository.slyguy",
             "license": "upstream metadata; no AcTweeteR redistribution", "platforms": ("macos", "android", "tvos"),
             "dependencies": ("slyguy.dependencies", "repository.slyguy"), "configuration": "None verified",
             "update": "SlyGuy repository", "recovery": "Kodi native reinstall from repository.slyguy"},
            {"id": "slyguy.trailers", "minimum": "0.2.1", "source": "repository.slyguy",
             "license": "upstream metadata; no AcTweeteR redistribution", "platforms": ("macos", "android", "tvos"),
             "dependencies": ("script.module.slyguy", "inputstream.adaptive"), "configuration": "Provider availability; no shared credentials",
             "update": "SlyGuy repository", "recovery": "Rerun trailer repair in AcTweeteR"},
        ),
    },
    {
        "id": "media",
        "name": "Media and search",
        "required": True,
        "addons": (
            {"id": "plugin.video.youtube", "minimum": "", "source": "Kodi official repository",
             "license": "upstream metadata", "platforms": ("macos", "android", "tvos"),
             "dependencies": (), "configuration": "Google/API authorization is external and not inferred",
             "update": "Kodi official repository", "recovery": "Kodi native reinstall; retain add-on profile"},
            {"id": "script.trakt", "minimum": "", "source": "Kodi official repository",
             "license": "upstream metadata", "platforms": ("macos", "android", "tvos"),
             "dependencies": (), "configuration": "Account authorization belongs to the Trakt add-on; no automatic sign-in",
             "update": "Kodi official repository", "recovery": "Kodi native reinstall; retain add-on profile"},
            {"id": "inputstream.adaptive", "minimum": "21.0.0", "source": "Kodi official or platform-bundled",
             "license": "GPL-2.0-or-later", "platforms": ("macos", "android", "tvos"),
             "dependencies": (), "configuration": "Platform binary used by SlyGuy DASH playback",
             "update": "Kodi official/platform binary update channel",
             "recovery": "Enable compatible platform package through Kodi"},
        ),
    },
    {"id": "extensions", "name": "Extensions", "required": True, "addons": ()},
    {"id": "diagnostics", "name": "Diagnostics", "required": True,
     "minimum": "0.4.3", "source": "Bundled with service.actweeter",
     "license": "GPL-2.0-or-later", "platforms": ("macos", "android", "tvos"),
     "dependencies": (), "configuration": "Credential values excluded from exported reports",
     "update": "service.actweeter via Kodi repository updates",
     "recovery": "Rerun Diagnosticar instalación from AcTweeteR setup",
     "addons": ()},
)


def all_addons():
    """Flatten catalog entries, preserving the first canonical add-on record."""
    result = {}
    for module in MODULES:
        for addon in module["addons"]:
            result.setdefault(addon["id"], dict(addon))
    return result


def addon_state(addon, *, installed_version="", enabled=False, platform="unknown"):
    """Return an explicit status without equating installation with operation."""
    supported = platform in addon["platforms"] or "all" in addon["platforms"]
    if not supported:
        install_state = "UNSUPPORTED_PLATFORM"
    elif not installed_version:
        install_state = "MISSING"
    elif addon["minimum"] and not _version_satisfies(installed_version, addon["minimum"]):
        install_state = "VERSION_INCOMPATIBLE"
    elif not enabled:
        install_state = "INSTALLED_DISABLED"
    else:
        install_state = "INSTALLED_ENABLED"
    return {
        "id": addon["id"],
        "minimum": addon["minimum"],
        "installed_version": installed_version or "",
        "available_version": "UNKNOWN_UNQUERIED",
        "install_state": install_state,
        "runtime_state": "NOT_TESTED",
        "platform_compatibility": "NOT_RUNTIME_VERIFIED",
        "source": addon["source"],
        "license": addon["license"],
        "platforms": list(addon["platforms"]),
        "dependencies": list(addon["dependencies"]),
        "configuration": addon["configuration"],
        "update": addon["update"],
        "recovery": addon["recovery"],
    }


def _version_satisfies(installed, minimum):
    # Imported lazily: first_run also consumes this catalog's installation plan.
    from first_run import addon_version_satisfies
    return addon_version_satisfies(installed, minimum)


def installation_plan(platform, modules=None):
    """Dependency-first plan; Kodi resolves each package's full native imports.

    Catalog edges express bootstrap order, not a replacement for addon.xml.
    Unknown edges and cycles are errors rather than silently omitted packages.
    All registered modules are required unless explicitly opted out in code.
    Unsupported entries stay in the plan so callers report a blocking state.
    """
    modules = MODULES if modules is None else modules
    entries = {}
    for module in modules:
        if not module.get("required", True):
            continue
        for addon in module.get("addons", ()):
            if addon["id"] in entries:
                raise ValueError("duplicate catalog add-on")
            entries[addon["id"]] = dict(addon)
    ordered, visiting, visited = [], set(), set()

    def visit(addon_id):
        if addon_id.startswith("xbmc."):
            return  # Application API imports are verified by Kodi's resolver.
        if addon_id not in entries:
            raise ValueError("unregistered dependency: " + addon_id)
        if addon_id in visiting:
            raise ValueError("catalog dependency cycle: " + addon_id)
        if addon_id in visited:
            return
        visiting.add(addon_id)
        addon = entries[addon_id]
        for dependency in addon["dependencies"]:
            visit(dependency)
        visiting.remove(addon_id)
        visited.add(addon_id)
        addon["supported"] = platform in addon["platforms"] or "all" in addon["platforms"]
        ordered.append(addon)

    for addon_id in entries:
        visit(addon_id)
    return tuple(ordered)


def valid_catalog():
    """Validate stable IDs and required lifecycle fields for automated tests."""
    seen = set()
    for module in MODULES:
        if not re.fullmatch(r"[a-z][a-z0-9_-]*", module.get("id", "")):
            return False
        for addon in module.get("addons", ()):
            addon_id = addon.get("id", "")
            if (not re.fullmatch(r"[A-Za-z0-9._-]+", addon_id) or addon_id in seen
                    or not addon.get("source") or not addon.get("license")
                    or not addon.get("platforms") or "dependencies" not in addon
                    or not addon.get("update") or not addon.get("recovery")):
                return False
            seen.add(addon_id)
        if module["id"] == "diagnostics":
            required = ("minimum", "source", "license", "platforms", "dependencies",
                        "configuration", "update", "recovery")
            if any(key not in module or module[key] is None or module[key] == ""
                   for key in required):
                return False
    return True
