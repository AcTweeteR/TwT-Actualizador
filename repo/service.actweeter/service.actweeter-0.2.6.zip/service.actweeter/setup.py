"""Kodi-native onboarding and on-demand service diagnostics.

All credentials remain in the official add-on settings screens. This UI only
checks whether required fields are present and displays non-sensitive status.
"""

from __future__ import annotations

import json
import os
import sys
import base64
import re
from urllib.parse import parse_qs, urlparse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
LIB_PATH = os.path.join(ADDON_PATH, "resources", "lib")
if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)

from first_run import (
    INTRO_OPTIONS, OPTIONAL_ADDONS, OPTIONAL_ADDON_SOURCES,
    REQUIRED_REPAIR_SOURCES,
    REQUIRED_ADDON_IDS,
    has_xtream_configuration, home_diagnostic_snapshot, intro_mode_for_selection,
    optional_addon_action,
    claim_process_session, load_state, mark_completed, mark_prompted, mark_started, mark_step,
    mark_component_offer_seen, save_state, service_rows,
    should_offer_component_completion, should_offer_first_run,
    optional_source_guidance,
)


SETTINGS_ADDONS = {
    "xstream": "plugin.video.xstream-pro",
    "pvr": "pvr.iptvsimple",
    "slyguy": "slyguy.trailers",
    "youtube": "plugin.video.youtube",
    "trakt": "script.trakt",
}
METADATA_ADDONS = ("plugin.video.tmdb.bingie.helper",
                   "plugin.video.themoviedb.helper")


def _state_path():
    root = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    xbmcvfs.mkdirs(root)
    return os.path.join(root, "setup_state.json")


def _read_state():
    return load_state(_state_path())


def _write_state(state):
    save_state(_state_path(), state)


def _intro_session_path():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    xbmcvfs.mkdirs(profile)
    return os.path.join(profile, "intro_session.json")


def _first_run_session_path():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    xbmcvfs.mkdirs(profile)
    return os.path.join(profile, "first_run_session.json")


def _addon_installed(addon_id):
    return bool(xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id))


def _addon_enabled(addon_id):
    return bool(xbmc.getCondVisibility("System.AddonIsEnabled(%s)" % addon_id))


def _addon_ready(addon_id):
    return _addon_installed(addon_id) and _addon_enabled(addon_id)


def _ensure_repository_enabled(dialog, repository_id):
    """Enable only an already-installed repository, after explicit consent."""
    if not repository_id or _addon_enabled(repository_id):
        return bool(repository_id and _addon_enabled(repository_id))
    if not _addon_installed(repository_id):
        return False
    if not dialog.yesno(
            "Activar repositorio",
            "%s ya está instalado, pero deshabilitado. ¿Quieres habilitarlo para que Kodi pueda resolver el complemento solicitado? No se instalará ningún repositorio nuevo." % repository_id,
            "Ahora no", "Habilitar"):
        return False
    try:
        xbmc.executebuiltin("EnableAddon(%s)" % repository_id, True)
    except Exception as exc:
        xbmc.log("[AcTweeteR] REPOSITORY_ENABLE status=error type=%s" %
                 type(exc).__name__, xbmc.LOGWARNING)
    return _addon_enabled(repository_id)


def _is_tvos():
    return bool(xbmc.getCondVisibility("System.Platform.TVOS"))


def _open_external_zip_installer(dialog, key):
    """Open Kodi's native ZIP UI only after a user-approved external-source flow."""
    guidance = optional_source_guidance(key)
    if not guidance:
        return False
    if not dialog.yesno(
            "Fuente externa autorizada",
            guidance + "\n\n¿Abrir ahora el instalador ZIP de Kodi? AcTweeteR no añadirá la fuente ni instalará nada por sí solo.",
            "Ahora no", "Abrir instalador"):
        return False
    try:
        # Kodi owns unknown-source permission, archive selection and install prompts.
        xbmc.executebuiltin("InstallFromZip", True)
        return True
    except Exception as exc:
        xbmc.log("[AcTweeteR] ZIP_INSTALL_UI status=error type=%s" %
                 type(exc).__name__, xbmc.LOGWARNING)
        dialog.ok("No se pudo abrir el instalador", "Abre Complementos → Instalar desde archivo ZIP desde Kodi.")
        return False


def _request_native_addon_install(dialog, addon_id, source_id, *, required=False):
    """Request one install through Kodi and offer a bounded-by-user retry."""
    heading = "Dependencia de AcTweeteR" if required else "Instalar complemento opcional"
    role = "dependencia de la skin" if required else "servicio opcional"
    if not dialog.yesno(
            heading,
            "¿Pedir a Kodi que instale %s (%s) desde %s? Kodi gestiona las dependencias y confirmaciones; AcTweeteR no configura credenciales." %
            (addon_id, role, source_id),
            "Ahora no", "Instalar"):
        return "DECLINED"

    attempts = 0
    while attempts < 2:
        attempts += 1
        try:
            # Kodi's native installer handles dependency resolution, licenses,
            # platform packages, and its own confirmation UI.
            command = "EnableAddon" if _addon_installed(addon_id) else "InstallAddon"
            xbmc.executebuiltin("%s(%s)" % (command, addon_id), True)
        except Exception as exc:
            xbmc.log("[AcTweeteR] ADDON_INSTALL status=error addon=%s type=%s" %
                     (addon_id, type(exc).__name__), xbmc.LOGWARNING)
        if _addon_installed(addon_id) and _addon_enabled(addon_id):
            return "INSTALLED"
        if attempts == 2 or not dialog.yesno(
                "Instalación no confirmada",
                "Kodi no confirma que %s esté instalado y habilitado. Comprueba la conexión, la compatibilidad y el repositorio; ¿quieres volver a intentarlo ahora?" % addon_id,
                "Dejar pendiente", "Reintentar"):
            return "FAILED"
def _installed_addons():
    installed = {key: _addon_ready(addon_id)
                 for key, addon_id in OPTIONAL_ADDONS.items() if key != "metadata"}
    installed["required"] = all(_addon_ready(addon_id)
                                for addon_id in REQUIRED_ADDON_IDS)
    installed["metadata"] = any(_addon_installed(addon_id)
                                for addon_id in METADATA_ADDONS)
    return installed


def _pvr_status():
    raw = xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": "PVR.GetProperties",
        "params": {"properties": ["available", "scanning"]},
    }))
    try:
        response = json.loads(raw)
        if "error" in response:
            return {"error": True, "available": False, "scanning": False}
        result = response.get("result", {})
        return {"error": False, "available": bool(result.get("available")),
                "scanning": bool(result.get("scanning"))}
    except (TypeError, ValueError):
        return {"error": True, "available": False, "scanning": False}


def _collect_status():
    installed = _installed_addons()
    configured = None
    if installed.get("xstream"):
        try:
            configured = has_xtream_configuration(xbmcaddon.Addon(OPTIONAL_ADDONS["xstream"]))
        except Exception:
            configured = False
    pvr = _pvr_status() if installed.get("pvr") else None
    return service_rows(installed, pvr=pvr, xstream_configured=configured)


def _show_status(dialog):
    rows = _collect_status()
    translated = {
        "CONFIGURED": "Datos presentes; conexión no probada",
        "SETUP_REQUIRED": "Requiere configuración",
        "INSTALLED_NOT_CHECKED": "Instalado; disponibilidad no comprobada",
        "INTEGRATION_NOT_CHECKED_NOW": "Integración incluida; proveedor no comprobado ahora",
        "DEPENDENCY_MISSING": "No disponible: falta SlyGuy Trailers",
        "NOT_REQUIRED_FOR_SLYGUY": "No necesario para trailers SlyGuy; OAuth no se comprobó",
        "OPTIONAL_MISSING": "Opcional; no instalado",
        "MISSING": "No instalado",
        "ERROR": "Kodi devolvió un error",
        "AVAILABLE": "Disponible en Kodi",
        "INITIALIZING_OR_UNAVAILABLE": "Inicializando o no disponible",
    }
    lines = ["%s: %s%s" % (
        row["service"], translated.get(row["status"], row["status"]),
        " (opcional)" if row["optional"] else ""
    ) for row in rows]
    lines.append("SlyGuy Trailers es el proveedor principal integrado; yt-dlp no requiere Google OAuth.")
    lines.append("YouTube y su OAuth son opcionales y los administra el complemento YouTube; no se leen tokens aquí.")
    lines.append("PVR disponible no confirma canales, EPG completa ni reproducción; compruébalos en Kodi.")
    dialog.textviewer("Estado de servicios de AcTweeteR", "\n".join(lines))


def _open_settings(dialog, key):
    addon_id = SETTINGS_ADDONS.get(key)
    if not addon_id:
        return
    installed = _addon_installed(addon_id)
    enabled = _addon_enabled(addon_id)
    if installed and enabled:
        # Kodi owns each add-on's official configuration UI and secret storage.
        xbmc.executebuiltin("Addon.OpenSettings(%s)" % addon_id, True)
        return

    source_id = OPTIONAL_ADDON_SOURCES.get(key)
    source_enabled = _ensure_repository_enabled(dialog, source_id)
    action = optional_addon_action(
        key, installed, source_enabled, tvos=_is_tvos(), addon_enabled=enabled)
    if action == "ENABLE":
        result = _request_native_addon_install(
            dialog, addon_id, "instalación existente de Kodi")
        if result == "INSTALLED":
            xbmc.executebuiltin("Addon.OpenSettings(%s)" % addon_id, True)
        else:
            dialog.ok("Complemento deshabilitado",
                      "%s sigue deshabilitado. Puedes reintentar más tarde; Home no depende de este servicio." % addon_id)
        return
    if action == "PLATFORM_UNAVAILABLE":
        if key == "xstream":
            dialog.ok(
                "XStream no disponible en tvOS",
                "La versión de XStream Pro identificada declara IPTV Simple como dependencia obligatoria. Kodi Omega no publica el paquete oficial de IPTV Simple para tvOS; AcTweeteR no intentará instalar una dependencia irresoluble. Home sigue disponible.")
            return
        dialog.ok(
            "No disponible en tvOS",
            "Kodi Omega no publica un binario oficial de PVR IPTV Simple para tvOS. La TV/PVR nativa no se puede completar en este dispositivo; esto no afecta al Home ni a las demás funciones."
        )
        return
    if action == "REPOSITORY_REQUIRED":
        if source_id and _addon_installed(source_id):
            dialog.ok("Repositorio deshabilitado",
                      "%s no se habilitó. Puedes activarlo desde Complementos → Mis complementos → Repositorios y volver a intentarlo." % source_id)
            return
        if key == "slyguy":
            _open_external_zip_installer(dialog, key)
            return
        dialog.ok(
            "Repositorio necesario",
            "Kodi no tiene instalado/habilitado %s. Activa el repositorio oficial de Kodi desde Complementos → Mis complementos → Repositorios de complementos → Kodi Add-on repository. Después vuelve a este asistente. Puedes omitirlo." % source_id,
        )
        return
    if action == "SOURCE_REQUIRED":
        _open_external_zip_installer(dialog, key)
        return
    if action != "OFFER_INSTALL":
        dialog.ok("Complemento opcional", "No hay una vía de instalación autorizada configurada para este complemento.")
        return

    result = _request_native_addon_install(dialog, addon_id, source_id)
    if result != "INSTALLED":
        dialog.ok(
            "Instalación pendiente",
            ("Has omitido %s. Puedes volver a intentarlo desde este asistente." if result == "DECLINED" else
             "No se confirmó la instalación de %s. La opción sigue disponible para reintentar desde este asistente.") % addon_id,
        )
        return
    dialog.ok(
        "Complemento instalado",
        "%s está instalado. Si quieres configurarlo, vuelve al asistente y selecciona su opción de configuración. AcTweeteR no añade credenciales automáticamente." % addon_id,
    )


def _missing_components():
    missing_required = [addon_id for addon_id in REQUIRED_REPAIR_SOURCES
                        if not _addon_ready(addon_id)]
    missing_optional = [key for key, addon_id in OPTIONAL_ADDONS.items()
                        if key != "metadata" and not _addon_ready(addon_id)]
    return missing_required + missing_optional


def _complete_missing_components(dialog):
    """Offer installs only through already-enabled authorized Kodi repos."""
    missing = _missing_components()
    if not missing:
        dialog.ok("Complementos", "Los complementos declarados y servicios opcionales ya están instalados.")
        return

    labels = {
        "xstream": "XStream Pro (IPTV; fuente oficial de XStream Pro)",
        "pvr": "PVR IPTV Simple Client (repositorio oficial de Kodi)",
        "slyguy": "SlyGuy Trailers (requiere el repositorio oficial)",
        "youtube": "YouTube (repositorio oficial de Kodi)",
        "trakt": "Trakt (repositorio oficial de Kodi)",
    }
    outcomes = []
    external_pending = None
    external_installer_opened = False
    for addon_id in (item for item in missing if item in REQUIRED_REPAIR_SOURCES):
        sources = REQUIRED_REPAIR_SOURCES[addon_id]
        for source in sources:
            if _ensure_repository_enabled(dialog, source):
                break
        enabled_sources = [source for source in sources if _addon_enabled(source)]
        already_installed = _addon_installed(addon_id)
        if not enabled_sources and not already_installed:
            source_help = " o ".join(sources)
            outcomes.append(
                "%s: falta. Instala y habilita %s%s y vuelve a intentarlo."
                % (addon_id, source_help,
                   " (repository.actweeter 1.0.2 incluye el catálogo Omega de Matke)"
                   if "repository.actweeter" in sources else ""))
            continue
        result = _request_native_addon_install(
            dialog, addon_id, ", ".join(enabled_sources) or "instalación existente de Kodi",
            required=True)
        status = ("instalado y habilitado" if result == "INSTALLED" else
                  "omitido por el usuario" if result == "DECLINED" else
                  "pendiente; puedes reintentar desde este asistente")
        outcomes.append("%s: %s." % (addon_id, status))

    for key in missing:
        if key in REQUIRED_REPAIR_SOURCES:
            continue
        addon_id = OPTIONAL_ADDONS[key]
        source_id = OPTIONAL_ADDON_SOURCES.get(key)
        if source_id:
            _ensure_repository_enabled(dialog, source_id)
        action = optional_addon_action(
            key, _addon_installed(addon_id),
            bool(source_id and _addon_enabled(source_id)), tvos=_is_tvos(),
            addon_enabled=_addon_enabled(addon_id))
        if action == "PLATFORM_UNAVAILABLE":
            if key == "xstream":
                outcomes.append("XStream Pro: no se ofrece en tvOS porque su dependencia declarada IPTV Simple no tiene paquete Kodi Omega compatible verificado. Home continúa disponible.")
            else:
                outcomes.append("PVR IPTV Simple: no hay paquete oficial Kodi Omega para tvOS; la función PVR nativa no está disponible en este dispositivo.")
            continue
        if action == "SOURCE_REQUIRED":
            guidance = optional_source_guidance(key)
            outcomes.append("%s: requiere instalación desde una fuente externa autorizada. %s" %
                            (labels.get(key, addon_id), guidance))
            if external_pending is None:
                external_pending = ("Fuente externa autorizada", guidance)
            continue
        if action == "ENABLE":
            result = _request_native_addon_install(
                dialog, addon_id, "instalación existente de Kodi")
            status = "habilitado" if result == "INSTALLED" else "sigue pendiente; puedes reintentarlo"
            outcomes.append("%s: %s." % (labels.get(key, addon_id), status))
            continue
        if action == "REPOSITORY_REQUIRED":
            if key == "slyguy":
                guidance = optional_source_guidance(key)
                outcomes.append("SlyGuy Trailers: primero instala el repositorio SlyGuy. %s" % guidance)
                if external_pending is None:
                    external_pending = ("Instalar repositorio SlyGuy", guidance)
                continue
            guidance = "Activa el repositorio Kodi Add-on repository desde Complementos → Mis complementos → Repositorios de complementos y vuelve a intentarlo."
            outcomes.append("%s: falta %s. %s Después vuelve a intentarlo; se puede omitir." %
                            (labels.get(key, addon_id), source_id or "un repositorio compatible", guidance))
            continue
        result = _request_native_addon_install(
            dialog, addon_id, source_id, required=False)
        status = ("instalado y habilitado" if result == "INSTALLED" else
                  "omitido por el usuario" if result == "DECLINED" else
                  "pendiente; puedes reintentar desde este asistente")
        outcomes.append("%s: %s." % (labels.get(key, addon_id), status))

    if external_pending:
        heading, guidance = external_pending
        if dialog.yesno(
                heading,
                guidance + "\n\n¿Abrir el instalador ZIP de Kodi? AcTweeteR no añadirá fuentes ni elegirá paquetes por ti.",
                "Ahora no", "Abrir instalador"):
            try:
                # Run the one external ZIP workflow only after native-repository
                # requests finish, so Kodi's modal dialogs are never stacked.
                xbmc.executebuiltin("InstallFromZip", True)
                external_installer_opened = True
            except Exception as exc:
                xbmc.log("[AcTweeteR] ZIP_INSTALL_UI status=error type=%s" %
                         type(exc).__name__, xbmc.LOGWARNING)
        else:
            outcomes.append("El flujo externo se omitió; puedes reabrirlo desde este asistente.")
    if external_installer_opened:
        outcomes.append("Se abrió una sola sesión del instalador ZIP. Instala el repositorio/fuente elegidos y vuelve a ejecutar Completar instalación para continuar con los demás componentes externos.")
    outcomes.append("La falta de estos servicios no bloquea Home. La configuración es independiente y opcional.")
    dialog.textviewer("Instalación de complementos", "\n\n".join(outcomes))


def _home_diagnostic():
    """Log a one-shot, secret-free snapshot; never records labels or paths."""
    window_id = focus_id = -1
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "GUI.GetProperties",
            "params": {"properties": ["currentwindow"]},
        })))
        window_id = response.get("result", {}).get("currentwindow", {}).get("id", -1)
        if isinstance(window_id, int) and window_id >= 0:
            focus_id = xbmcgui.Window(window_id).getFocusId()
    except Exception:
        pass
    missing_required = sum(not _addon_ready(addon_id)
                           for addon_id in REQUIRED_ADDON_IDS)
    widgets_count = xbmc.getInfoLabel("Container(77777).NumItems")
    snapshot = home_diagnostic_snapshot(
        window_id=window_id,
        focus_id=focus_id,
        menu_visible=xbmc.getCondVisibility("Control.IsVisible(900)"),
        widgets_count=widgets_count,
        widgets_updating=xbmc.getCondVisibility("Container(77777).IsUpdating"),
        startup_mask=xbmc.getInfoLabel("Window(Home).Property(StartupMask)"),
        intro_playback=xbmc.getInfoLabel("Window(Home).Property(AcTweeteRIntroPlayback)"),
        missing_required_count=missing_required,
    )
    xbmc.log(
        "[AcTweeteR] HOME_DIAGNOSTIC window=%d focus=%d menu_visible=%d widgets=%d updating=%d startup_mask=%d intro=%d missing_required=%d" % (
            snapshot["window_id"], snapshot["focus_id"], snapshot["menu_visible"],
            snapshot["widgets_count"], snapshot["widgets_updating"],
            snapshot["startup_mask"], snapshot["intro_playback"],
            snapshot["missing_required_count"]), xbmc.LOGINFO)
    return snapshot


def _set_intro(dialog):
    selected = dialog.select("Introducción", [label for label, _ in INTRO_OPTIONS])
    mode = intro_mode_for_selection(selected)
    if mode is None:
        return False
    xbmc.executebuiltin("Skin.SetString(splash_screen,%s)" % mode)
    return True


def _preview_notify(action, payload):
    encoded = base64.b64encode(json.dumps(
        {"action": action, **payload}, separators=(",", ":")
    ).encode("utf-8")).decode("ascii")
    request = {"jsonrpc": "2.0", "id": 1, "method": "JSONRPC.NotifyAll",
               "params": {"sender": "service.actweeter.SIGNAL",
                          "message": "actweeter_auto_preview", "data": [encoded]}}
    try:
        response = json.loads(xbmc.executeJSONRPC(
            json.dumps(request, separators=(",", ":"))))
        status = "accepted" if "error" not in response else "rejected"
    except Exception as exc:
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_SIGNAL action=%s status=error type=%s" %
                 (action, type(exc).__name__), xbmc.LOGWARNING)
        return False
    xbmc.log("[AcTweeteR] AUTO_PREVIEW_SIGNAL action=%s status=%s" %
             (action, status), xbmc.LOGINFO)
    return status == "accepted"


def _auto_preview_focus(args):
    if len(args) < 1:
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_FOCUS status=invalid_args", xbmc.LOGWARNING)
        return
    try:
        container = int(args[0])
        delay = float(args[1]) if len(args) > 1 else 3.0
        if container <= 0 or not (0.0 <= delay <= 60.0):
            xbmc.log("[AcTweeteR] AUTO_PREVIEW_FOCUS status=invalid_target", xbmc.LOGWARNING)
            return
        result = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "GUI.GetProperties",
            "params": {"properties": ["currentwindow"]},
        })))
        window = int(result["result"]["currentwindow"]["id"])
        focus = int(xbmcgui.Window(window).getFocusId())
        prefix = "Container(%d).ListItem." % container
        trailer = xbmc.getInfoLabel(prefix + "Trailer")
        trailer_id = ""
        try:
            parsed = urlparse(trailer)
            query = parse_qs(parsed.query)
            if parsed.hostname in ("youtube.com", "www.youtube.com", "m.youtube.com",
                                  "youtu.be", "plugin.video.youtube"):
                candidate = ((query.get("v") or query.get("video_id") or [""])[0]
                             if parsed.hostname != "youtu.be" else
                             parsed.path.strip("/"))
                if re.fullmatch(r"[A-Za-z0-9_-]{6,64}", candidate):
                    trailer_id = candidate
        except (TypeError, ValueError):
            trailer_id = ""
        payload = {
            "window": window,
            "container": container,
            "focus": focus,
            "position": int(xbmc.getInfoLabel("Container(%d).CurrentItem" % container) or "-1"),
            "media_type": xbmc.getInfoLabel(prefix + "DBType").lower(),
            "imdb": xbmc.getInfoLabel(prefix + "UniqueID(imdb)"),
            "tmdb": xbmc.getInfoLabel(prefix + "UniqueID(tmdb)"),
            "dbid": xbmc.getInfoLabel(prefix + "DBID"),
            "title": xbmc.getInfoLabel(prefix + "Title"),
            "year": xbmc.getInfoLabel(prefix + "Year"),
            "trailer_id": trailer_id,
            "delay": delay,
        }
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_FOCUS status=captured window=%d container=%d focus=%d media=%s identity=%s trailer=%s" %
                 (window, container, focus, payload["media_type"],
                  "present" if payload["imdb"] or payload["tmdb"] or payload["dbid"] else "missing",
                  "present" if trailer_id else "missing"), xbmc.LOGINFO)
        _preview_notify("focus", payload)
    except (KeyError, TypeError, ValueError):
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_FOCUS status=state_unavailable", xbmc.LOGWARNING)
        return
    except Exception as exc:
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_FOCUS status=error type=%s" %
                 type(exc).__name__, xbmc.LOGWARNING)
        return


def _auto_preview_cancel(args):
    try:
        container = int(args[0]) if args else 0
        payload = {}
        if container > 0:
            result = json.loads(xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0", "id": 1, "method": "GUI.GetProperties",
                "params": {"properties": ["currentwindow"]},
            })))
            window = int(result["result"]["currentwindow"]["id"])
            focus = int(xbmcgui.Window(window).getFocusId())
            prefix = "Container(%d).ListItem." % container
            payload = {
                "container": container, "window": window, "focus": focus,
                "position": int(xbmc.getInfoLabel(
                    "Container(%d).CurrentItem" % container) or "-1"),
                "media_type": xbmc.getInfoLabel(prefix + "DBType").lower(),
                "imdb": xbmc.getInfoLabel(prefix + "UniqueID(imdb)"),
                "tmdb": xbmc.getInfoLabel(prefix + "UniqueID(tmdb)"),
                "dbid": xbmc.getInfoLabel(prefix + "DBID"),
            }
        _preview_notify("cancel", payload)
    except (TypeError, ValueError):
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_CANCEL status=state_unavailable", xbmc.LOGWARNING)
        return
    except Exception as exc:
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_CANCEL status=error type=%s" %
                 type(exc).__name__, xbmc.LOGWARNING)
        return


def _auto_preview_preempt(owner):
    if owner in ("MANUAL_DETAIL", "MANUAL_SPOTLIGHT", "VOD", "OTHER"):
        _preview_notify("preempt", {"owner": owner})


def _play_intro():
    """Open the existing skin mask once per Kodi process for AcTweeteR modes."""
    mode = xbmc.getInfoLabel("Skin.String(splash_screen)")
    if mode not in ("actweeter_video", "actweeter_image"):
        return
    session_path = _intro_session_path()
    if not claim_process_session(session_path, os.getpid()):
        xbmc.log("[AcTweeteR] INTRO_SESSION_GUARD status=not_claimed",
                 xbmc.LOGINFO)
        return
    xbmc.log("[AcTweeteR] INTRO_SESSION_GUARD status=claimed",
             xbmc.LOGINFO)
    # Claim before inspecting playback: on startup the mask/player can become
    # active before this Home onload script runs. That must still consume the
    # process-wide attempt, or a later Home activation can replay the intro.
    if xbmc.getCondVisibility("Player.HasMedia"):
        return
    xbmc.executebuiltin("SetProperty(AcTweeteRIntroShown,1,Home)")
    xbmc.executebuiltin("SetProperty(StartupMask,1,Home)")
    if mode == "actweeter_video":
        # Establish ownership before opening the modal so menu focus cannot
        # clear the startup mask during the window-creation transition.
        xbmc.executebuiltin("SetProperty(AcTweeteRIntroPlayback,1,Home)")
    xbmc.executebuiltin("ActivateWindow(1103)")


def _intro_watchdog():
    """Release the visible splash only when the local intro never started."""
    if not xbmc.getInfoLabel("Window(Home).Property(AcTweeteRIntroPlayback)"):
        return
    if xbmc.getCondVisibility("Player.HasVideo"):
        xbmc.log("[AcTweeteR] INTRO_WATCHDOG status=player_active", xbmc.LOGINFO)
        return
    xbmc.log("[AcTweeteR] INTRO_WATCHDOG status=playback_not_started", xbmc.LOGWARNING)
    xbmc.executebuiltin("ClearProperty(AcTweeteRIntroPlayback,Home)")
    xbmc.executebuiltin("ClearProperty(StartupMask,Home)")
    xbmc.executebuiltin("Dialog.Close(1103,true)")


def _wizard(dialog, *, first_run=False):
    if first_run:
        answer = dialog.yesno(
            "Configuración inicial de AcTweeteR",
            "XStream configura el catálogo IPTV. SlyGuy Trailers es el proveedor principal opcional para trailers y no necesita Google OAuth.\n"
            "YouTube, su OAuth, PVR y Trakt son opcionales según las funciones que quieras usar.\n"
            "Las contraseñas se introducen únicamente en los ajustes oficiales; AcTweeteR no las copia.\n\n¿Quieres empezar ahora?",
            "Ahora no", "Empezar",
        )
        state = _read_state()
        if not answer:
            _write_state(mark_prompted(state))
            return
        _write_state(mark_started(state))

    options = [
        "Comprobar componentes",
        "Configurar IPTV / XStream",
        "Configurar TV / PVR",
        "Configurar SlyGuy Trailers (opcional)",
        "Configurar YouTube (opcional)",
        "Vincular Trakt (opcional)",
        "Elegir introducción",
        "Ver estado de servicios",
        "Diagnosticar Home (sin datos personales)",
        "Finalizar",
        "Completar instalación de complementos",
    ]
    while True:
        state = _read_state()
        start_at = int(state.get("last_step_index", 0)) if str(state.get("last_step_index", "0")).isdigit() else 0
        choice = dialog.select("Configuración inicial de AcTweeteR", options,
                               preselect=min(start_at, len(options) - 1))
        if choice < 0:
            break
        if choice == 9:
            installed = {key: _addon_installed(addon_id)
                         for key, addon_id in OPTIONAL_ADDONS.items()}
            core_configured = False
            if installed.get("xstream"):
                try:
                    core_configured = has_xtream_configuration(
                        xbmcaddon.Addon(OPTIONAL_ADDONS["xstream"]))
                except Exception:
                    core_configured = False
            # Presence of settings is not a provider connectivity/playback test.
            status = "PARTIALLY_CONFIGURED" if core_configured else "CONFIGURATION_REQUIRED"
            _write_state(mark_completed(state, status))
            final_message = (
                "Hay datos básicos de XStream, pero esta comprobación no ha probado el proveedor. "
                "Revisa Estado de servicios si el catálogo no carga."
                if core_configured else
                "La configuración principal sigue pendiente. Puedes continuar con Kodi y volver a este asistente desde Ajustes."
            )
            dialog.ok("AcTweeteR", final_message + "\n\nPuedes volver a abrir este asistente desde Ajustes de la skin.")
            return
        if choice == 10:
            _complete_missing_components(dialog)
            state = _read_state()
            _write_state(mark_step(state, options[choice], "REVIEWED"))
            continue
        _write_state(mark_step(state, options[choice], "IN_PROGRESS"))
        if choice in (0, 7):
            _show_status(dialog)
        if choice == 8:
            _home_diagnostic()
            dialog.ok("Diagnóstico de Home", "Se registró un resumen técnico sin títulos, rutas, nombres de cuenta ni credenciales. Si necesitas soporte, comparte las líneas HOME_DIAGNOSTIC de kodi.log.")
        elif choice == 1:
            _open_settings(dialog, "xstream")
        elif choice == 2:
            _open_settings(dialog, "pvr")
        elif choice == 3:
            _open_settings(dialog, "slyguy")
        elif choice == 4:
            _open_settings(dialog, "youtube")
        elif choice == 5:
            _open_settings(dialog, "trakt")
        elif choice == 6:
            intro_saved = _set_intro(dialog)
        else:
            intro_saved = False
        state = _read_state()
        state["last_step_index"] = choice
        result = ("REVIEWED" if choice in (0, 7, 8) else
                  "DONE" if choice == 6 and intro_saved else
                  "SKIPPED" if choice == 6 else "RETURNED")
        _write_state(mark_step(state, options[choice], result))


def main():
    dialog = xbmcgui.Dialog()
    action = sys.argv[1].strip().casefold() if len(sys.argv) > 1 else "wizard"
    args = [part.strip() for part in sys.argv[2:]]
    if action == "preview_focus":
        _auto_preview_focus(args)
    elif action == "preview_cancel":
        _auto_preview_cancel(args)
    elif action == "preview_manual":
        _auto_preview_preempt("MANUAL_DETAIL")
    elif action == "preview_spotlight":
        _auto_preview_preempt("MANUAL_SPOTLIGHT")
    elif action == "preview_vod":
        _auto_preview_preempt("VOD")
    elif action == "preview_exit":
        # Leaving a skin surface cancels its own preview work; it does not
        # imply that an unrelated/external player has taken ownership.
        _preview_notify("exit", {})
    elif action in ("first_run", "firstrun"):
        xbmc.log("[AcTweeteR] FIRST_RUN_FLOW status=entered", xbmc.LOGINFO)
        installed = _installed_addons()
        configured = False
        if installed.get("xstream"):
            try:
                configured = has_xtream_configuration(xbmcaddon.Addon(OPTIONAL_ADDONS["xstream"]))
            except Exception:
                configured = False
        state = _read_state()
        if should_offer_first_run(state, configured):
            if claim_process_session(_first_run_session_path(), os.getpid()):
                xbmc.log("[AcTweeteR] FIRST_RUN_WIZARD status=offered", xbmc.LOGINFO)
                _wizard(dialog, first_run=True)
            else:
                xbmc.log("[AcTweeteR] FIRST_RUN_WIZARD status=not_claimed",
                         xbmc.LOGINFO)
        else:
            reason = "prompted" if state.get("prompted") else "core_configured"
            xbmc.log("[AcTweeteR] FIRST_RUN_WIZARD status=skipped reason=%s" % reason,
                     xbmc.LOGINFO)
            missing = _missing_components()
            if should_offer_component_completion(state, missing, configured):
                # Persist before opening UI so repeated Home loads cannot stack
                # prompts. A declined offer remains available from Settings.
                _write_state(mark_component_offer_seen(state))
                required_missing = any(item in REQUIRED_REPAIR_SOURCES for item in missing)
                offer_text = (
                    "Esta actualización detectó dependencias declaradas de la skin que faltan, además de posibles servicios opcionales. ¿Abrir el asistente para pedir a Kodi que instale las dependencias desde repositorios autorizados? Puedes omitirlo, aunque algunas funciones de la skin podrían quedar incompletas."
                    if required_missing else
                    "Esta actualización puede ayudarte a instalar los complementos opcionales que faltan. No son necesarios para Home y no se configurarán automáticamente. ¿Abrir el asistente?"
                )
                if dialog.yesno(
                        "Revisión de complementos de AcTweeteR",
                        offer_text,
                        "Ahora no", "Abrir asistente"):
                    _wizard(dialog)
        _play_intro()
    elif action in ("services", "status"):
        _show_status(dialog)
    elif action == "intro":
        _play_intro()
    elif action == "intro_watchdog":
        _intro_watchdog()
    else:
        _wizard(dialog)


if __name__ == "__main__":
    main()
