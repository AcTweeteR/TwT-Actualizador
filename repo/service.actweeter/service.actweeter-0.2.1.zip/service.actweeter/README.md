# AcTweeteR Service

Private Kodi helper add-on used by AcTweeteR for search coordination,
first-run setup, service status, and preview lifecycle integration.

The service does not contain account credentials. IPTV, YouTube/OAuth, Trakt,
and provider settings remain in their respective Kodi add-ons. Status checks
are on demand and intentionally report configuration presence separately from
connectivity or playback validation.

SlyGuy Trailers is the preferred trailer provider when installed. YouTube and
OAuth remain optional for the SlyGuy trailer route; other add-on features may
have their own requirements. See the repository's private setup documentation
and third-party notices for scope and provenance.

This is a private development component, not a public installation or
distribution channel.
