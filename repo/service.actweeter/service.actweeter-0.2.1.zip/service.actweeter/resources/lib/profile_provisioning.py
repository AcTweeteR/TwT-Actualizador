"""Per-profile AcTweeteR provisioning with a strict private-settings allowlist."""

from __future__ import annotations

import json
import os
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any


PROVISIONING_SCHEMA = 1
PRIVATE_XSTREAM_SETTING_IDS = frozenset({
    "profile_1_enabled", "profile_1_name", "profile_1_source_type",
    "profile_1_xtream_url", "profile_1_xtream_username",
    "profile_1_xtream_password", "profile_1_epg_xtream",
    "profile_1_load_live", "profile_1_load_movies", "profile_1_load_series",
    "active_pvr_profile", "auto_sync_pvr",
})
REQUIRED_ADDONS = (
    "plugin.video.xstream-pro", "pvr.iptvsimple", "skin.actweeter",
)


class NeedsPrivateConfig(ValueError):
    """Master has no complete provider configuration to provision."""


def read_private_xstream_settings(master_settings: bytes) -> dict[str, str]:
    """Return only the one configured Xtream profile fields; never log them."""
    root = ET.fromstring(master_settings)
    if root.tag != "settings":
        raise NeedsPrivateConfig("unexpected private XStream settings format")
    result = {}
    for node in root.findall("setting"):
        setting_id = node.get("id")
        if setting_id in PRIVATE_XSTREAM_SETTING_IDS:
            result[setting_id] = (node.text or "").strip()
    required = (
        "profile_1_enabled", "profile_1_source_type", "profile_1_xtream_url",
        "profile_1_xtream_username", "profile_1_xtream_password",
    )
    source_type = result.get("profile_1_source_type", "").casefold()
    if (result.get("profile_1_enabled", "").casefold() != "true"
            or source_type not in {"xtream", "xtream codes"}
            or any(not result.get(key) for key in required[2:])):
        raise NeedsPrivateConfig("Master provider profile is incomplete")
    return result


def write_state(path: str | Path, state: dict[str, Any]) -> None:
    """Persist only non-secret provisioning status using atomic replacement."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = dict(state)
    payload["schema_version"] = PROVISIONING_SCHEMA
    fd, temporary = tempfile.mkstemp(prefix=".provision-", dir=str(target.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(payload, stream, sort_keys=True, separators=(",", ":"))
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, target)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def read_state(path: str | Path) -> dict[str, Any]:
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return {"schema_version": PROVISIONING_SCHEMA, "status": "UNPROVISIONED"}
    if not isinstance(value, dict) or value.get("schema_version") != PROVISIONING_SCHEMA:
        return {"schema_version": PROVISIONING_SCHEMA, "status": "UNPROVISIONED"}
    return value


def _jsonrpc(kodi, method: str, params: dict[str, Any]) -> dict[str, Any]:
    response = json.loads(kodi.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": method, "params": params,
    })))
    if "error" in response:
        raise RuntimeError("Kodi API rejected provisioning operation")
    return response.get("result", {})


def _enable_required_addons(kodi) -> None:
    for addon_id in REQUIRED_ADDONS:
        details = _jsonrpc(kodi, "Addons.GetAddonDetails",
                           {"addonid": addon_id, "properties": ["enabled"]})
        if not details.get("addon", {}).get("enabled", False):
            _jsonrpc(kodi, "Addons.SetAddonEnabled",
                     {"addonid": addon_id, "enabled": True})
            details = _jsonrpc(kodi, "Addons.GetAddonDetails",
                               {"addonid": addon_id, "properties": ["enabled"]})
        if not details.get("addon", {}).get("enabled", False):
            raise RuntimeError("required add-on did not become enabled")


def _apply_private_settings(addon, values: dict[str, str]) -> bool:
    """Apply allow-listed values and report whether XStream's profile changed."""
    getter = getattr(addon, "getSetting", None)
    changed = False
    for setting_id, value in values.items():
        if getter is None or getter(setting_id) != value:
            addon.setSetting(setting_id, value)
            changed = True
    return changed


def provision_active_consumer(kodi, addon_factory, vfs, addon_path: str,
                              *, structure_sync=None, run_plugin=None,
                              set_skin=None) -> str:
    """Provision only the currently active Consumer profile; safe to retry."""
    profile = _jsonrpc(kodi, "Profiles.GetCurrentProfile", {})
    profile_name = str(profile.get("label") or profile.get("name") or "")
    if profile_name.casefold() != "consumer":
        return "NOT_CONSUMER"

    profile_root = Path(vfs.translatePath("special://profile/"))
    state_path = profile_root / "addon_data" / "service.actweeter" / "provisioning.json"
    state = read_state(state_path)
    if state.get("status") == "PROVISIONED":
        # Reconcile a disabled required add-on and drifted provider settings,
        # but do not repeat first-run jobs on an unchanged profile.
        _enable_required_addons(kodi)
        master_settings = vfs.translatePath(
            "special://masterprofile/addon_data/plugin.video.xstream-pro/settings.xml"
        )
        private_settings = read_private_xstream_settings(Path(master_settings).read_bytes())
        xstream = addon_factory("plugin.video.xstream-pro")
        settings_changed = _apply_private_settings(xstream, private_settings)
        if set_skin is not None:
            set_skin("skin.actweeter")
        if settings_changed and run_plugin is not None:
            # Only changed private configuration warrants a provider/PVR
            # reconciliation. An ordinary service restart remains a no-op.
            run_plugin("plugin://plugin.video.xstream-pro/?mode=force_reload_pvr")
        if settings_changed:
            write_state(state_path, {**state, "settings_reconciled": True})
        return "ALREADY_PROVISIONED"
    write_state(state_path, {"status": "PROVISIONING", "profile": "Consumer"})
    try:
        master_settings = vfs.translatePath(
            "special://masterprofile/addon_data/plugin.video.xstream-pro/settings.xml"
        )
        private_settings = read_private_xstream_settings(Path(master_settings).read_bytes())
        write_state(state_path, {"status": "PROVISIONING", "profile": "Consumer",
                                 "stage": "ENABLE_ADDONS"})
        _enable_required_addons(kodi)

        xstream = addon_factory("plugin.video.xstream-pro")
        _apply_private_settings(xstream, private_settings)

        if structure_sync is not None:
            outcome = structure_sync(vfs, addon_path)
            if outcome.get("errors") or outcome.get("conflicts"):
                raise RuntimeError("structural sync reported a conflict or error")

        write_state(state_path, {"status": "PROVISIONING", "profile": "Consumer",
                                 "stage": "REQUEST_SEARCH_PVR"})
        if set_skin is not None:
            set_skin("skin.actweeter")
        if run_plugin is not None:
            # XStream performs its initial provider index/PVR initialization
            # when enabled. Do not start a second concurrent Search worker.
            run_plugin("plugin://plugin.video.xstream-pro/?mode=force_reload_pvr")

        write_state(state_path, {"status": "PROVISIONED", "profile": "Consumer",
                                 "version": 1, "private_config": "master_profile_provider1",
                                 "search_owner": "xstream_profile_initialization",
                                 "pvr_sync_requested": run_plugin is not None,
                                 "skin_requested": set_skin is not None})
        return "PROVISIONED"
    except (OSError, ET.ParseError, NeedsPrivateConfig) as exc:
        write_state(state_path, {"status": "NEEDS_PRIVATE_CONFIG",
                                 "error_type": type(exc).__name__})
        return "NEEDS_PRIVATE_CONFIG"
    except Exception as exc:
        write_state(state_path, {"status": "ERROR", "profile": "Consumer",
                                 "error_type": type(exc).__name__})
        raise
