"""Kodi service lifecycle and background refresh coordinator."""

from __future__ import annotations

import os
import time
import sys
import json
import base64
import uuid
import threading
from pathlib import Path

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
LIB_PATH = os.path.join(ADDON_PATH, "resources", "lib")
if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)

from search_background import (last_successful_sync, plugin_refresh_url,
                               RefreshGate, xstream_profile_number)  # noqa: E402
from profile_sync import profile_sync_targets, sync_profiles  # noqa: E402
from profile_provisioning import provision_active_consumer  # noqa: E402
from slyguy_trailer_return import (  # noqa: E402
    capture_context, identity_matches, parse_identity, return_decision,
    marker_cleanup_allowed, TerminalEventGate,
)
from kodi_auto_preview import KodiAutoPreviewCoordinator  # noqa: E402


_MONITOR_BASE = getattr(xbmc, "Monitor", object)
if isinstance(_MONITOR_BASE, type):
    class AcTweeteRMonitor(_MONITOR_BASE):
        def __init__(self, preview):
            super().__init__()
            self.preview = preview

        def onNotification(self, sender, method, data):
            if (sender in ("service.actweeter.SIGNAL", "slyguy.trailers.SIGNAL") or
                    method == "actweeter_auto_preview"):
                kind = type(data).__name__
                shape = "none"
                try:
                    parsed = json.loads(data) if isinstance(data, str) else data
                    shape = ("list:%d" % len(parsed) if isinstance(parsed, list) else
                             "dict" if isinstance(parsed, dict) else type(parsed).__name__)
                except (TypeError, ValueError):
                    shape = "invalid_json"
                xbmc.log("[AcTweeteR] AUTO_PREVIEW_NOTIFICATION sender=%s method=%s data_type=%s data_shape=%s" %
                         (sender, method, kind, shape), xbmc.LOGINFO)
            self.preview.on_notification(sender, method, data)
else:  # lightweight import harnesses may expose a factory rather than a class
    class AcTweeteRMonitor:
        def __new__(cls, preview):
            return xbmc.Monitor()


class _InactivePlayer:
    """Only for isolated imports that do not provide Kodi's Player API."""
    def getPlayingItem(self):
        raise RuntimeError("no player API in test harness")

    def stop(self):
        return None


def sync_structural_profiles(vfs, addon_path):
    """Reconcile the six versioned Skin Shortcuts files across Kodi profiles."""
    master_root = Path(vfs.translatePath("special://masterprofile/")).resolve()
    profiles_file = master_root / "profiles.xml"
    manifest_file = Path(addon_path) / "resources" / "structural_manifest.json"
    profiles_xml = profiles_file.read_bytes()
    manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
    if manifest.get("schema_version") != 1 or not isinstance(manifest.get("files"), list):
        raise ValueError("unsupported structural manifest")
    targets = profile_sync_targets(profiles_xml, master_root)
    state_path = (master_root / "addon_data" / "service.actweeter" /
                  "profile_sync_state.json")
    return sync_profiles(master_root, targets, manifest["files"], state_path=state_path)


def provision_current_profile(kodi, addon_factory, vfs, addon_path):
    """Consumer-only first-run provisioner; Master remains the private source."""
    def set_skin(skin_id):
        if kodi.getSkinDir() == skin_id:
            return
        response = json.loads(kodi.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Settings.SetSettingValue",
            "params": {"setting": "lookandfeel.skin", "value": skin_id},
        })))
        if "error" in response or response.get("result") is not True:
            raise RuntimeError("Kodi rejected active-profile skin selection")
        # Kodi deliberately presents a timed Yes/No confirmation after a skin
        # switch. Confirm only that exact native dialog; never send Select to
        # an arbitrary foreground window. Without this, a clean Consumer
        # silently falls back to Estuary when the confirmation expires.
        for _ in range(150):
            if kodi.getSkinDir() == skin_id and xbmcgui.getCurrentWindowDialogId() == 10100:
                kodi.executebuiltin("Action(Select)", False)
                for _ in range(20):
                    if (kodi.getSkinDir() == skin_id and
                            xbmcgui.getCurrentWindowDialogId() != 10100):
                        return
                    kodi.sleep(100)
                break
            if kodi.getSkinDir() == skin_id and xbmcgui.getCurrentWindowDialogId() != 10100:
                # Kodi may not require confirmation (for example after the
                # preference was already accepted in this profile).
                return
            kodi.sleep(100)
        if kodi.getSkinDir() != skin_id:
            raise RuntimeError("Kodi reverted the requested profile skin")
        if xbmcgui.getCurrentWindowDialogId() == 10100:
            raise RuntimeError("Kodi skin confirmation was not accepted")

    return provision_active_consumer(
        kodi, addon_factory, vfs, addon_path,
        run_plugin=lambda url: kodi.executebuiltin("RunPlugin(%s)" % url, False),
        set_skin=set_skin,
    )


def _window_id(kodi):
    """Read Kodi's active window ID without relying on translated labels."""
    try:
        response = json.loads(kodi.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "GUI.GetProperties",
            "params": {"properties": ["currentwindow"]},
        })))
        current = response.get("result", {}).get("currentwindow", {})
        value = current.get("id") if isinstance(current, dict) else None
        return value if type(value) is int else None
    except (TypeError, ValueError, AttributeError):
        return None


def _safe_int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _trailer_identity_values(kodi, spotlight=False):
    item = "Container(1508).ListItem." if spotlight else "ListItem."
    return {
        "imdb": kodi.getInfoLabel(item + "UniqueID(imdb)"),
        "tmdb": kodi.getInfoLabel(item + "UniqueID(tmdb)"),
        "dbid": kodi.getInfoLabel(item + "DBID"),
    }


_PLAYER_BASE = getattr(xbmc, "Player", object)


class SlyGuyTrailerReturnPlayer(_PLAYER_BASE):
    """Observe explicitly armed SlyGuy trailers from supported skin surfaces."""

    def __init__(self, kodi, monitor, auto_preview=None):
        super().__init__()
        self.kodi = kodi
        self.monitor = monitor
        self.lock = threading.Lock()
        self.context = None
        self.terminal_gate = TerminalEventGate()
        self.auto_preview = auto_preview
        self.auto_request_identity = ""
        self.auto_request_generation = ""
        self.auto_request_id = ""

    def _capture(self, *, allow_inactive=False):
        pending = self.kodi.getInfoLabel(
            "Window(Home).Property(SLYGUY_TRAILER_RETURN_PENDING)") == "1"
        explicit = self.kodi.getInfoLabel(
            "Window(Home).Property(SLYGUY_TRAILER_RETURN_REQUEST)") == "1"
        origin = self.kodi.getInfoLabel(
            "Window(Home).Property(SLYGUY_TRAILER_RETURN_ORIGIN)") or "VIDEO_INFO"
        source_window_id = _safe_int(self.kodi.getInfoLabel(
            "Window(Home).Property(SLYGUY_TRAILER_RETURN_WINDOW)"))
        return_control_id = _safe_int(self.kodi.getInfoLabel(
            "Window(Home).Property(SLYGUY_TRAILER_RETURN_CONTROL)"))
        vod_pending = bool(self.kodi.getInfoLabel(
            "Window(Home).Property(VOD_RETURN_PENDING)"))
        if not allow_inactive and not self.kodi.getCondVisibility("Player.HasVideo"):
            return None
        identity = self.kodi.getInfoLabel(
            "Window(Home).Property(SLYGUY_TRAILER_RETURN_ID)")
        identity_values = _trailer_identity_values(
            self.kodi, spotlight=origin.upper() == "SPOTLIGHT")
        if origin.upper() == "SPOTLIGHT":
            parsed = parse_identity(identity)
            # The stable identity was captured from Container(1508) before
            # SlyGuy took over the window. Revalidate it against the list on
            # return; the current playback window has no ListItem context.
            identity_values = ({parsed[0]: parsed[1]} if parsed else {})
        return capture_context(
            pending=pending, explicit_request=explicit, vod_pending=vod_pending,
            window_id=_window_id(self.kodi),
            item_type=(self.kodi.getInfoLabel(
                           "Window(Home).Property(SLYGUY_TRAILER_RETURN_TYPE)")
                       if origin.upper() == "SPOTLIGHT" else
                       self.kodi.getInfoLabel("ListItem.DBType")),
            identity=identity,
            current_values=identity_values,
            origin=origin,
            source_window_id=source_window_id,
            return_control_id=return_control_id,
        )

    def onAVStarted(self):
        if self.auto_preview is not None:
            try:
                item = self.getPlayingItem()
                owner = item.getProperty("AcTweeteR.PreviewOwner")
            except Exception:
                item = None
                owner = ""
            if owner == "AUTO_PREVIEW":
                self.auto_request_generation = item.getProperty(
                    "AcTweeteR.PreviewGeneration")
                self.auto_request_identity = item.getProperty(
                    "AcTweeteR.PreviewIdentity")
                self.auto_request_id = item.getProperty(
                    "AcTweeteR.PreviewRequestId")
                status = self.auto_preview.av_started(item)
                if status == "STALE_OWNED":
                    self.auto_preview.stop_stale_item(item)
                elif status == "ACCEPTED":
                    self.kodi.log("[AcTweeteR] AUTO_PREVIEW_AV_STARTED generation=%s" %
                                  self.auto_request_generation, self.kodi.LOGINFO)
                return
            manual_owner = self.kodi.getInfoLabel(
                "Window(Home).Property(SLYGUY_TRAILER_RETURN_ORIGIN)")
            if manual_owner in ("VIDEO_INFO", "SPOTLIGHT") and self.kodi.getInfoLabel(
                    "Window(Home).Property(SLYGUY_TRAILER_RETURN_PENDING)") == "1":
                self.auto_preview.external_playback_started(
                    "MANUAL_SPOTLIGHT" if manual_owner == "SPOTLIGHT" else "MANUAL_DETAIL")
            else:
                self.auto_preview.external_playback_started("OTHER")
            # Keep the displaced preview token until Kodi delivers its stop
            # callback; that callback owns its manifest cleanup even though a
            # manual/VOD item is now the active player.
        context = self._capture()
        if context is None:
            return
        with self.lock:
            if self.context is None:
                context["correlation_id"] = uuid.uuid4().hex[:12]
                self.context = context
                self.terminal_gate = TerminalEventGate()
                # DialogVideoInfo may unload after natural EOF once Kodi has
                # already made Player.HasVideo false. Let its XML cleanup
                # distinguish that terminal transition from a pre-play cancel.
                self.kodi.executebuiltin(
                    "SetProperty(SLYGUY_TRAILER_RETURN_PLAYBACK_STARTED,1,Home)",
                    False)
                self.kodi.log(
                    "[AcTweeteR] SLYGUY_RETURN_CAPTURED correlation=%s origin=%s identity_kind=%s return_window=%s return_control=%s" %
                    (context["correlation_id"], context["origin"],
                     context["identity_kind"], context["return_window_id"],
                     context.get("return_control_id", "none")),
                    self.kodi.LOGINFO)

    def onPlayBackStopped(self):
        self._terminal("stopped")

    def onPlayBackEnded(self):
        self._terminal("ended")

    def onPlayBackError(self):
        # Errors may happen before AVStarted; accept only the same explicit
        # request marker and matching movie detail identity.
        with self.lock:
            missing_context = self.context is None
        if missing_context:
            context = self._capture(allow_inactive=True)
            if context is not None:
                with self.lock:
                    if self.context is None:
                        context["correlation_id"] = uuid.uuid4().hex[:12]
                        self.context = context
                        self.terminal_gate = TerminalEventGate()
        self._terminal("error")

    def _terminal(self, event):
        if self.auto_preview is not None:
            # Timestamp Kodi's callback before touching Player APIs: those APIs
            # can wait on the playback lock and would obscure callback latency.
            self.auto_preview.player_terminal_event(event)
            try:
                item = self.getPlayingItem()
                owner = item.getProperty("AcTweeteR.PreviewOwner")
            except Exception:
                item = None
                owner = ""
            if owner == "AUTO_PREVIEW" and self.auto_preview.terminal(item, event):
                self.kodi.log("[AcTweeteR] AUTO_PREVIEW_TERMINAL event=%s" % event,
                              self.kodi.LOGINFO)
                self.auto_request_generation = ""
                self.auto_request_identity = ""
                self.auto_request_id = ""
                return
            if self.auto_request_generation:
                try:
                    generation = int(self.auto_request_generation)
                except (TypeError, ValueError):
                    generation = -1
                if generation > 0 and self.auto_preview.terminal_by_identity(
                        generation, self.auto_request_identity,
                        self.auto_request_id, event):
                    self.kodi.log("[AcTweeteR] AUTO_PREVIEW_TERMINAL event=%s" % event,
                                  self.kodi.LOGINFO)
                    self.auto_request_generation = ""
                    self.auto_request_identity = ""
                    self.auto_request_id = ""
                    return
            if not owner and not self.auto_request_generation:
                # Player.play() can be accepted without an AVStarted callback
                # (for example a resolver/player error). Release only the
                # exact AcTweeteR handoff previously acknowledged by the
                # provider; never Stop or claim this untagged playback.
                self.auto_preview.terminal_unowned_launch(event)
            self.auto_preview.external_playback_ended()
        with self.lock:
            if self.context is None or not self.terminal_gate.claim(event):
                return
            context = dict(self.context)
        correlation = context.get("correlation_id", "none")
        self.kodi.log(
            "[AcTweeteR] SLYGUY_RETURN_TERMINAL correlation=%s origin=%s event=%s" %
            (correlation, context.get("origin", "VIDEO_INFO"), event),
            self.kodi.LOGINFO)
        threading.Thread(target=self._restore, args=(context, event),
                         name="AcTweeteR-SlyGuyReturn", daemon=True).start()

    def _clear_markers(self, context, identity_verified=False):
        current = self.kodi.getInfoLabel(
            "Window(Home).Property(SLYGUY_TRAILER_RETURN_ID)")
        pending = self.kodi.getInfoLabel(
            "Window(Home).Property(SLYGUY_TRAILER_RETURN_PENDING)")
        request = self.kodi.getInfoLabel(
            "Window(Home).Property(SLYGUY_TRAILER_RETURN_REQUEST)")
        if not marker_cleanup_allowed(
                current, context["identity"],
                identity_verified=identity_verified,
                pending=bool(pending), explicit_request=bool(request)):
            return
        self.kodi.executebuiltin(
            "ClearProperty(SLYGUY_TRAILER_RETURN_PENDING,Home)", False)
        self.kodi.executebuiltin(
            "ClearProperty(SLYGUY_TRAILER_RETURN_ID,Home)", False)
        self.kodi.executebuiltin(
            "ClearProperty(SLYGUY_TRAILER_RETURN_REQUEST,Home)", False)
        self.kodi.executebuiltin(
            "ClearProperty(SLYGUY_TRAILER_RETURN_PLAYBACK_STARTED,Home)", False)
        self.kodi.executebuiltin(
            "ClearProperty(SLYGUY_TRAILER_RETURN_ORIGIN,Home)", False)
        self.kodi.executebuiltin(
            "ClearProperty(SLYGUY_TRAILER_RETURN_WINDOW,Home)", False)
        self.kodi.executebuiltin(
            "ClearProperty(SLYGUY_TRAILER_RETURN_CONTROL,Home)", False)
        self.kodi.executebuiltin(
            "ClearProperty(SLYGUY_TRAILER_RETURN_TYPE,Home)", False)
        if context.get("origin") == "SPOTLIGHT":
            self.kodi.executebuiltin("ClearProperty(KeepPlayingPreview,Home)", False)

    def _request_is_current(self, context):
        return (
            self.kodi.getInfoLabel(
                "Window(Home).Property(SLYGUY_TRAILER_RETURN_PENDING)") == "1" and
            self.kodi.getInfoLabel(
                "Window(Home).Property(SLYGUY_TRAILER_RETURN_REQUEST)") == "1" and
            self.kodi.getInfoLabel(
                "Window(Home).Property(SLYGUY_TRAILER_RETURN_ID)") == context["identity"] and
            (self.kodi.getInfoLabel(
                "Window(Home).Property(SLYGUY_TRAILER_RETURN_ORIGIN)") or
             "VIDEO_INFO").upper() == context.get("origin", "VIDEO_INFO")
        )

    def _current_identity_values(self, context):
        return _trailer_identity_values(
            self.kodi, spotlight=context.get("origin") == "SPOTLIGHT")

    def _restore(self, context, event):
        try:
            self._restore_context(context, event)
        except Exception as exc:
            self.kodi.log(
                "[AcTweeteR] SLYGUY_RETURN_RESULT=ERROR error_type=%s correlation=%s" %
                (type(exc).__name__, context.get("correlation_id", "none")),
                self.kodi.LOGERROR)
            try:
                self._clear_markers(context)
            except Exception:
                pass
            with self.lock:
                self.context = None

    def _restore_context(self, context, event):
        deadline = time.monotonic() + 8.0
        while not self.monitor.abortRequested() and time.monotonic() < deadline:
            if not self._request_is_current(context):
                self.kodi.log(
                    "[AcTweeteR] SLYGUY_RETURN_RESULT=REQUEST_NO_LONGER_CURRENT correlation=%s" %
                    context.get("correlation_id", "none"),
                    self.kodi.LOGINFO)
                with self.lock:
                    self.context = None
                return
            active = bool(self.kodi.getCondVisibility("Player.HasVideo"))
            window_id = _window_id(self.kodi)
            decision = return_decision(
                context, event=event, player_active=active,
                window_id=window_id,
                current_values=self._current_identity_values(context),
                control_focused=(
                    self.kodi.getCondVisibility("Control.HasFocus(1508)")
                    if context.get("origin") == "SPOTLIGHT" else False),
            )
            if decision == "preserve":
                self._clear_markers(context)
                with self.lock:
                    self.context = None
                self.kodi.log(
                    "[AcTweeteR] SLYGUY_RETURN_RESULT=DETAIL_PRESERVED correlation=%s" %
                    context.get("correlation_id", "none"), self.kodi.LOGINFO)
                return
            if decision == "focus_spotlight":
                # This guarded focus repair is limited to Home and only occurs
                # after the selected spotlight movie identity has matched.
                self.kodi.executebuiltin("SetFocus(1508)", False)
                deadline = time.monotonic() + 3.0
                while (not self.monitor.abortRequested() and
                       time.monotonic() < deadline):
                    if (_window_id(self.kodi) == 10000 and
                            self.kodi.getCondVisibility("Control.HasFocus(1508)") and
                            identity_matches(
                                context["identity"],
                                self._current_identity_values(context))):
                        self._clear_markers(context)
                        with self.lock:
                            self.context = None
                        self.kodi.log(
                            "[AcTweeteR] SLYGUY_RETURN_RESULT=SPOTLIGHT_RESTORED correlation=%s" %
                            context.get("correlation_id", "none"), self.kodi.LOGINFO)
                        return
                    time.sleep(0.1)
                break
            if decision == "restore":
                # Action(Info) is issued only after Kodi reports the Movies Hub
                # and the selected item's stable identity matches the capture.
                self.kodi.executebuiltin("Action(Info)", False)
                self.kodi.log(
                    "[AcTweeteR] SLYGUY_RETURN_INFO_ACTION=1 correlation=%s" %
                    context.get("correlation_id", "none"), self.kodi.LOGINFO)
                deadline = time.monotonic() + 8.0
                while (not self.monitor.abortRequested() and
                       time.monotonic() < deadline):
                    if (_window_id(self.kodi) == 12003 and
                            identity_matches(
                                context["identity"],
                                self._current_identity_values(context))):
                        self._clear_markers(context, identity_verified=True)
                        with self.lock:
                            self.context = None
                        self.kodi.log(
                            "[AcTweeteR] SLYGUY_RETURN_RESULT=DETAIL_RESTORED correlation=%s" %
                            context.get("correlation_id", "none"), self.kodi.LOGINFO)
                        return
                    time.sleep(0.1)
                break
            if decision == "abandon":
                self.kodi.log(
                    "[AcTweeteR] SLYGUY_RETURN_RESULT=IDENTITY_MISMATCH correlation=%s" %
                    context.get("correlation_id", "none"),
                    self.kodi.LOGWARNING)
                self._clear_markers(context)
                with self.lock:
                    self.context = None
                return
            time.sleep(0.1)

        self.kodi.log(
            "[AcTweeteR] SLYGUY_RETURN_RESULT=STATE_NOT_CONFIRMED correlation=%s" %
            context.get("correlation_id", "none"), self.kodi.LOGWARNING)
        self._clear_markers(context)
        with self.lock:
            self.context = None


def _run_coordinator(kodi, addon_factory, vfs, clock=time.time, structure_sync=None,
                     monitor=None):
    """Run one Kodi-owned coordinator loop; all provider I/O stays in XStream."""
    monitor = monitor or kodi.Monitor()
    refresh_gate = RefreshGate()
    service_started_at = clock()
    last_missing_addon_log = 0.0
    try:
        provision_status = provision_current_profile(
            kodi, addon_factory, vfs, ADDON_PATH
        )
        if provision_status not in ("NOT_CONSUMER", "ALREADY_PROVISIONED"):
            kodi.log("[AcTweeteR] PROFILE_PROVISIONING status=%s" % provision_status,
                     kodi.LOGINFO)
    except Exception as exc:
        kodi.log("[AcTweeteR] PROFILE_PROVISIONING status=ERROR error_type=%s" %
                 type(exc).__name__, kodi.LOGERROR)
    while not monitor.abortRequested():
        now = clock()
        if structure_sync is not None:
            try:
                outcome = structure_sync(vfs, ADDON_PATH)
                if outcome["files_updated"] or outcome["conflicts"] or outcome["errors"]:
                    kodi.log("[AcTweeteR] PROFILE_SYNC profiles=%d updated=%d conflicts=%d errors=%d" % (
                        outcome["profiles"], outcome["files_updated"],
                        outcome["conflicts"], outcome["errors"]), kodi.LOGINFO)
            except Exception as exc:
                kodi.log("[AcTweeteR] Profile structure sync unavailable error_type=%s" %
                         type(exc).__name__, kodi.LOGINFO)
        try:
            xstream = addon_factory("plugin.video.xstream-pro")
            xstream_profile = vfs.translatePath(xstream.getAddonInfo("profile"))
            profile_number = xstream_profile_number(xstream.getSetting("active_pvr_profile"))
            last_sync = last_successful_sync(xstream_profile, profile_number)
            # XStream builds a new profile's initial index during its own
            # startup. Give that bootstrap time to finish before this hourly
            # coordinator can request a stale/missing-index refresh.
            if last_sync <= 0 and now - service_started_at < 120:
                if monitor.waitForAbort(60):
                    break
                continue
            if refresh_gate.should_request(last_sync, now, abort=monitor.abortRequested()):
                # RunPlugin executes in Kodi's plugin runtime; this service only
                # schedules it and never reads provider settings or credentials.
                kodi.log("[AcTweeteR] SEARCH_REFRESH_START profile=%d" % profile_number,
                         kodi.LOGINFO)
                kodi.executebuiltin("RunPlugin(%s)" % plugin_refresh_url(profile_number), False)
                refresh_gate.mark_requested(now)
        except Exception as exc:
            # Add-on may be absent on a clean install before private provisioning.
            if now - last_missing_addon_log >= 3600:
                kodi.log("[AcTweeteR] Search refresh unavailable error_type=%s" %
                         type(exc).__name__, kodi.LOGINFO)
                last_missing_addon_log = now
        if monitor.waitForAbort(60):
            break


def _profile_kind(kodi):
    """Return a non-identifying profile class for lifecycle diagnostics."""
    try:
        response = json.loads(kodi.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Profiles.GetCurrentProfile",
            "params": {},
        })))
        label = str(response.get("result", {}).get("label", "")).casefold()
        if label == "consumer":
            return "consumer"
        if label:
            return "master"
    except Exception:
        pass
    return "unknown"


def _dispatch_auto_preview(kodi, request):
    """Signal the SlyGuy-owned worker without running provider I/O on Kodi UI."""
    encoded = base64.b64encode(json.dumps(
        request, separators=(",", ":")
    ).encode("utf-8")).decode("ascii")
    response = json.loads(kodi.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": "JSONRPC.NotifyAll",
        "params": {"sender": "service.actweeter.SIGNAL",
                   "message": "actweeter_auto_preview", "data": [encoded]},
    }, separators=(",", ":"))))
    if "error" in response:
        raise RuntimeError("Kodi notification transport rejected preview")


def run_service(kodi, addon_factory, vfs, clock=time.time, structure_sync=None):
    """Log one opaque lifecycle identity around the sole coordinator loop."""
    instance_id = uuid.uuid4().hex
    profile = _profile_kind(kodi)
    kodi.log("[AcTweeteR] SERVICE_INSTANCE_START profile=%s instance=%s" %
             (profile, instance_id), kodi.LOGINFO)
    kodi.log("[AcTweeteR] COORDINATOR_START profile=%s instance=%s" %
             (profile, instance_id), kodi.LOGINFO)
    player_factory = getattr(kodi, "Player", None)
    preview_player = player_factory() if player_factory else _InactivePlayer()
    auto_preview = KodiAutoPreviewCoordinator(
        kodi, preview_player,
        lambda request, item_data=None: _dispatch_auto_preview(kodi, request),
        vfs=vfs)
    kodi.log("[AcTweeteR] AUTO_PREVIEW_COORDINATOR status=started",
             kodi.LOGINFO)
    return_monitor = AcTweeteRMonitor(auto_preview)
    trailer_return_player = SlyGuyTrailerReturnPlayer(kodi, return_monitor,
                                                      auto_preview=auto_preview)
    try:
        return _run_coordinator(kodi, addon_factory, vfs, clock=clock,
                                structure_sync=structure_sync,
                                monitor=return_monitor)
    finally:
        auto_preview.close()
        kodi.log("[AcTweeteR] AUTO_PREVIEW_COORDINATOR status=stopped",
                 kodi.LOGINFO)
        kodi.log("[AcTweeteR] COORDINATOR_STOP profile=%s instance=%s" %
                 (profile, instance_id), kodi.LOGINFO)
        kodi.log("[AcTweeteR] SERVICE_INSTANCE_STOP profile=%s instance=%s" %
                 (profile, instance_id), kodi.LOGINFO)


run_service(xbmc, xbmcaddon.Addon, xbmcvfs,
            structure_sync=sync_structural_profiles)
