"""Kodi-native onboarding and on-demand service diagnostics.

All credentials remain in the official add-on settings screens. This UI only
checks whether required fields are present and displays non-sensitive status.
"""

from __future__ import annotations

import json
import os
import sys
import base64
import re
from urllib.parse import parse_qs, urlparse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
LIB_PATH = os.path.join(ADDON_PATH, "resources", "lib")
if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)

from first_run import (
    INTRO_OPTIONS, OPTIONAL_ADDONS, has_xtream_configuration, intro_mode_for_selection,
    claim_intro_for_process, load_state, mark_completed, mark_prompted, mark_step,
    save_state, service_rows, should_offer_first_run,
)


SETTINGS_ADDONS = {
    "xstream": "plugin.video.xstream-pro",
    "pvr": "pvr.iptvsimple",
    "slyguy": "slyguy.trailers",
    "youtube": "plugin.video.youtube",
    "trakt": "script.trakt",
}
METADATA_ADDONS = ("plugin.video.tmdb.bingie.helper",
                   "plugin.video.themoviedb.helper")


def _state_path():
    root = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    xbmcvfs.mkdirs(root)
    return os.path.join(root, "setup_state.json")


def _read_state():
    return load_state(_state_path())


def _write_state(state):
    save_state(_state_path(), state)


def _intro_session_path():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    xbmcvfs.mkdirs(profile)
    return os.path.join(profile, "intro_session.json")


def _addon_installed(addon_id):
    return bool(xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id))


def _installed_addons():
    installed = {key: _addon_installed(addon_id)
                 for key, addon_id in OPTIONAL_ADDONS.items() if key != "metadata"}
    installed["metadata"] = any(_addon_installed(addon_id)
                                for addon_id in METADATA_ADDONS)
    return installed


def _pvr_status():
    raw = xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": "PVR.GetProperties",
        "params": {"properties": ["available", "scanning"]},
    }))
    try:
        response = json.loads(raw)
        if "error" in response:
            return {"error": True, "available": False, "scanning": False}
        result = response.get("result", {})
        return {"error": False, "available": bool(result.get("available")),
                "scanning": bool(result.get("scanning"))}
    except (TypeError, ValueError):
        return {"error": True, "available": False, "scanning": False}


def _collect_status():
    installed = _installed_addons()
    configured = None
    if installed.get("xstream"):
        try:
            configured = has_xtream_configuration(xbmcaddon.Addon(OPTIONAL_ADDONS["xstream"]))
        except Exception:
            configured = False
    pvr = _pvr_status() if installed.get("pvr") else None
    return service_rows(installed, pvr=pvr, xstream_configured=configured)


def _show_status(dialog):
    rows = _collect_status()
    translated = {
        "CONFIGURED": "Datos presentes; conexión no probada",
        "SETUP_REQUIRED": "Requiere configuración",
        "INSTALLED_NOT_CHECKED": "Instalado; disponibilidad no comprobada",
        "INTEGRATION_NOT_CHECKED_NOW": "Integración incluida; proveedor no comprobado ahora",
        "DEPENDENCY_MISSING": "No disponible: falta SlyGuy Trailers",
        "NOT_REQUIRED_FOR_SLYGUY": "No necesario para trailers SlyGuy; OAuth no se comprobó",
        "OPTIONAL_MISSING": "Opcional; no instalado",
        "MISSING": "No instalado",
        "ERROR": "Kodi devolvió un error",
        "AVAILABLE": "Disponible en Kodi",
        "INITIALIZING_OR_UNAVAILABLE": "Inicializando o no disponible",
    }
    lines = ["%s: %s%s" % (
        row["service"], translated.get(row["status"], row["status"]),
        " (opcional)" if row["optional"] else ""
    ) for row in rows]
    lines.append("SlyGuy Trailers es el proveedor principal integrado; yt-dlp no requiere Google OAuth.")
    lines.append("YouTube y su OAuth son opcionales y los administra el complemento YouTube; no se leen tokens aquí.")
    lines.append("PVR disponible no confirma canales, EPG completa ni reproducción; compruébalos en Kodi.")
    dialog.textviewer("Estado de servicios de AcTweeteR", "\n".join(lines))


def _open_settings(dialog, key):
    addon_id = SETTINGS_ADDONS.get(key)
    if not addon_id:
        return
    if not _addon_installed(addon_id):
        dialog.ok("Complemento no instalado", "Kodi no encuentra ese complemento. No se ha instalado ni cambiado nada.")
        return
    # Kodi owns each add-on's official configuration UI and secret storage.
    xbmc.executebuiltin("Addon.OpenSettings(%s)" % addon_id, True)


def _set_intro(dialog):
    selected = dialog.select("Introducción", [label for label, _ in INTRO_OPTIONS])
    mode = intro_mode_for_selection(selected)
    if mode is None:
        return False
    xbmc.executebuiltin("Skin.SetString(splash_screen,%s)" % mode)
    return True


def _preview_notify(action, payload):
    encoded = base64.b64encode(json.dumps(
        {"action": action, **payload}, separators=(",", ":")
    ).encode("utf-8")).decode("ascii")
    request = {"jsonrpc": "2.0", "id": 1, "method": "JSONRPC.NotifyAll",
               "params": {"sender": "service.actweeter.SIGNAL",
                          "message": "actweeter_auto_preview", "data": [encoded]}}
    try:
        response = json.loads(xbmc.executeJSONRPC(
            json.dumps(request, separators=(",", ":"))))
        status = "accepted" if "error" not in response else "rejected"
    except Exception as exc:
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_SIGNAL action=%s status=error type=%s" %
                 (action, type(exc).__name__), xbmc.LOGWARNING)
        return False
    xbmc.log("[AcTweeteR] AUTO_PREVIEW_SIGNAL action=%s status=%s" %
             (action, status), xbmc.LOGINFO)
    return status == "accepted"


def _auto_preview_focus(args):
    if len(args) < 1:
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_FOCUS status=invalid_args", xbmc.LOGWARNING)
        return
    try:
        container = int(args[0])
        delay = float(args[1]) if len(args) > 1 else 3.0
        if container <= 0 or not (0.0 <= delay <= 60.0):
            xbmc.log("[AcTweeteR] AUTO_PREVIEW_FOCUS status=invalid_target", xbmc.LOGWARNING)
            return
        result = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "GUI.GetProperties",
            "params": {"properties": ["currentwindow"]},
        })))
        window = int(result["result"]["currentwindow"]["id"])
        focus = int(xbmcgui.Window(window).getFocusId())
        prefix = "Container(%d).ListItem." % container
        trailer = xbmc.getInfoLabel(prefix + "Trailer")
        trailer_id = ""
        try:
            parsed = urlparse(trailer)
            query = parse_qs(parsed.query)
            if parsed.hostname in ("youtube.com", "www.youtube.com", "m.youtube.com",
                                  "youtu.be", "plugin.video.youtube"):
                candidate = ((query.get("v") or query.get("video_id") or [""])[0]
                             if parsed.hostname != "youtu.be" else
                             parsed.path.strip("/"))
                if re.fullmatch(r"[A-Za-z0-9_-]{6,64}", candidate):
                    trailer_id = candidate
        except (TypeError, ValueError):
            trailer_id = ""
        payload = {
            "window": window,
            "container": container,
            "focus": focus,
            "position": int(xbmc.getInfoLabel("Container(%d).CurrentItem" % container) or "-1"),
            "media_type": xbmc.getInfoLabel(prefix + "DBType").lower(),
            "imdb": xbmc.getInfoLabel(prefix + "UniqueID(imdb)"),
            "tmdb": xbmc.getInfoLabel(prefix + "UniqueID(tmdb)"),
            "dbid": xbmc.getInfoLabel(prefix + "DBID"),
            "title": xbmc.getInfoLabel(prefix + "Title"),
            "year": xbmc.getInfoLabel(prefix + "Year"),
            "trailer_id": trailer_id,
            "delay": delay,
        }
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_FOCUS status=captured window=%d container=%d focus=%d media=%s identity=%s trailer=%s" %
                 (window, container, focus, payload["media_type"],
                  "present" if payload["imdb"] or payload["tmdb"] or payload["dbid"] else "missing",
                  "present" if trailer_id else "missing"), xbmc.LOGINFO)
        _preview_notify("focus", payload)
    except (KeyError, TypeError, ValueError):
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_FOCUS status=state_unavailable", xbmc.LOGWARNING)
        return
    except Exception as exc:
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_FOCUS status=error type=%s" %
                 type(exc).__name__, xbmc.LOGWARNING)
        return


def _auto_preview_cancel(args):
    try:
        container = int(args[0]) if args else 0
        payload = {}
        if container > 0:
            result = json.loads(xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0", "id": 1, "method": "GUI.GetProperties",
                "params": {"properties": ["currentwindow"]},
            })))
            window = int(result["result"]["currentwindow"]["id"])
            focus = int(xbmcgui.Window(window).getFocusId())
            prefix = "Container(%d).ListItem." % container
            payload = {
                "container": container, "window": window, "focus": focus,
                "position": int(xbmc.getInfoLabel(
                    "Container(%d).CurrentItem" % container) or "-1"),
                "media_type": xbmc.getInfoLabel(prefix + "DBType").lower(),
                "imdb": xbmc.getInfoLabel(prefix + "UniqueID(imdb)"),
                "tmdb": xbmc.getInfoLabel(prefix + "UniqueID(tmdb)"),
                "dbid": xbmc.getInfoLabel(prefix + "DBID"),
            }
        _preview_notify("cancel", payload)
    except (TypeError, ValueError):
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_CANCEL status=state_unavailable", xbmc.LOGWARNING)
        return
    except Exception as exc:
        xbmc.log("[AcTweeteR] AUTO_PREVIEW_CANCEL status=error type=%s" %
                 type(exc).__name__, xbmc.LOGWARNING)
        return


def _auto_preview_preempt(owner):
    if owner in ("MANUAL_DETAIL", "MANUAL_SPOTLIGHT", "VOD", "OTHER"):
        _preview_notify("preempt", {"owner": owner})


def _play_intro():
    """Open the existing skin mask once per Kodi process for AcTweeteR modes."""
    mode = xbmc.getInfoLabel("Skin.String(splash_screen)")
    if mode not in ("actweeter_video", "actweeter_image"):
        return
    session_path = _intro_session_path()
    if not claim_intro_for_process(session_path, os.getpid()):
        xbmc.log("[AcTweeteR] INTRO_SESSION_GUARD status=already_claimed",
                 xbmc.LOGINFO)
        return
    if not os.path.isfile(session_path):
        xbmc.log("[AcTweeteR] INTRO_SESSION_GUARD status=persistence_unavailable",
                 xbmc.LOGWARNING)
    else:
        xbmc.log("[AcTweeteR] INTRO_SESSION_GUARD status=claimed",
                 xbmc.LOGINFO)
    # Claim before inspecting playback: on startup the mask/player can become
    # active before this Home onload script runs. That must still consume the
    # process-wide attempt, or a later Home activation can replay the intro.
    if xbmc.getCondVisibility("Player.HasMedia"):
        return
    xbmc.executebuiltin("SetProperty(AcTweeteRIntroShown,1,Home)")
    xbmc.executebuiltin("SetProperty(StartupMask,1,Home)")
    xbmc.executebuiltin("ActivateWindow(1103)")


def _wizard(dialog, *, first_run=False):
    if first_run:
        answer = dialog.yesno(
            "Configuración inicial de AcTweeteR",
            "XStream configura el catálogo IPTV. SlyGuy Trailers es el proveedor principal opcional para trailers y no necesita Google OAuth.\n"
            "YouTube, su OAuth, PVR y Trakt son opcionales según las funciones que quieras usar.\n"
            "Las contraseñas se introducen únicamente en los ajustes oficiales; AcTweeteR no las copia.\n\n¿Quieres empezar ahora?",
            "Ahora no", "Empezar",
        )
        state = _read_state()
        _write_state(mark_prompted(state))
        if not answer:
            return

    options = [
        "Comprobar componentes",
        "Configurar IPTV / XStream",
        "Configurar TV / PVR",
        "Configurar SlyGuy Trailers (opcional)",
        "Configurar YouTube (opcional)",
        "Vincular Trakt (opcional)",
        "Elegir introducción",
        "Ver estado de servicios",
        "Finalizar",
    ]
    while True:
        state = _read_state()
        start_at = int(state.get("last_step_index", 0)) if str(state.get("last_step_index", "0")).isdigit() else 0
        choice = dialog.select("Configuración inicial de AcTweeteR", options,
                               preselect=min(start_at, len(options) - 1))
        if choice < 0:
            break
        if choice == 8:
            installed = {key: _addon_installed(addon_id)
                         for key, addon_id in OPTIONAL_ADDONS.items()}
            core_configured = False
            if installed.get("xstream"):
                try:
                    core_configured = has_xtream_configuration(
                        xbmcaddon.Addon(OPTIONAL_ADDONS["xstream"]))
                except Exception:
                    core_configured = False
            # Presence of settings is not a provider connectivity/playback test.
            status = "PARTIALLY_CONFIGURED" if core_configured else "CONFIGURATION_REQUIRED"
            _write_state(mark_completed(state, status))
            final_message = (
                "Hay datos básicos de XStream, pero esta comprobación no ha probado el proveedor. "
                "Revisa Estado de servicios si el catálogo no carga."
                if core_configured else
                "La configuración principal sigue pendiente. Puedes continuar con Kodi y volver a este asistente desde Ajustes."
            )
            dialog.ok("AcTweeteR", final_message + "\n\nPuedes volver a abrir este asistente desde Ajustes de la skin.")
            return
        _write_state(mark_step(state, options[choice], "IN_PROGRESS"))
        if choice in (0, 7):
            _show_status(dialog)
        elif choice == 1:
            _open_settings(dialog, "xstream")
        elif choice == 2:
            _open_settings(dialog, "pvr")
        elif choice == 3:
            _open_settings(dialog, "slyguy")
        elif choice == 4:
            _open_settings(dialog, "youtube")
        elif choice == 5:
            _open_settings(dialog, "trakt")
        elif choice == 6:
            intro_saved = _set_intro(dialog)
        else:
            intro_saved = False
        state = _read_state()
        state["last_step_index"] = choice
        result = ("REVIEWED" if choice in (0, 7) else
                  "DONE" if choice == 6 and intro_saved else
                  "SKIPPED" if choice == 6 else "RETURNED")
        _write_state(mark_step(state, options[choice], result))


def main():
    dialog = xbmcgui.Dialog()
    action = sys.argv[1].strip().casefold() if len(sys.argv) > 1 else "wizard"
    args = [part.strip() for part in sys.argv[2:]]
    if action == "preview_focus":
        _auto_preview_focus(args)
    elif action == "preview_cancel":
        _auto_preview_cancel(args)
    elif action == "preview_manual":
        _auto_preview_preempt("MANUAL_DETAIL")
    elif action == "preview_spotlight":
        _auto_preview_preempt("MANUAL_SPOTLIGHT")
    elif action == "preview_vod":
        _auto_preview_preempt("VOD")
    elif action == "preview_exit":
        # Leaving a skin surface cancels its own preview work; it does not
        # imply that an unrelated/external player has taken ownership.
        _preview_notify("exit", {})
    elif action in ("first_run", "firstrun"):
        installed = _installed_addons()
        configured = False
        if installed.get("xstream"):
            try:
                configured = has_xtream_configuration(xbmcaddon.Addon(OPTIONAL_ADDONS["xstream"]))
            except Exception:
                configured = False
        state = _read_state()
        if should_offer_first_run(state, configured):
            _wizard(dialog, first_run=True)
        _play_intro()
    elif action in ("services", "status"):
        _show_status(dialog)
    elif action == "intro":
        _play_intro()
    else:
        _wizard(dialog)


if __name__ == "__main__":
    main()
