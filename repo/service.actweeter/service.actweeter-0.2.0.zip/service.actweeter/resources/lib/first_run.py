"""Secret-free first-run and service-status primitives for AcTweeteR."""

from __future__ import annotations

import json
import os
from pathlib import Path


WIZARD_STEPS = (
    "Comprobar componentes",
    "Configurar IPTV / XStream",
    "Configurar TV / PVR",
    "Configurar SlyGuy Trailers (opcional)",
    "Configurar YouTube (opcional)",
    "Vincular Trakt (opcional)",
    "Elegir introducción",
    "Ver estado de servicios",
)
INTRO_OPTIONS = (
    ("Vídeo AcTweeteR", "actweeter_video"),
    ("Imagen AcTweeteR", "actweeter_image"),
    ("Sin introducción", "none"),
)
STEP_STATUSES = {"IN_PROGRESS", "RETURNED", "REVIEWED", "DONE", "SKIPPED"}

OPTIONAL_ADDONS = {
    "xstream": "plugin.video.xstream-pro",
    "pvr": "pvr.iptvsimple",
    "slyguy": "slyguy.trailers",
    "youtube": "plugin.video.youtube",
    "trakt": "script.trakt",
    "metadata": "plugin.video.tmdb.bingie.helper",
}


def has_xtream_configuration(addon):
    """Check presence only; never return, persist, or log credential values."""
    try:
        profile = addon.getSetting("active_pvr_profile") or "Profile 1"
        digits = "".join(char for char in profile if char.isdigit())
        number = int(digits or "1")
        if not 1 <= number <= 10:
            return False
        prefix = "profile_%d_" % number
        return (
            addon.getSetting(prefix + "enabled").casefold() == "true"
            and all(addon.getSetting(prefix + key).strip()
                    for key in ("xtream_url", "xtream_username", "xtream_password"))
        )
    except Exception:
        return False


def service_rows(installed, pvr=None, xstream_configured=None):
    """Return safe UI rows; values contain status only, never provider data."""
    installed = installed or {}
    rows = []
    for key, label, optional in (
        ("xstream", "IPTV / XStream", False),
        ("pvr", "TV / PVR", True),
        ("slyguy", "SlyGuy Trailers", True),
        ("youtube", "YouTube", True),
        ("trakt", "Trakt", True),
        ("metadata", "Metadatos (dependencia de skin)", False),
    ):
        present = bool(installed.get(key, False))
        status = "INSTALLED_NOT_CHECKED" if present else ("OPTIONAL_MISSING" if optional else "MISSING")
        if key == "xstream" and present and xstream_configured is not None:
            status = "CONFIGURED" if xstream_configured else "SETUP_REQUIRED"
        if key == "pvr" and present and pvr is not None:
            if pvr.get("error"):
                status = "ERROR"
            elif pvr.get("scanning"):
                status = "INITIALIZING_OR_UNAVAILABLE"
            elif pvr.get("available"):
                status = "AVAILABLE"
            else:
                status = "INITIALIZING_OR_UNAVAILABLE"
        rows.append({"service": label, "status": status, "optional": optional})
    slyguy_present = bool(installed.get("slyguy", False))
    rows.append({
        "service": "Previews automáticos",
        "status": "INTEGRATION_NOT_CHECKED_NOW" if slyguy_present else "DEPENDENCY_MISSING",
        "optional": True,
    })
    rows.append({
        "service": "OAuth Google",
        "status": "NOT_REQUIRED_FOR_SLYGUY",
        "optional": True,
    })
    return rows


def should_offer_first_run(state, core_configured):
    """Offer onboarding once only when the core provider is not configured."""
    state = state or {}
    return not bool(state.get("prompted")) and not bool(core_configured)


def intro_mode_for_selection(selection):
    """Map a Kodi dialog index to a supported mode; cancellation is no choice."""
    if type(selection) is not int or not 0 <= selection < len(INTRO_OPTIONS):
        return None
    return INTRO_OPTIONS[selection][1]


def claim_intro_for_process(path, process_id):
    """Claim the intro once per Kodi process, including across Home reloads."""
    if isinstance(process_id, bool) or not isinstance(process_id, int) or process_id <= 0:
        return False
    destination = Path(path)
    try:
        previous = json.loads(destination.read_text(encoding="utf-8"))
        if (isinstance(previous, dict) and previous.get("schema_version") == 1 and
                previous.get("process_id") == process_id):
            return False
    except (OSError, ValueError, TypeError):
        pass

    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.name + ".tmp-" + str(process_id))
    try:
        with temporary.open("w", encoding="utf-8") as handle:
            json.dump({"schema_version": 1, "process_id": process_id}, handle)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, destination)
    except OSError:
        try:
            temporary.unlink()
        except OSError:
            pass
        # Fail open: a filesystem problem must not prevent the intro.
    return True


def normalize_state(state):
    """Reject malformed or unsupported wizard state without interrupting Kodi."""
    if not isinstance(state, dict) or state.get("schema_version") != 1:
        return {}
    result = {"schema_version": 1, "wizard_version": 1}
    for key in ("prompted", "completed"):
        if isinstance(state.get(key), bool):
            result[key] = state[key]
    if state.get("last_step") in WIZARD_STEPS:
        result["last_step"] = state["last_step"]
    index = state.get("last_step_index")
    if isinstance(index, int) and not isinstance(index, bool) and 0 <= index < len(WIZARD_STEPS):
        result["last_step_index"] = index
    raw_steps = state.get("step_status")
    if isinstance(raw_steps, dict):
        result["step_status"] = {
            key: value for key, value in raw_steps.items()
            if key in WIZARD_STEPS and isinstance(value, str) and value in STEP_STATUSES
        }
    else:
        result["step_status"] = {}
    config_status = state.get("configuration_status")
    if config_status in ("CORE_READY", "PARTIALLY_CONFIGURED", "CONFIGURATION_REQUIRED"):
        result["configuration_status"] = config_status
    return result


def load_state(path):
    try:
        with Path(path).open("r", encoding="utf-8") as handle:
            return normalize_state(json.load(handle))
    except (OSError, ValueError, TypeError):
        return {}


def save_state(path, state):
    """Atomically persist only allowlisted, non-secret wizard state."""
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.name + ".tmp")
    sanitized = normalize_state(state)
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(sanitized, handle, sort_keys=True)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, destination)
    return sanitized


def mark_prompted(state):
    result = normalize_state(state)
    result.update({"schema_version": 1, "wizard_version": 1, "prompted": True})
    return result


def mark_step(state, step, status):
    result = normalize_state(state)
    if not isinstance(step, str) or step not in WIZARD_STEPS:
        return result
    if not isinstance(status, str) or status not in STEP_STATUSES:
        return result
    result.update({"schema_version": 1, "wizard_version": 1, "last_step": step})
    steps = dict(result.get("step_status", {}))
    steps[str(step)] = str(status)
    result["step_status"] = steps
    return result


def mark_completed(state, configuration_status=None):
    result = normalize_state(state)
    result.update({"schema_version": 1, "wizard_version": 1,
                   "prompted": True, "completed": True})
    if configuration_status in ("CORE_READY", "PARTIALLY_CONFIGURED", "CONFIGURATION_REQUIRED"):
        result["configuration_status"] = configuration_status
    return result
