"""Secret-free first-run and service-status primitives for AcTweeteR."""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path


WIZARD_STEPS = (
    "Comprobar componentes",
    "Configurar IPTV / XStream",
    "Configurar TV / PVR",
    "Configurar SlyGuy Trailers (opcional)",
    "Configurar YouTube (opcional)",
    "Vincular Trakt (opcional)",
    "Elegir introducción",
    "Ver estado de servicios",
    "Diagnosticar Home (sin datos personales)",
)
INTRO_OPTIONS = (
    ("Vídeo AcTweeteR", "actweeter_video"),
    ("Imagen AcTweeteR", "actweeter_image"),
    ("Sin introducción", "none"),
)
STEP_STATUSES = {"IN_PROGRESS", "RETURNED", "REVIEWED", "DONE", "SKIPPED"}
WIZARD_VERSION = 2

OPTIONAL_ADDONS = {
    "xstream": "plugin.video.xstream-pro",
    "pvr": "pvr.iptvsimple",
    "slyguy": "slyguy.trailers",
    "youtube": "plugin.video.youtube",
    "trakt": "script.trakt",
    "metadata": "plugin.video.tmdb.bingie.helper",
}
REQUIRED_ADDON_IDS = (
    "service.actweeter",
    "script.bingie.helper",
    "script.bingie.toolbox",
    "script.bingie.widgets",
    "script.skinshortcuts",
    "resource.images.studios.coloured",
    "plugin.video.tmdb.bingie.helper",
    "plugin.program.autocompletion",
)

# Kodi installs an add-on only from repositories already present and enabled
# on that installation. XStream Pro is intentionally excluded: its private or
# provider-specific source is not a product-managed repository.
OPTIONAL_ADDON_SOURCES = {
    "pvr": "repository.xbmc.org",
    "slyguy": "repository.slyguy",
    "youtube": "repository.xbmc.org",
    "trakt": "repository.xbmc.org",
}


def optional_addon_action(key, addon_installed, source_installed):
    """Choose a safe wizard action without attempting an absent add-on."""
    addon_id = OPTIONAL_ADDONS.get(key)
    if not addon_id or key == "metadata":
        return "UNSUPPORTED"
    if addon_installed:
        return "CONFIGURE"
    source_id = OPTIONAL_ADDON_SOURCES.get(key)
    if not source_id:
        return "SOURCE_REQUIRED"
    if not source_installed:
        return "REPOSITORY_REQUIRED"
    return "OFFER_INSTALL"


def home_diagnostic_snapshot(*, window_id, focus_id, menu_visible,
                             widgets_count, widgets_updating, startup_mask,
                             intro_playback, missing_required_count):
    """Allowlist non-personal Home health fields for one-shot diagnostics."""
    def safe_int(value):
        try:
            number = int(value)
            return number if number >= 0 else -1
        except (TypeError, ValueError):
            return -1

    def safe_bool(value):
        if isinstance(value, str):
            return value.strip().casefold() in ("1", "true", "yes", "on")
        return bool(value)

    return {
        "window_id": safe_int(window_id),
        "focus_id": safe_int(focus_id),
        "menu_visible": safe_bool(menu_visible),
        "widgets_count": safe_int(widgets_count),
        "widgets_updating": safe_bool(widgets_updating),
        "startup_mask": safe_bool(startup_mask),
        "intro_playback": safe_bool(intro_playback),
        "missing_required_count": safe_int(missing_required_count),
    }


def has_xtream_configuration(addon):
    """Check presence only; never return, persist, or log credential values."""
    try:
        profile = addon.getSetting("active_pvr_profile") or "Profile 1"
        digits = "".join(char for char in profile if char.isdigit())
        number = int(digits or "1")
        if not 1 <= number <= 10:
            return False
        prefix = "profile_%d_" % number
        return (
            addon.getSetting(prefix + "enabled").casefold() == "true"
            and all(addon.getSetting(prefix + key).strip()
                    for key in ("xtream_url", "xtream_username", "xtream_password"))
        )
    except Exception:
        return False


def service_rows(installed, pvr=None, xstream_configured=None):
    """Return safe UI rows; values contain status only, never provider data."""
    installed = installed or {}
    rows = []
    required_present = bool(installed.get("required", False))
    rows.append({
        "service": "Componentes obligatorios de AcTweeteR",
        "status": "AVAILABLE" if required_present else "MISSING",
        "optional": False,
    })
    for key, label, optional in (
        ("xstream", "IPTV / XStream", False),
        ("pvr", "TV / PVR", True),
        ("slyguy", "SlyGuy Trailers", True),
        ("youtube", "YouTube", True),
        ("trakt", "Trakt", True),
        ("metadata", "Metadatos (dependencia de skin)", False),
    ):
        present = bool(installed.get(key, False))
        status = "INSTALLED_NOT_CHECKED" if present else ("OPTIONAL_MISSING" if optional else "MISSING")
        if key == "xstream" and present and xstream_configured is not None:
            status = "CONFIGURED" if xstream_configured else "SETUP_REQUIRED"
        if key == "pvr" and present and pvr is not None:
            if pvr.get("error"):
                status = "ERROR"
            elif pvr.get("scanning"):
                status = "INITIALIZING_OR_UNAVAILABLE"
            elif pvr.get("available"):
                status = "AVAILABLE"
            else:
                status = "INITIALIZING_OR_UNAVAILABLE"
        rows.append({"service": label, "status": status, "optional": optional})
    slyguy_present = bool(installed.get("slyguy", False))
    rows.append({
        "service": "Previews automáticos",
        "status": "INTEGRATION_NOT_CHECKED_NOW" if slyguy_present else "DEPENDENCY_MISSING",
        "optional": True,
    })
    rows.append({
        "service": "OAuth Google",
        "status": "NOT_REQUIRED_FOR_SLYGUY",
        "optional": True,
    })
    return rows


def should_offer_first_run(state, core_configured):
    """Offer incomplete onboarding, migrating ambiguous v1 prompts once."""
    state = state or {}
    if core_configured or state.get("completed"):
        return False
    # v1 set ``prompted`` before the user completed an accepted wizard. Re-offer
    # that ambiguous legacy state once; v2 distinguishes explicit deferral.
    if state.get("prompted") and state.get("wizard_version", 1) >= WIZARD_VERSION:
        return False
    return True


def intro_mode_for_selection(selection):
    """Map a Kodi dialog index to a supported mode; cancellation is no choice."""
    if type(selection) is not int or not 0 <= selection < len(INTRO_OPTIONS):
        return None
    return INTRO_OPTIONS[selection][1]


def claim_process_session(path, process_id):
    """Atomically claim one process-scoped startup action across Home loads.

    Failure to persist is fail-closed: skipping a cosmetic intro is safer than
    starting it twice or leaving a second modal over the Home screen.
    """
    if isinstance(process_id, bool) or not isinstance(process_id, int) or process_id <= 0:
        return False
    destination = Path(path)
    lock = destination.with_name(destination.name + ".claim-" + str(process_id))
    lock_fd = None
    temporary = None
    try:
        destination.parent.mkdir(parents=True, exist_ok=True)
        lock_fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except (FileExistsError, OSError):
        return False

    try:
        try:
            previous = json.loads(destination.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError):
            previous = None
        if (isinstance(previous, dict) and previous.get("schema_version") == 1 and
                previous.get("process_id") == process_id):
            return False

        descriptor, temporary_name = tempfile.mkstemp(
            prefix=destination.name + ".tmp-", dir=str(destination.parent))
        temporary = Path(temporary_name)
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump({"schema_version": 1, "process_id": process_id}, handle)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, destination)
    except OSError:
        return False
    finally:
        if lock_fd is not None:
            os.close(lock_fd)
        for transient in (temporary, lock):
            if transient is not None:
                try:
                    transient.unlink()
                except OSError:
                    pass
    return True


def claim_intro_for_process(path, process_id):
    """Compatibility name for the process-scoped intro claim."""
    return claim_process_session(path, process_id)


def normalize_state(state):
    """Reject malformed or unsupported wizard state without interrupting Kodi."""
    if not isinstance(state, dict) or state.get("schema_version") != 1:
        return {}
    result = {"schema_version": 1, "wizard_version": 1}
    version = state.get("wizard_version")
    if isinstance(version, int) and not isinstance(version, bool) and version in (1, WIZARD_VERSION):
        result["wizard_version"] = version
    for key in ("prompted", "completed", "started"):
        if isinstance(state.get(key), bool):
            result[key] = state[key]
    if state.get("last_step") in WIZARD_STEPS:
        result["last_step"] = state["last_step"]
    index = state.get("last_step_index")
    if isinstance(index, int) and not isinstance(index, bool) and 0 <= index < len(WIZARD_STEPS):
        result["last_step_index"] = index
    raw_steps = state.get("step_status")
    if isinstance(raw_steps, dict):
        result["step_status"] = {
            key: value for key, value in raw_steps.items()
            if key in WIZARD_STEPS and isinstance(value, str) and value in STEP_STATUSES
        }
    else:
        result["step_status"] = {}
    config_status = state.get("configuration_status")
    if config_status in ("CORE_READY", "PARTIALLY_CONFIGURED", "CONFIGURATION_REQUIRED"):
        result["configuration_status"] = config_status
    return result


def load_state(path):
    try:
        with Path(path).open("r", encoding="utf-8") as handle:
            return normalize_state(json.load(handle))
    except (OSError, ValueError, TypeError):
        return {}


def save_state(path, state):
    """Atomically persist only allowlisted, non-secret wizard state."""
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.name + ".tmp")
    sanitized = normalize_state(state)
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(sanitized, handle, sort_keys=True)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, destination)
    return sanitized


def mark_prompted(state):
    result = normalize_state(state)
    result.update({"schema_version": 1, "wizard_version": WIZARD_VERSION, "prompted": True})
    return result


def mark_started(state):
    result = normalize_state(state)
    result.update({"schema_version": 1, "wizard_version": WIZARD_VERSION,
                   "prompted": False, "started": True})
    return result


def mark_step(state, step, status):
    result = normalize_state(state)
    if not isinstance(step, str) or step not in WIZARD_STEPS:
        return result
    if not isinstance(status, str) or status not in STEP_STATUSES:
        return result
    result.update({"schema_version": 1, "wizard_version": WIZARD_VERSION, "last_step": step})
    steps = dict(result.get("step_status", {}))
    steps[str(step)] = str(status)
    result["step_status"] = steps
    return result


def mark_completed(state, configuration_status=None):
    result = normalize_state(state)
    result.update({"schema_version": 1, "wizard_version": WIZARD_VERSION,
                   "prompted": True, "completed": True})
    if configuration_status in ("CORE_READY", "PARTIALLY_CONFIGURED", "CONFIGURATION_REQUIRED"):
        result["configuration_status"] = configuration_status
    return result
