# -*- coding: utf-8 -*-
import os
import sys
import datetime
import xbmcaddon
import xbmcvfs

import xbmc


ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
LIB_DIR = os.path.join(ADDON_DIR, "resources", "lib")
if LIB_DIR not in sys.path:
    sys.path.insert(0, LIB_DIR)


try:
    from pvr_epg_guard import repair_pvr_epg_files

    repair_pvr_epg_files()
except Exception as exc:
    xbmc.log("[Xstream Pro] EPG guard service failed: {0}".format(exc), xbmc.LOGWARNING)


try:
    from pvr_group_memory import remember_current_pvr_group
except Exception as exc:
    remember_current_pvr_group = None
    xbmc.log("[Xstream Pro] PVR group memory service unavailable: {0}".format(exc), xbmc.LOGWARNING)


monitor = xbmc.Monitor()
try:
    from recent_tv_native import RecentTV
    recent_tv = RecentTV(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')), xbmc)
except Exception:
    recent_tv = None
    xbmc.log('[Xstream Pro] Recent TV service unavailable', xbmc.LOGWARNING)
last_year_check = None
resume_signature = None
resume_path = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')), 'resume_points_p1.json')
while not monitor.abortRequested():
    if recent_tv is not None:
        try:
            recent_tv.tick()
        except Exception:
            xbmc.log('[Xstream Pro] Recent TV polling warning', xbmc.LOGWARNING)
    now = datetime.datetime.now()
    year_key = (now.year, now.day)
    if year_key != last_year_check:
        xbmc.executebuiltin("SetProperty(Premium.PreviousYear,{0},home)".format(now.year - 1))
        last_year_check = year_key
    try:
        stat = os.stat(resume_path)
        signature = (stat.st_mtime_ns, stat.st_size)
    except OSError:
        signature = (0, 0)
    if signature != resume_signature:
        xbmc.executebuiltin('SetProperty(Premium.ContinueRefresh,{0},home)'.format(signature[0]))
        resume_signature = signature
    if remember_current_pvr_group is not None:
        try:
            remember_current_pvr_group()
        except Exception as exc:
            xbmc.log("[Xstream Pro] PVR group memory service warning: {0}".format(exc), xbmc.LOGWARNING)
    if monitor.waitForAbort(1.0):
        break
