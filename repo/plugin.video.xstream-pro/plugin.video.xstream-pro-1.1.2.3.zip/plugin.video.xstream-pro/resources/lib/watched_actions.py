"""Thin testable dispatch for XStream's existing watched toggle."""


def toggle_tmdb_watched(g, args):
    """Run the same profile-scoped XStream watched toggle used by its route."""
    tmdb_id = args.get("tmdb_id", [""])[0]
    tmdb_type = args.get("tmdb_type", [""])[0]
    season = args.get("season", [""])[0]
    episode = args.get("episode", [""])[0]
    profile = g["pm"].active
    profile_num = int(profile) if profile and str(profile).isdigit() else 1
    state = None

    if tmdb_id and tmdb_type == "movie":
        store = g["WatchedMovies"](g["addon"], profile_num=profile_num)
        if store.is_watched(tmdb_id):
            store.mark_unwatched(tmdb_id)
            g["xbmcgui"].Dialog().notification("Xstream Pro", g["_t"](31121))
            state = False
        else:
            store.mark_watched(tmdb_id)
            g["xbmcgui"].Dialog().notification("Xstream Pro", g["_t"](31120))
            state = True
    elif tmdb_id and tmdb_type == "tv" and season and episode:
        store = g["WatchedEpisodes"](g["addon"], profile_num=profile_num)
        if store.is_watched(tmdb_id, season, episode):
            store.mark_unwatched(tmdb_id, season, episode)
            g["xbmcgui"].Dialog().notification("Xstream Pro", g["_t"](31121))
            state = False
        else:
            store.mark_watched(tmdb_id, season, episode)
            g["xbmcgui"].Dialog().notification("Xstream Pro", g["_t"](31120))
            state = True
    elif tmdb_id and tmdb_type == "tv" and season:
        store = g["WatchedMovies"](g["addon"], profile_num=profile_num)
        key = "season:{0}:{1}".format(tmdb_id, season)
        if store.is_watched(key):
            store.mark_unwatched(key)
            g["xbmcgui"].Dialog().notification("Xstream Pro", g["_t"](31121))
            state = False
        else:
            store.mark_watched(key)
            g["xbmcgui"].Dialog().notification("Xstream Pro", g["_t"](31120))
            state = True
    elif tmdb_id and tmdb_type == "tv":
        store = g["WatchedMovies"](g["addon"], profile_num=profile_num)
        key = "tvshow:{0}".format(tmdb_id)
        if store.is_watched(key):
            store.mark_unwatched(key)
            g["xbmcgui"].Dialog().notification("Xstream Pro", g["_t"](31121))
            state = False
        else:
            store.mark_watched(key)
            g["xbmcgui"].Dialog().notification("Xstream Pro", g["_t"](31120))
            state = True

    g["xbmc"].executebuiltin("Container.Refresh")
    return state
