# -*- coding: utf-8 -*-
import os
import sys
import datetime
import time
import re
import xbmcaddon
import xbmcvfs

import xbmc


ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
LIB_DIR = os.path.join(ADDON_DIR, "resources", "lib")
if LIB_DIR not in sys.path:
    sys.path.insert(0, LIB_DIR)


try:
    from pvr_epg_guard import repair_pvr_epg_files

    repair_pvr_epg_files()
except Exception as exc:
    xbmc.log("[Xstream Pro] EPG guard service failed: {0}".format(exc), xbmc.LOGWARNING)


try:
    from pvr_group_memory import remember_current_pvr_group
except Exception as exc:
    remember_current_pvr_group = None
    xbmc.log("[Xstream Pro] PVR group memory service unavailable: {0}".format(exc), xbmc.LOGWARNING)


monitor = xbmc.Monitor()
try:
    from provider_catalog_index import IndexBuildWorker
    def _catalog_trace():
        if xbmcaddon.Addon().getSetting('performance_diagnostics_enabled').lower() != 'true':
            return None
        from performance_diagnostics import PerformanceTrace
        trace = PerformanceTrace(log=lambda message: xbmc.log(message, xbmc.LOGINFO))
        trace.set_context('catalog', 'movie')
        return trace
    _catalog_player = xbmc.Player()
    catalog_index_worker = IndexBuildWorker(
        xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')),
        idle=lambda: xbmc.getGlobalIdleTime() >= 5 and not _catalog_player.isPlaying(),
        cancelled=lambda: monitor.abortRequested() or _catalog_player.isPlaying()
                          or xbmc.getGlobalIdleTime() < 2,
        trace_factory=_catalog_trace)
except Exception:
    catalog_index_worker = None
    xbmc.log('[Xstream Pro] Catalog index worker unavailable; original catalog route remains active', xbmc.LOGWARNING)
try:
    from recent_tv_native import RecentTV
    recent_tv = RecentTV(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')), xbmc)
except Exception:
    recent_tv = None
    xbmc.log('[Xstream Pro] Recent TV service unavailable', xbmc.LOGWARNING)
last_year_check = None
last_epg_check = 0
resume_signature = None
resume_path = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')), 'resume_points_p1.json')
while not monitor.abortRequested():
    if catalog_index_worker is not None:
        try:
            catalog_index_worker.tick()
        except Exception:
            xbmc.log('[Xstream Pro] Catalog index scheduling warning', xbmc.LOGWARNING)
    if recent_tv is not None:
        try:
            recent_tv.tick()
        except Exception:
            xbmc.log('[Xstream Pro] Recent TV polling warning', xbmc.LOGWARNING)
    # Run one refresh attempt at startup/periodically after the user has
    # stopped interacting. Never acquire player ownership or block the UI.
    if time.monotonic() - last_epg_check >= 1800:
        try:
            addon = xbmcaddon.Addon()
            active = addon.getSetting("active_pvr_profile") or "Profile 1"
            match = re.search(r"(\d+)$", active)
            profile = match.group(1) if match else "1"
            directory = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
            filename = "pvr_epg_xstream_pro_p%s.xml" % profile
            from pvr_epg_health import should_refresh
            if not xbmc.getCondVisibility("Player.HasMedia") and xbmc.getGlobalIdleTime() >= 30:
                if should_refresh(os.path.join(directory, filename)):
                    xbmc.executebuiltin(
                        "RunPlugin(plugin://plugin.video.xstream-pro/?mode=auto_refresh_pvr_epg)")
                last_epg_check = time.monotonic()
        except Exception:
            xbmc.log("[Xstream Pro] Automatic PVR EPG tick unavailable", xbmc.LOGWARNING)
            last_epg_check = time.monotonic()
    now = datetime.datetime.now()
    year_key = (now.year, now.day)
    if year_key != last_year_check:
        xbmc.executebuiltin("SetProperty(Premium.PreviousYear,{0},home)".format(now.year - 1))
        last_year_check = year_key
    try:
        stat = os.stat(resume_path)
        signature = (stat.st_mtime_ns, stat.st_size)
    except OSError:
        signature = (0, 0)
    if signature != resume_signature:
        xbmc.executebuiltin('SetProperty(Premium.ContinueRefresh,{0},home)'.format(signature[0]))
        resume_signature = signature
    if remember_current_pvr_group is not None:
        try:
            remember_current_pvr_group()
        except Exception as exc:
            xbmc.log("[Xstream Pro] PVR group memory service warning: {0}".format(exc), xbmc.LOGWARNING)
    if monitor.waitForAbort(1.0):
        break
if catalog_index_worker is not None:
    catalog_index_worker.close()
