"""Conservative TMDb enrichment gate for Xtream-to-Trakt identity mapping.

Search results are *candidates*, never verified identities by themselves.
Only a uniquely confirmed TMDb detail identity can enter the sync index.
No remote writes or credentials are handled here.
"""
from .trakt_sync import normalize_ids


def candidate_report(provider, candidates):
    """Return an explicit review decision; never match on title similarity alone."""
    if provider.get('kind') not in ('movie', 'show') or not str(provider.get('provider_id', '')).isdigit():
        raise ValueError('invalid provider identity')
    accepted = []
    for row in candidates:
        if not isinstance(row, dict) or row.get('kind') != provider['kind']:
            continue
        ids = normalize_ids({'tmdb': row.get('tmdb_id')})
        if 'tmdb' not in ids:
            continue
        accepted.append({'tmdb': ids['tmdb'], 'title': str(row.get('title', '')),
                         'year': str(row.get('year', ''))})
    unique = {row['tmdb']: row for row in accepted}
    return {'provider_id': str(provider['provider_id']), 'kind': provider['kind'],
            'status': 'review_required' if unique else 'unidentified',
            'candidates': list(unique.values())}


def verified_mapping(provider, tmdb_id, *, evidence):
    """Create mapping only with explicit provider detail ID or reviewed selection."""
    ids = normalize_ids({'tmdb': tmdb_id})
    if ('tmdb' not in ids or evidence not in ('provider_detail', 'manual_review') or
            provider.get('kind') not in ('movie', 'show') or
            not str(provider.get('provider_id', '')).isdigit() or
            int(provider['provider_id']) < 1):
        raise ValueError('unverified identity')
    return {'profile': str(provider['profile']), 'kind': provider['kind'],
            'provider_id': str(provider['provider_id']), 'ids': ids,
            'confidence': 'verified', 'evidence': evidence}
