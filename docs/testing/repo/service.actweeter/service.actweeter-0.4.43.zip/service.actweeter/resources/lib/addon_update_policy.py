"""Restore Kodi automatic add-on updates for AcTweeteR installations."""
import json
SETTING = 'general.addonupdates'
AUTO = 0

def ensure_notify_only(execute_jsonrpc):
    def call(method, params):
        result = json.loads(execute_jsonrpc(json.dumps({'jsonrpc':'2.0','id':'actweeter-update-policy','method':method,'params':params})))
        if not isinstance(result,dict) or 'error' in result: raise RuntimeError('Kodi update policy JSON-RPC failed')
        return result.get('result')
    current=call('Settings.GetSettingValue',{'setting':SETTING})
    if not isinstance(current,dict) or type(current.get('value')) is not int: raise RuntimeError('Kodi update setting unavailable')
    if current['value']==AUTO: return 'ALREADY_AUTO'
    if call('Settings.SetSettingValue',{'setting':SETTING,'value':AUTO}) is not True: raise RuntimeError('Kodi rejected automatic update setting')
    verified=call('Settings.GetSettingValue',{'setting':SETTING})
    if not isinstance(verified,dict) or verified.get('value')!=AUTO: raise RuntimeError('Kodi did not retain automatic update setting')
    return 'AUTO_ENABLED'
