"""Thin testable dispatch for XStream's existing watched toggle."""

def tmdb_watch_key(kind, tmdb_id, season=None, episode=None):
    """Namespace imported/manual TMDb marks away from provider numeric IDs."""
    tmdb_id = str(tmdb_id or '').strip()
    if kind == 'movie' and tmdb_id.isdigit() and int(tmdb_id) > 0:
        return 'tmdb:movie:' + tmdb_id
    if (kind == 'episode' and tmdb_id.isdigit() and int(tmdb_id) > 0
            and str(season).isdigit() and int(season) >= 0
            and str(episode).isdigit() and int(episode) > 0):
        return 'tmdb:episode:{0}:s{1}:e{2}'.format(tmdb_id, int(season), int(episode))
    return ''


def toggle_tmdb_watched(g, args):
    """Run the same profile-scoped XStream watched toggle used by its route."""
    tmdb_id = args.get("tmdb_id", [""])[0]
    tmdb_type = args.get("tmdb_type", [""])[0]
    season = args.get("season", [""])[0]
    episode = args.get("episode", [""])[0]
    profile = g["pm"].active
    profile_num = int(profile) if profile and str(profile).isdigit() else 1
    state = None

    if tmdb_id and tmdb_type == "movie":
        store = g["WatchedMovies"](g["addon"], profile_num=profile_num)
        key = tmdb_watch_key('movie', tmdb_id)
        if key:
            previous = store._data.get(key, False)
            state = not bool(previous)
            store._data[key] = state
            store._save()
            g["xbmcgui"].Dialog().notification("Xstream Pro", g["_t"](31120 if state else 31121))
    elif tmdb_id and tmdb_type == "tv" and season and episode:
        store = g["WatchedMovies"](g["addon"], profile_num=profile_num)
        key = tmdb_watch_key('episode', tmdb_id, season, episode)
        if key:
            state = not bool(store._data.get(key, False))
            store._data[key] = state
            store._save()
            g["xbmcgui"].Dialog().notification("Xstream Pro", g["_t"](31120 if state else 31121))
    elif tmdb_id and tmdb_type == "tv":
        # Bulk updates require a unique, complete provider inventory for this
        # exact TMDb series. Never treat an absent/partial inventory as watched.
        from series_changes import inventory_map
        from series_state import _valid_stored_inventory
        import time
        snapshots = inventory_map(g["addon"], profile_num)
        candidates = []
        for record in snapshots.values():
            if not isinstance(record, dict) or str(record.get("tmdb_id") or "") != str(tmdb_id):
                continue
            rows, valid = _valid_stored_inventory(record.get("episodes"))
            fresh = 0 <= time.time() - float(record.get("checked_at") or 0) <= 14 * 86400
            if valid and record.get("complete") is True and fresh:
                candidates.append(rows)
        if len(candidates) == 1 and str(tmdb_id).isdigit() and int(tmdb_id) > 0:
            selected = [row for row in candidates[0]
                        if not season or str(row["season"]) == str(season)]
            store = g["WatchedMovies"](g["addon"], profile_num=profile_num)
            keys = [tmdb_watch_key("episode", tmdb_id, row["season"], row["episode"])
                    for row in selected]
            if keys and all(keys):
                state = not all(store._data.get(key) is True for key in keys)
                for key in keys:
                    store._data[key] = state
                store._save()
                g["xbmcgui"].Dialog().notification("Xstream Pro", g["_t"](31120 if state else 31121))

    g["xbmc"].executebuiltin("Container.Refresh")
    return state
