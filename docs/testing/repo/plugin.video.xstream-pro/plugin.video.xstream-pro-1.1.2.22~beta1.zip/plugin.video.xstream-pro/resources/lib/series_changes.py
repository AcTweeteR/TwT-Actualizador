"""Small provider-only snapshot for XStream series and episode changes."""
import json
import os
import time

import xbmcvfs
import series_state


WINDOW_SECONDS = 30 * 86400
MAX_EVENTS = 50
CATALOG_INTERVAL = 6 * 3600


def _path(addon, profile_num):
    profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    return os.path.join(profile, "series_changes_p%d.json" % int(profile_num))


def _read(addon, profile_num):
    try:
        with open(_path(addon, profile_num), "r", encoding="utf-8") as stream:
            data = json.load(stream)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def _write(addon, profile_num, data):
    target = _path(addon, profile_num)
    os.makedirs(os.path.dirname(target), exist_ok=True)
    temporary = target + ".tmp"
    with open(temporary, "w", encoding="utf-8") as stream:
        json.dump(data, stream, ensure_ascii=False, separators=(",", ":"))
        stream.flush()
    os.replace(temporary, target)


def _trim(data):
    cutoff = time.time() - WINDOW_SECONDS
    data["events"] = sorted(
        (event for event in data.get("events", [])
         if float(event.get("changed", 0) or 0) >= cutoff),
        key=lambda event: float(event.get("changed", 0) or 0), reverse=True
    )[:MAX_EVENTS]


def record_catalog(addon, profile_num, items, force=False):
    """Baseline once; later provider catalogue refreshes detect newly seen IDs."""
    now = time.time()
    data = _read(addon, profile_num)
    if not force and now - float(data.get("catalog_checked", 0) or 0) < CATALOG_INTERVAL:
        return
    if not isinstance(items, list):
        return
    current = {str(item.get("series_id")): str(item.get("name") or "")
               for item in items if isinstance(item, dict) and item.get("series_id")}
    known = data.get("catalog_ids")
    if known is None:
        data["catalog_ids"] = sorted(current)
    else:
        known_ids = set(str(value) for value in known)
        events = data.setdefault("events", [])
        existing = {str(event.get("series_id")) for event in events}
        for series_id in current.keys() - known_ids:
            if series_id not in existing:
                events.append({"series_id": series_id, "title": current[series_id],
                               "status": "NUEVA SERIE", "changed": now})
        data["catalog_ids"] = sorted(known_ids | set(current))
    data["catalog_checked"] = now
    _trim(data)
    _write(addon, profile_num, data)


def record_series_info(addon, profile_num, series_id, title, response):
    """Refresh compact inventory only when XStream naturally loads series detail."""
    if not isinstance(response, dict):
        return
    episodes = response.get("episodes")
    if not isinstance(episodes, dict):
        return
    inventory, inventory_complete = series_state.normalize_inventory(episodes)
    episode_ids = {row["provider_id"] for row in inventory}
    now = time.time()
    data = _read(addon, profile_num)
    stored_inventories = data.get("episode_inventory")
    if not isinstance(stored_inventories, dict):
        stored_inventories = {}
        data["episode_inventory"] = stored_inventories
    info = response.get("info")
    info = info if isinstance(info, dict) else {}
    diagnostics = series_state.inventory_diagnostics(episodes) if not inventory_complete else {}
    conflicting_coordinates = diagnostics.pop("conflicting_coordinates", [])
    stored_inventories[str(series_id)] = {
        "checked_at": now,
        "complete": bool(inventory_complete),
        "diagnostics": diagnostics,
        "conflicting_coordinates": conflicting_coordinates,
        "tmdb_id": str(info.get("tmdb_id") or info.get("tmdb") or ""),
        "episodes": inventory,
    }
    inventories = data.setdefault("episode_ids", {})
    key = str(series_id)
    previous = set(str(value) for value in inventories.get(key, []))
    if episode_ids and key in inventories:
        new_ids = episode_ids - previous
        if new_ids:
            events = data.setdefault("events", [])
            is_new_series = any(
                str(event.get("series_id")) == key
                and event.get("status") == "NUEVA SERIE"
                and now - float(event.get("changed", 0) or 0) <= WINDOW_SECONDS
                for event in events if isinstance(event, dict))
            if not is_new_series:
                events = [event for event in events
                          if str(event.get("series_id")) != key]
                events.append({"series_id": key, "title": str(title or ""),
                               "status": "NUEVOS CAPÍTULOS", "changed": now})
                data["events"] = events
    if episode_ids:
        inventories[key] = sorted(episode_ids)
    _trim(data)
    _write(addon, profile_num, data)


def inventory_map(addon, profile_num):
    """Return the existing per-profile series inventory snapshot (no new store)."""
    data = _read(addon, profile_num)
    inventories = data.get("episode_inventory", {})
    return inventories if isinstance(inventories, dict) else {}


def status(addon, profile_num, series_id):
    now = time.time()
    for event in _read(addon, profile_num).get("events", []):
        if str(event.get("series_id")) == str(series_id) and now - float(event.get("changed", 0) or 0) <= WINDOW_SECONDS:
            return str(event.get("status") or "")
    return ""


def recent(addon, profile_num, limit=24):
    now = time.time()
    events = [event for event in _read(addon, profile_num).get("events", [])
              if now - float(event.get("changed", 0) or 0) <= WINDOW_SECONDS]
    return sorted(events, key=lambda event: float(event.get("changed", 0) or 0),
                  reverse=True)[:max(1, min(int(limit), 50))]
