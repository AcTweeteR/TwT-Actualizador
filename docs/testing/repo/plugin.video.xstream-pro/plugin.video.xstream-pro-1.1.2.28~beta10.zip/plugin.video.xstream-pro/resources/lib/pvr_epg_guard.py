# -*- coding: utf-8 -*-
import os
import re
import time

import xbmc
import xbmcaddon
import xbmcvfs


ADDON_ID = "plugin.video.xstream-pro"
PVR_FILE_SLUG = "xstream_pro"
EMPTY_XMLTV = '<?xml version="1.0" encoding="utf-8"?>\n<tv>\n</tv>\n'
PVR_EPG_RE = re.compile(
    r"^pvr_epg_{0}_p(\d+)\.xml$".format(re.escape(PVR_FILE_SLUG)),
    re.IGNORECASE,
)
SPORTS_PVR_EPG_RE = re.compile(
    r"^pvr_sports_epg_{0}_p(\d+)\.xml$".format(re.escape(PVR_FILE_SLUG)),
    re.IGNORECASE,
)


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log("[Xstream Pro] EPG guard: {0}".format(message), level)
    except Exception:
        pass


def _profile_number_from_setting(value):
    match = re.search(r"(\d+)", value or "")
    if not match:
        return None
    try:
        num = int(match.group(1))
    except ValueError:
        return None
    if 1 <= num <= 10:
        return str(num)
    return None


def _candidate_paths(addon, profile_dir):
    paths = set()

    active_raw = addon.getSetting("active_pvr_profile") or "Profile 1"
    active_num = _profile_number_from_setting(active_raw) or "1"
    paths.add(os.path.join(profile_dir, "pvr_epg_{0}_p{1}.xml".format(PVR_FILE_SLUG, active_num)))

    sports_raw = addon.getSetting("sports_pvr_profile") or "Active PVR Profile"
    if sports_raw.strip().lower() == "active pvr profile":
        sports_num = active_num
    else:
        sports_num = _profile_number_from_setting(sports_raw)
    if sports_num:
        paths.add(os.path.join(profile_dir, "pvr_epg_{0}_p{1}.xml".format(PVR_FILE_SLUG, sports_num)))
        paths.add(os.path.join(profile_dir, "pvr_sports_epg_{0}_p{1}.xml".format(PVR_FILE_SLUG, sports_num)))

    try:
        for name in os.listdir(profile_dir):
            if PVR_EPG_RE.match(name) or SPORTS_PVR_EPG_RE.match(name):
                paths.add(os.path.join(profile_dir, name))
    except OSError as exc:
        _log("could not list addon profile directory: {0}".format(exc), xbmc.LOGWARNING)

    return sorted(paths)


def xmltv_header_valid(path):
    try:
        if not os.path.exists(path) or os.path.getsize(path) <= 0:
            return False
        with open(path, "rb") as f:
            head = f.read(512)
        if head.startswith(b"\xef\xbb\xbf"):
            head = head[3:]
        head = head.lstrip()
        if not head:
            return False
        if head.startswith(b"<?xml"):
            close = head.find(b"?>")
            if close < 0:
                return False
            head = head[close + 2 :].lstrip()
        return head.startswith(b"<tv>") or head.startswith(b"<tv ")
    except Exception:
        return False


def _write_stub(path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp_path = path + ".tmp"
    with open(tmp_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(EMPTY_XMLTV)
        try:
            f.flush()
            os.fsync(f.fileno())
        except OSError:
            pass
    os.replace(tmp_path, path)


def _backup_invalid(path):
    if not os.path.exists(path):
        return ""
    stamp = time.strftime("%Y%m%d_%H%M%S")
    base = "{0}.bad_xmltv_{1}".format(path, stamp)
    candidate = base
    index = 1
    while os.path.exists(candidate):
        index += 1
        candidate = "{0}_{1}".format(base, index)
    os.replace(path, candidate)
    return candidate


def repair_pvr_epg_files():
    addon = xbmcaddon.Addon(ADDON_ID)
    profile_dir = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    os.makedirs(profile_dir, exist_ok=True)

    repaired = 0
    kept = 0
    failed = 0

    for path in _candidate_paths(addon, profile_dir):
        name = os.path.basename(path)
        try:
            if xmltv_header_valid(path):
                kept += 1
                continue

            if os.path.exists(path) and os.path.getsize(path) > 0:
                backup = _backup_invalid(path)
                _log("moved invalid XMLTV {0} to {1}".format(name, os.path.basename(backup)))

            _write_stub(path)
            repaired += 1
            _log("wrote valid XMLTV stub for {0}".format(name))
        except Exception as exc:
            failed += 1
            _log("failed to repair {0}: {1}".format(name, exc), xbmc.LOGWARNING)

    _log("finished; repaired={0} kept={1} failed={2}".format(repaired, kept, failed))
    return {"repaired": repaired, "kept": kept, "failed": failed}
