"""Portable MRU membership: full derived M3U, no duplicate rows or PVR restarts."""
import json
import os
import re
import time


def channel_uid(name, url):
    value = 0
    for byte in (name + url).encode('utf-8'):
        value = ((value * 33) + (byte if byte < 128 else byte - 256)) & 0xffffffff
    return abs(value if value < 0x80000000 else value - 0x100000000)


def transform(source, recent):
    lines = source.splitlines(keepends=True)
    count = 0
    changed = 0
    for index, line in enumerate(lines):
        if not line.startswith('#EXTINF'):
            continue
        count += 1
        following = next((v.strip() for v in lines[index + 1:]
                          if v.strip() and not v.startswith('#')), '')
        name = line.rsplit(',', 1)[-1].strip()
        if channel_uid(name, following) not in recent:
            continue
        def membership(match):
            groups = match.group(1).split(';')
            if 'Últimos Vistos' not in groups:
                groups.append('Últimos Vistos')
            return 'group-title="' + ';'.join(groups) + '"'
        lines[index] = re.sub(r'group-title="([^"]*)"', membership, line, count=1)
        changed += 1
    return ''.join(lines), count, changed


class RecentTV:
    def __init__(self, profile, kodi):
        self.kodi = kodi
        self.state_path = os.path.join(profile, 'recent_tv_mru.json')
        self.source = os.path.join(profile, 'pvr_live_xstream_pro_p1.m3u8')
        self.target = os.path.join(profile, 'pvr_recent_native.m3u8')
        self.current = None
        self.pending = 0
        self.ui_refresh_pending = False
        self.source_stamp = None
        try:
            with open(self.state_path, encoding='utf-8') as stream:
                self.recent = json.load(stream)['channels'][:25]
        except (OSError, ValueError, KeyError, TypeError):
            self.recent = []
        self.pending = time.monotonic() - 16

    def call(self, method, params):
        result = json.loads(self.kodi.executeJSONRPC(json.dumps(
            {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
        return result.get('result', {})

    def tick(self):
        try:
            source_stat = os.stat(self.source)
            stamp = (source_stat.st_mtime_ns, source_stat.st_size)
            if stamp != self.source_stamp:
                self.source_stamp = stamp
                self.pending = time.monotonic()
        except OSError:
            pass
        players = self.call('Player.GetActivePlayers', {})
        active = next((p['playerid'] for p in players if p.get('type') == 'video'), None)
        uid = None
        if active is not None:
            item = self.call('Player.GetItem', {'playerid': active}).get('item', {})
            if item.get('type') == 'channel':
                detail = self.call('PVR.GetChannelDetails', {
                    'channelid': item['id'], 'properties': ['uniqueid']})
                uid = detail.get('channeldetails', {}).get('uniqueid')
        if uid and uid != self.current:
            self.recent = [int(uid)] + [v for v in self.recent if v != int(uid)]
            self.recent = self.recent[:25]
            self._atomic(self.state_path, json.dumps({'channels': self.recent}, sort_keys=True))
            self.pending = time.monotonic()
            token = '%d-%d' % (int(uid), int(time.monotonic() * 1000))
            self.kodi.executebuiltin('SetProperty(Premium.RecentTVRefresh,%s,home)' % token)
            self.ui_refresh_pending = True
        self.current = uid
        if self.ui_refresh_pending and active is None:
            try:
                if self.kodi.getCondVisibility('Window.IsActive(home)'):
                    self.kodi.executebuiltin('Container.Refresh')
                    self.ui_refresh_pending = False
            except Exception:
                pass
        # Flush only while idle, not during a zap or playback. IPTV Simple polls normally.
        if active is None and self.pending and time.monotonic() - self.pending >= 15:
            try:
                with open(self.source, encoding='utf-8') as stream:
                    original = stream.read()
                derived, count, changed = transform(original, set(self.recent))
                if count < 1:
                    return
                existing = ''
                if os.path.exists(self.target):
                    with open(self.target, encoding='utf-8') as stream:
                        existing = stream.read()
                if derived != existing:
                    self._atomic(self.target, derived)
                    self.kodi.log('[Xstream Pro] Recent TV membership refreshed: %d unique history entries' % len(self.recent), self.kodi.LOGINFO)
                self.pending = 0
            except OSError:
                self.kodi.log('[Xstream Pro] Recent TV playlist unavailable; original remains intact', self.kodi.LOGWARNING)

    @staticmethod
    def _atomic(path, content):
        temporary = path + '.tmp'
        with open(temporary, 'w', encoding='utf-8') as stream:
            stream.write(content)
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)
