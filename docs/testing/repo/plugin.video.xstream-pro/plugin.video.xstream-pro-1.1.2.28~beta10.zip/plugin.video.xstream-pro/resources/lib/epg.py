# -*- coding: utf-8 -*-
import sys
import calendar
import json
import os
import time
import re
import threading
import urllib.parse
import bz2
import gzip
import io
import lzma
import zipfile

import requests
import xbmc
import xbmcaddon
import xbmcvfs

from profiles import ProfileManager
from lang import _t
from iptv import _validate_url


def _safe_fsync(f):
    try:
        profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
        if xbmc.getCondVisibility("System.Platform.OSX") and (
            "Containers" in profile or "Library/Caches/Kodi" in profile
        ):
            return
        os.fsync(f.fileno())
    except OSError:
        pass


_CACHE_LOCKS = {}
_CACHE_LOCKS_GUARD = threading.Lock()


def _cache_lock(path):
    key = os.path.abspath(path)
    with _CACHE_LOCKS_GUARD:
        lock = _CACHE_LOCKS.get(key)
        if lock is None:
            lock = threading.Lock()
            _CACHE_LOCKS[key] = lock
        return lock

# Use defusedxml if available. Always strip XMLTV DOCTYPE before parsing so
# common XMLTV DTD declarations do not break providers, while entity expansion
# still stays blocked.
try:
    from defusedxml import ElementTree as ET
    _USING_DEFUSEDXML = True
except ImportError:
    import xml.etree.ElementTree as ET
    _USING_DEFUSEDXML = False


def _strip_xml_doctype(payload):
    if isinstance(payload, str):
        payload = payload.encode("utf-8", "ignore")
    lowered = payload.lower()
    start = lowered.find(b"<!doctype")
    if start < 0:
        return payload

    i = start + len(b"<!doctype")
    quote = None
    bracket_depth = 0
    while i < len(payload):
        ch = payload[i]
        if quote is not None:
            if ch == quote:
                quote = None
        elif ch in (34, 39):  # " or '
            quote = ch
        elif ch == 91:  # [
            bracket_depth += 1
        elif ch == 93 and bracket_depth:  # ]
            bracket_depth -= 1
        elif ch == 62 and bracket_depth == 0:  # >
            return payload[:start] + payload[i + 1:]
        i += 1
    raise ValueError("Malformed XML DOCTYPE")


def _safe_fromstring(text, forbid_entities=True):
    # Removing the DTD prevents external DTD fetches. If the document relied on
    # custom entities, ElementTree/defusedxml will fail on unresolved references
    # instead of expanding them.
    return ET.fromstring(_strip_xml_doctype(text))


EPG_MAX_BYTES = 200 * 1024 * 1024  # 200 MB
EPG_MAX_UNCOMPRESSED_BYTES = 300 * 1024 * 1024  # 300 MB

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}

_startup_forced_profiles = set()


def _get_timeout():
    try:
        return int(xbmcaddon.Addon().getSetting("stream_timeout") or "15")
    except ValueError:
        return 15


def _get_headers():
    custom_ua = xbmcaddon.Addon().getSetting("custom_user_agent")
    if custom_ua:
        return {"User-Agent": custom_ua}
    return HEADERS


def _read_limited_fileobj(fileobj, limit=EPG_MAX_UNCOMPRESSED_BYTES):
    chunks = []
    total = 0
    while True:
        chunk = fileobj.read(64 * 1024)
        if not chunk:
            break
        total += len(chunk)
        if total > limit:
            raise ValueError(f"EPG decompressed payload exceeds {limit} bytes")
        chunks.append(chunk)
    return b"".join(chunks)


def _payload_looks_like_xml(payload):
    if isinstance(payload, str):
        payload = payload.encode("utf-8", "ignore")
    head = payload[:512].lstrip()
    if head.startswith(b"\xef\xbb\xbf"):
        head = head[3:].lstrip()
    lowered = head.lower()
    return (
        lowered.startswith(b"<?xml")
        or lowered.startswith(b"<tv")
        or lowered.startswith(b"<!doctype")
    )


def _decode_epg_payload(payload, headers=None, url=""):
    headers = headers or {}
    content_encoding = (headers.get("Content-Encoding") or "").lower()
    content_type = (headers.get("Content-Type") or "").lower()
    lower_url = (url or "").lower()

    # Requests may already decompress gzip transfer encoding while the response
    # header still says gzip. If the payload is XMLTV text, never try to gunzip it.
    if _payload_looks_like_xml(payload):
        return payload

    if payload.startswith(b"\x1f\x8b"):
        with gzip.GzipFile(fileobj=io.BytesIO(payload)) as gz:
            return _read_limited_fileobj(gz)

    if "gzip" in content_encoding or lower_url.endswith((".gz", ".xml.gz", ".gzip")):
        try:
            with gzip.GzipFile(fileobj=io.BytesIO(payload)) as gz:
                return _read_limited_fileobj(gz)
        except (OSError, EOFError, gzip.BadGzipFile):
            if _payload_looks_like_xml(payload):
                return payload
            raise

    if (
        payload.startswith(b"PK\x03\x04")
        or lower_url.endswith(".zip")
        or "zip" in content_type
    ):
        with zipfile.ZipFile(io.BytesIO(payload)) as zf:
            names = [n for n in zf.namelist() if not n.endswith("/")]
            if not names:
                raise ValueError("EPG zip archive is empty")
            preferred = [
                n for n in names
                if n.lower().endswith((".xml", ".xmltv", ".xml.gz", ".gz"))
            ]
            name = (preferred or names)[0]
            with zf.open(name) as inner:
                inner_payload = _read_limited_fileobj(inner)
            return _decode_epg_payload(inner_payload, {}, name)

    if payload.startswith(b"BZh") or lower_url.endswith(".bz2"):
        with bz2.BZ2File(io.BytesIO(payload)) as bz:
            return _read_limited_fileobj(bz)

    if payload.startswith(b"\xfd7zXZ\x00") or lower_url.endswith((".xz", ".lzma")):
        with lzma.LZMAFile(io.BytesIO(payload)) as xz:
            return _read_limited_fileobj(xz)

    return payload


_LOG_REDACT_PATH_RE = re.compile(
    r"(/(?:live|movie|series)/)([^/?\s]+)(/?)([^/?\s]*)", re.IGNORECASE
)
_LOG_REDACT_QUERY_RE = re.compile(r"(?i)\b(password|pwd|pass|username|user|token|key|apikey|api_key|auth)=([^&\s]+)")
_LOG_MAX_LEN = 4000


def _epg_log(msg):
    safe_msg = str(msg)
    safe_msg = _LOG_REDACT_PATH_RE.sub(
        lambda m: (
            m.group(1)
            + "***REDACTED***"
            + m.group(3)
            + ("***REDACTED***" if m.group(4) else "")
        ),
        safe_msg,
    )
    safe_msg = _LOG_REDACT_QUERY_RE.sub(r"\1=***REDACTED***", safe_msg)
    if len(safe_msg) > _LOG_MAX_LEN:
        safe_msg = safe_msg[:_LOG_MAX_LEN] + "...[truncated]"
    xbmc.log(f"[Xstream Pro EPG] {safe_msg}", xbmc.LOGINFO)


def _safe_url_for_log(url):
    try:
        parsed = urllib.parse.urlparse(str(url or ""))
        if not parsed.scheme:
            return "<url>"
        path = parsed.path or "/"
        if len(path) > 80:
            path = path[:80] + "...[truncated]"
        return "{0}://<redacted-host>{1}".format(parsed.scheme, path)
    except Exception:
        return "<url>"


class EPG:
    def __init__(self, addon, profile_num=None):
        self.addon = addon
        if profile_num is not None:
            active_profile = str(profile_num)
            # Import addon.py helper via local import to avoid circular dependency

            addon_module = sys.modules.get("resources.lib.addon")
            if addon_module is not None and hasattr(
                addon_module, "_get_credentials_for_profile"
            ):
                creds = addon_module._get_credentials_for_profile(active_profile)
            else:
                # Fallback: use ProfileManager directly
                pm = ProfileManager(addon)
                original = pm.active
                try:
                    pm.active = active_profile
                    creds = pm.get_credentials()
                finally:
                    pm.active = original
        else:
            pm = ProfileManager(addon)
            creds = pm.get_credentials()
            active_profile = pm.active

        self.profile_num = str(active_profile)

        source_type = creds.get("source_type", "Xtream Codes")

        if source_type == "M3U":
            self.epg_url = creds.get("epg_m3u", "")
        else:
            self.epg_url = creds.get("epg_xtream", "")

        self._auto_detected = False
        if not self.epg_url:
            xt_url = creds.get("xtream_url", "")
            xt_user = creds.get("xtream_username", "")
            xt_pwd = creds.get("xtream_password", "")
            if xt_url and xt_user and xt_pwd:
                self.epg_url = f"{xt_url.rstrip('/')}/xmltv.php?username={urllib.parse.quote(xt_user)}&password={urllib.parse.quote(xt_pwd)}"
                self._auto_detected = True
                _epg_log("Auto-detected EPG URL from Xtream credentials")
        self.cache_hours = 4
        self.offset_hours = 0.0
        self.profile_path = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        self.cache_file = os.path.join(
            self.profile_path, f"epg_cache_profile_{active_profile}.json"
        )
        self.programs = {}
        self.channel_names = {}
        self._program_starts = {}
        self.is_refreshing = False
        self._bg_thread = None

    def _ensure_profile(self):
        os.makedirs(self.profile_path, exist_ok=True)

    def _cache_valid(self):
        if not os.path.exists(self.cache_file):
            return False
        age = time.time() - os.path.getmtime(self.cache_file)
        return age < (self.cache_hours * 3600)

    def _save_cache(self):
        self._ensure_profile()
        lock = _cache_lock(self.cache_file)
        tmp_file = "{}.{}.tmp".format(self.cache_file, threading.get_ident())
        with lock:
            try:
                with open(tmp_file, "w", encoding="utf-8") as f:
                    json.dump(
                        {
                            "programs": self.programs,
                            "channel_names": self.channel_names,
                            "program_starts": self._program_starts,
                        },
                        f,
                    )
                    try:
                        f.flush()
                        _safe_fsync(f)
                    except OSError:
                        pass

                for attempt in range(5):
                    try:
                        os.replace(tmp_file, self.cache_file)
                        return
                    except PermissionError:
                        if attempt >= 4:
                            raise
                        xbmc.sleep(150 * (attempt + 1))
            finally:
                try:
                    if os.path.exists(tmp_file):
                        os.remove(tmp_file)
                except OSError:
                    pass

    def _load_cache(self):
        try:
            with _cache_lock(self.cache_file):
                with open(self.cache_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
            if isinstance(data, dict) and "programs" in data:
                self.programs = data.get("programs", {})
                self.channel_names = data.get("channel_names", {})
                self._program_starts = data.get("program_starts", {})
            else:
                self.programs = data
                self.channel_names = {}
                self._program_starts = {}
            _epg_log(f"Loaded cache with {len(self.programs)} channels")
        except Exception as e:
            _epg_log(f"Cache load failed: {e}")
            self.programs = {}
            self.channel_names = {}
            self._program_starts = {}

    def _try_fetch_epg(self, url):
        """Try to fetch and parse EPG from a URL. Returns ET root or None on failure."""
        if not _validate_url(url):
            _epg_log(f"EPG URL blocked by SSRF protection")
            return None
        # Security: never log provider host, query params, usernames, or passwords.
        safe_url = _safe_url_for_log(url)
        _epg_log(f"Fetching EPG from {safe_url}")
        try:
            # Credentials live in the query string, so a cross-host redirect
            # would leak username/password into a third-party access log.
            # Disable automatic redirects and only follow same-host ones.
            initial_host = urllib.parse.urlparse(url).netloc.lower()
            current_url = url
            resp = None
            for _hop in range(5):
                resp = requests.get(
                    current_url,
                    headers=_get_headers(),
                    timeout=_get_timeout(),
                    allow_redirects=False,
                    stream=True,
                )
                if resp.status_code in (301, 302, 303, 307, 308):
                    loc = resp.headers.get("Location", "")
                    if not loc:
                        break
                    next_url = urllib.parse.urljoin(current_url, loc)
                    if not _validate_url(next_url):
                        resp.close()
                        raise ValueError("EPG redirect blocked by SSRF protection")
                    next_host = urllib.parse.urlparse(next_url).netloc.lower()
                    if next_host != initial_host:
                        resp.close()
                        raise ValueError(
                            f"EPG redirect to different host blocked (creds protection): {next_host}"
                        )
                    current_url = next_url
                    resp.close()
                    continue
                break
            else:
                if resp is not None:
                    resp.close()
                raise ValueError("EPG redirect loop")
            resp.raise_for_status()
            # Bounded read so we cannot OOM on a hostile / misconfigured EPG URL.
            chunks = []
            total = 0
            for chunk in resp.iter_content(chunk_size=64 * 1024):
                if not chunk:
                    continue
                total += len(chunk)
                if total > EPG_MAX_BYTES:
                    resp.close()
                    raise ValueError(f"EPG payload exceeds {EPG_MAX_BYTES} bytes")
                chunks.append(chunk)
            resp.close()
            payload = b"".join(chunks)
            payload = _decode_epg_payload(payload, resp.headers, current_url)
            root = _safe_fromstring(payload, forbid_entities=True)
            root_tag = (root.tag or "").split("}", 1)[-1].lower()
            if root_tag != "tv":
                raise ValueError(f"EPG XML root is not tv: {root_tag}")
            return root
        except Exception as e:
            _epg_log(f"EPG fetch failed for {safe_url}: {e}")
            return None

    def fetch(self):
        if not self.epg_url:
            _epg_log("No EPG URL configured")
            self.programs = {}
            return
        root = self._try_fetch_epg(self.epg_url)
        # If auto-detected and failed, try fallback endpoint
        if root is None and self._auto_detected:
            fallback_url = self.epg_url.replace(
                "/xmltv.php?", "/get_litepanels_xmltv.php?"
            )
            if fallback_url != self.epg_url:
                _epg_log("Trying fallback EPG endpoint")
                root = self._try_fetch_epg(fallback_url)
        if root is None:
            if os.path.exists(self.cache_file):
                _epg_log("EPG fetch failed; keeping existing cached EPG")
                self._load_cache()
            else:
                self.programs = {}
                self.channel_names = {}
                self._program_starts = {}
            try:
                import xbmcgui

                xbmcgui.Dialog().notification(
                    "Xstream Pro", _t(30757), xbmcgui.NOTIFICATION_WARNING, 5000
                )
            except Exception as e:
                _epg_log(f"EPG notify warning: {e}")
            return

        lang_pref = ""

        self.channel_names = {}
        for ch_el in root.findall("channel"):
            ch_id = ch_el.get("id", "")
            if ch_id:
                disp = ch_el.find("display-name")
                self.channel_names[ch_id] = disp.text if disp is not None else ch_id

        self.programs = {}
        for prog in root.findall("programme"):
            channel = prog.get("channel", "")
            if not channel:
                continue

            titles = prog.findall("title")
            title_el = titles[0] if titles else None
            if lang_pref and titles:
                for t in titles:
                    if (t.get("lang") or "").lower() == lang_pref:
                        title_el = t
                        break

            descs = prog.findall("desc")
            desc_el = descs[0] if descs else None
            if lang_pref and descs:
                for d in descs:
                    if (d.get("lang") or "").lower() == lang_pref:
                        desc_el = d
                        break

            icon_el = prog.find("icon")

            start = prog.get("start", "")
            stop = prog.get("stop", "")

            entry = {
                "title": title_el.text if title_el is not None else _t(30702),
                "desc": desc_el.text if desc_el is not None else "",
                "icon": icon_el.get("src") if icon_el is not None else "",
                "start": start,
                "stop": stop,
                "start_timestamp": _xmltv_time_to_simple(start),
                "start_str": _xmltv_time_to_display(start),
                "stop_timestamp": _xmltv_time_to_simple(stop),
                "duration_sec": _xmltv_duration_sec(start, stop),
            }
            self.programs.setdefault(channel, []).append(entry)

        try:
            past_days = int(self.addon.getSetting("epg_past_days") or "3")
        except ValueError:
            past_days = 3
        cutoff = time.time() - (past_days * 86400)

        for ch in self.programs:
            self.programs[ch] = [
                p for p in self.programs[ch] if _parse_xmltv_time(p["stop"]) > cutoff
            ]
            self.programs[ch].sort(key=lambda x: x["start"])
            self._program_starts[ch] = [
                _parse_xmltv_time(p["start"]) for p in self.programs[ch]
            ]
        _epg_log(f"Parsed {len(self.programs)} channels from XMLTV")
        self._save_cache()

    def _fetch_in_background(self):
        try:
            self.is_refreshing = True
            self.fetch()
        finally:
            self.is_refreshing = False
            self._bg_thread = None

    def load(self):
        global _startup_forced_profiles
        force_startup = (
            self.addon.getSetting("epg_force_refresh_startup").lower() == "true"
        )
        if force_startup and self.profile_num not in _startup_forced_profiles:
            _epg_log("Startup force refresh triggered")
            _startup_forced_profiles.add(self.profile_num)
            self.fetch()
            return
        if self._cache_valid():
            _epg_log("EPG cache is valid, loading from disk")
            self._load_cache()
            return
        # Stale-cache-first: load expired cache immediately, refresh in background
        if os.path.exists(self.cache_file):
            _epg_log("EPG cache expired, loading stale data while refreshing in background")
            self._load_cache()
        else:
            _epg_log("EPG cache missing, will fetch in background")
            self.programs = {}
            self.channel_names = {}
            self._program_starts = {}
        if self._bg_thread is None or not self._bg_thread.is_alive():
            self._bg_thread = threading.Thread(target=self._fetch_in_background, daemon=True)
            self._bg_thread.start()

    def _apply_offset(self, ts):
        if not self.offset_hours:
            return ts
        return ts + (self.offset_hours * 3600)

    def _find_channel_id(self, channel_id, channel_name=""):
        programs = self.programs or {}
        if not programs:
            return None

        cid = str(channel_id or "").strip()
        cname = str(channel_name or "").strip()
        if not cid and not cname:
            return None

        if cid and programs.get(cid):
            return cid

        cid_lower = cid.casefold() if cid else ""
        cname_lower = cname.casefold() if cname else ""

        if cid_lower:
            for program_id, progs in programs.items():
                if progs and str(program_id).strip().casefold() == cid_lower:
                    return program_id

        if cname_lower:
            for program_id, progs in programs.items():
                if progs and str(program_id).strip().casefold() == cname_lower:
                    return program_id
            for program_id, display_name in (self.channel_names or {}).items():
                if programs.get(program_id) and str(display_name or "").strip().casefold() == cname_lower:
                    return program_id

        def _norm(value):
            text = str(value or "").casefold()
            text = re.sub(r"\[[^\]]*\]|\([^\)]*\)", " ", text)
            text = re.sub(
                r"\b(uhd|fhd|fullhd|full hd|hd|sd|hevc|h265|h\.265|h264|h\.264|4k|8k|50fps|60fps|backup|raw|vip|event only|bk)\b",
                " ",
                text,
            )
            text = re.sub(r"[^\w]+", " ", text, flags=re.UNICODE)
            return " ".join(text.split())

        cname_norm = _norm(cname)
        if cname_norm:
            for program_id, display_name in (self.channel_names or {}).items():
                if programs.get(program_id) and _norm(display_name) == cname_norm:
                    return program_id
            for program_id, progs in programs.items():
                if progs and _norm(program_id) == cname_norm:
                    return program_id

        return None

    def get_programs_for_channel(self, channel_id, channel_name="", days_back=None):
        matched_id = self._find_channel_id(channel_id, channel_name)
        if not matched_id:
            return []
        if days_back is None:
            try:
                days_back = int(self.addon.getSetting("replay_days") or "7")
            except ValueError:
                days_back = 7
        cutoff = time.time() - (days_back * 86400)
        result = []
        for prog in self.programs[matched_id]:
            stop = self._apply_offset(_parse_xmltv_time(prog["stop"]))
            if stop and stop > cutoff:
                result.append(prog)
        return result

    def export_xmltv(self, dest_path):
        if not self.programs:
            return False
        try:
            from xml.sax.saxutils import escape

            self._ensure_profile()
            tmp_path = dest_path + ".tmp"
            with open(tmp_path, "w", encoding="utf-8", newline="\n") as f:
                f.write('<?xml version="1.0" encoding="utf-8"?>\n<tv>\n')
                for channel_id in self.programs:
                    name = self.channel_names.get(channel_id, channel_id)
                    f.write(
                        '  <channel id="{0}"><display-name>{1}</display-name></channel>\n'.format(
                            escape(str(channel_id), {'"': "&quot;"}),
                            escape(str(name)),
                        )
                    )
                for channel_id, progs in self.programs.items():
                    for prog in progs:
                        attrs = {
                            "start": prog.get("start", ""),
                            "stop": prog.get("stop", ""),
                            "channel": str(channel_id),
                        }
                        f.write(
                            '  <programme start="{start}" stop="{stop}" channel="{channel}">\n'.format(
                                start=escape(attrs["start"], {'"': "&quot;"}),
                                stop=escape(attrs["stop"], {'"': "&quot;"}),
                                channel=escape(attrs["channel"], {'"': "&quot;"}),
                            )
                        )
                        f.write("    <title>{0}</title>\n".format(escape(str(prog.get("title", "Unknown")))))
                        if prog.get("desc"):
                            f.write("    <desc>{0}</desc>\n".format(escape(str(prog["desc"]))))
                        if prog.get("icon"):
                            f.write(
                                '    <icon src="{0}" />\n'.format(
                                    escape(str(prog["icon"]), {'"': "&quot;"})
                                )
                            )
                        f.write("  </programme>\n")
                f.write("</tv>\n")
                try:
                    f.flush()
                    _safe_fsync(f)
                except OSError:
                    pass
            if not epg_file_header_valid(tmp_path):
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass
                raise ValueError("Generated XMLTV has invalid header")
            os.replace(tmp_path, dest_path)
            _epg_log(f"Exported XMLTV to {dest_path}")
            return True
        except Exception as e:
            _epg_log(f"Export XMLTV failed: {e}")
            return False


def epg_file_header_valid(epg_path):
    try:
        with open(epg_path, "rb") as f:
            head = f.read(256)
        if head.startswith(b"\xef\xbb\xbf"):
            head = head[3:]
        head = head.lstrip()
        if not head:
            return False
        if head.startswith(b"<?xml"):
            close = head.find(b"?>")
            if close < 0:
                return False
            head = head[close + 2:].lstrip()
        return head.startswith(b"<tv>") or head.startswith(b"<tv ")
    except Exception:
        return False


def epg_file_has_data(epg_path):
    try:
        if not epg_file_header_valid(epg_path):
            return False
        scanned = 0
        max_scan = 32 * 1024 * 1024
        with open(epg_path, "r", encoding="utf-8", errors="ignore") as f:
            while scanned < max_scan:
                chunk = f.read(32768)
                if not chunk:
                    return False
                if "<programme" in chunk:
                    return True
                scanned += len(chunk)
        return False
    except Exception:
        return False


def _parse_xmltv_time(ts):
    if not ts:
        return 0
    ts = str(ts).strip()
    if not ts:
        return 0

    offset_sec = 0

    tz_match = re.search(r"([+-]\d{2}:?\d{2})$", ts)
    if tz_match:
        tz = tz_match.group(1)
        base = ts[:tz_match.start()].strip()
        digits = tz[1:].replace(":", "")
        try:
            hours = int(digits[:2])
            minutes = int(digits[2:4])
            if hours <= 14 and minutes <= 59:
                sign = 1 if tz[0] == "+" else -1
                offset_sec = sign * (hours * 3600 + minutes * 60)
                ts = base
        except (ValueError, IndexError):
            offset_sec = 0

    ts = ts.rstrip("Z").strip()
    compact = re.sub(r"\D", "", ts)
    candidates = []
    if len(compact) == 14:
        candidates.append((compact, "%Y%m%d%H%M%S"))
    elif len(compact) == 12:
        candidates.append((compact, "%Y%m%d%H%M"))

    if ts not in (value for value, _fmt in candidates):
        if len(ts) == 14 and ts.isdigit():
            candidates.append((ts, "%Y%m%d%H%M%S"))
        elif len(ts) == 12 and ts.isdigit():
            candidates.append((ts, "%Y%m%d%H%M"))

    for value, fmt in candidates:
        try:
            parsed = time.strptime(value, fmt)
            return calendar.timegm(parsed) - offset_sec
        except ValueError:
            continue
    return 0


def _xmltv_time_to_simple(ts):
    t = _parse_xmltv_time(ts)
    if not t:
        return ts
    return time.strftime("%Y-%m-%d:%H-%M", time.localtime(t))


def _xmltv_time_to_display(ts):
    t = _parse_xmltv_time(ts)
    if not t:
        return ""
    return time.strftime("%d/%m %H:%M", time.localtime(t))


def _xmltv_duration_sec(start, stop):
    s = _parse_xmltv_time(start)
    e = _parse_xmltv_time(stop)
    if s and e:
        return int(e - s)
    return 3600
