"""AcTweeteR Pending semantics over XStream's existing Favorites folders.

No second membership database is created. Dedicated Movie and Series folders
prevent cross-type ID collisions; provider availability and completion remain
read-only inputs owned by XStream's catalog/state adapters.
"""

FOLDERS = {"movie": "AcTweeteR Pending - Movies",
           "series": "AcTweeteR Pending - Series"}


def _kind(kind):
    value = str(kind or "").strip().lower()
    if value not in FOLDERS:
        raise ValueError("unsupported Pending media kind")
    return value


class PendingAdapter:
    """Thin adapter around the installed XStream Favorites API."""

    def __init__(self, favorites):
        self.favorites = favorites

    def list_items(self, kind):
        normalized = _kind(kind)
        return [dict(item) for item in self.favorites.get_all(FOLDERS[normalized])
                if str(item.get("stype", "")).lower() == normalized]

    def contains(self, kind, provider_id):
        normalized = _kind(kind)
        wanted = str(provider_id or "").strip()
        if not wanted:
            return False
        return any(str(item.get("id")) == wanted
                   for item in self.list_items(normalized))

    def add(self, kind, item):
        normalized = _kind(kind)
        if str((item or {}).get("stype", "")).lower() != normalized:
            raise ValueError("Pending item media type does not match folder")
        if not str((item or {}).get("id") or "").strip():
            raise ValueError("Pending requires a stable provider ID")
        return bool(self.favorites.add(item, FOLDERS[normalized]))

    def remove(self, kind, provider_id):
        normalized = _kind(kind)
        wanted = str(provider_id or "").strip()
        if not wanted or not self.contains(normalized, wanted):
            return False
        return bool(self.favorites.remove(wanted, FOLDERS[normalized], normalized))

    def reconcile_completion(self, kind, provider_id, complete):
        """Remove only on positive completion; later inventory never re-adds."""
        normalized = _kind(kind)
        if complete is not True:
            return False
        return self.remove(normalized, provider_id)
