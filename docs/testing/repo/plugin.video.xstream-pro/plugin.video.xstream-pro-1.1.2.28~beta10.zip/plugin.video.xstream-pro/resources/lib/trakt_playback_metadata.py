"""Kodi ListItem metadata bridge for the official script.trakt add-on."""
import json
import re

_PATTERNS = {"tmdb": re.compile(r"^[0-9]+$"), "tvdb": re.compile(r"^[0-9]+$"),
             "imdb": re.compile(r"^tt[0-9]+$", re.IGNORECASE)}
_PROPERTY = "script.trakt.ids"


def normalize_ids(values):
    if not isinstance(values, dict):
        return {}
    return {key: str(value).strip() for key, pattern in _PATTERNS.items()
            if (value := values.get(key)) is not None and pattern.fullmatch(str(value).strip())}


def _number(value, zero=False):
    try:
        result = int(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return result if result >= (0 if zero else 1) else None


def apply_video_info_tag(tag, window, data):
    data = data if isinstance(data, dict) else {}
    movie, episode = data.get("stype") == "movie", data.get("stype") == "series"
    tag.setMediaType("movie" if movie else "episode" if episode else "video")
    if episode:
        show = str(data.get("show_title") or data.get("title") or "")
        tag.setTitle(str(data.get("episode_title") or data.get("name") or show))
        if show:
            tag.setTvShowTitle(show)
        season, number = _number(data.get("season"), True), _number(data.get("episode"))
        if season is not None:
            tag.setSeason(season)
        if number is not None:
            tag.setEpisode(number)
        video_ids = normalize_ids(data.get("video_ids"))
        trakt_ids = normalize_ids(data.get("show_ids"))
        if data.get("tmdb_id"):
            trakt_ids.setdefault("tmdb", str(data["tmdb_id"]))
            trakt_ids = normalize_ids(trakt_ids)
    else:
        tag.setTitle(str(data.get("title") or data.get("name") or ""))
        year = _number(data.get("year"))
        if year is not None:
            tag.setYear(year)
        video_ids = normalize_ids(data.get("video_ids"))
        if movie and data.get("tmdb_id"):
            video_ids.setdefault("tmdb", str(data["tmdb_id"]))
            video_ids = normalize_ids(video_ids)
        trakt_ids = video_ids
    if video_ids:
        preferred = next((key for key in ("tmdb", "imdb", "tvdb") if key in video_ids), "")
        tag.setUniqueIDs(video_ids, preferred)
    encoded = json.dumps(trakt_ids, sort_keys=True, separators=(",", ":")) if trakt_ids else ""
    current = window.getProperty(_PROPERTY)
    if encoded:
        window.setProperty(_PROPERTY, encoded)
    elif current:
        window.clearProperty(_PROPERTY)
    return encoded


def clear_window_ids_if_current(window, expected):
    if expected and window.getProperty(_PROPERTY) == expected:
        window.clearProperty(_PROPERTY)
