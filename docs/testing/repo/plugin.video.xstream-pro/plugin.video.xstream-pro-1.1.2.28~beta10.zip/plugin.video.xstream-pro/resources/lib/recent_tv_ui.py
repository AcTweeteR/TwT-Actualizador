"""Read-only XStream MRU presentation adapter backed by Kodi PVR identity."""
import json
import os


def ordered_channels(uids, channels):
    """Join MRU UIDs to Kodi channels, preserving order and removing duplicates."""
    by_uid = {}
    for channel in channels or []:
        if not isinstance(channel, dict):
            continue
        uid = channel.get('uniqueid')
        if uid is None or channel.get('channeltype', 'tv') != 'tv' or channel.get('hidden'):
            continue
        by_uid.setdefault(str(uid), channel)
    result, seen = [], set()
    for raw_uid in uids or []:
        if isinstance(raw_uid, bool):
            continue
        try:
            uid = str(int(raw_uid))
        except (TypeError, ValueError, OverflowError):
            continue
        if uid in seen:
            continue
        seen.add(uid)
        channel = by_uid.get(uid)
        if channel and channel.get('channelid') is not None:
            result.append(channel)
    return result


def _mru_path(g):
    profile = g['addon'].getAddonInfo('profile')
    profile = g['xbmcvfs'].translatePath(profile)
    return os.path.join(profile, 'recent_tv_mru.json')


def _read_uids(g):
    try:
        with open(_mru_path(g), encoding='utf-8') as stream:
            data = json.load(stream)
        values = data.get('channels', []) if isinstance(data, dict) else []
        return values if isinstance(values, list) else []
    except (OSError, ValueError, TypeError):
        return []


def _rpc(g, method, params):
    request = {'jsonrpc':'2.0', 'id':1, 'method':method, 'params':params}
    try:
        response = json.loads(g['xbmc'].executeJSONRPC(json.dumps(request)))
        if response.get('error'):
            g['_log']('Recent TV Kodi API failed method=%s code=%s' %
                      (method, response['error'].get('code', 'unknown')))
            return None
        return response.get('result')
    except Exception as exc:
        g['_log']('Recent TV Kodi API failed method=%s error_type=%s' %
                  (method, type(exc).__name__))
        return None


def _channel_listitem(g, channel, pnum):
    name = str(channel.get('channel') or channel.get('label') or '')
    channel_id = int(channel['channelid'])
    uid = int(channel['uniqueid'])
    li = g['_new_listitem'](name)
    number = channel.get('channelnumber')
    if number not in (None, 0, ''):
        li.setLabel2(str(number))
    art = channel.get('thumbnail') or channel.get('icon') or ''
    if art:
        li.setArt({'thumb':art, 'icon':art})
    tag = li.getVideoInfoTag()
    tag.setTitle(name)
    tag.setMediaType('video')
    now = channel.get('broadcastnow') or {}
    next_program = channel.get('broadcastnext') or {}
    if now.get('plot'):
        tag.setPlot(now['plot'])
    if now.get('genre'):
        tag.setGenres([now['genre']])
    if now.get('title'):
        li.setProperty('PVR.BroadcastNow', str(now['title']))
    if next_program.get('title'):
        li.setProperty('PVR.BroadcastNext', str(next_program['title']))
    li.setProperty('PVR.ChannelId', str(channel_id))
    li.setProperty('PVR.ChannelUID', str(uid))
    li.setProperty('IsPlayable', 'true')
    path = g['build_url']({'mode':'premium', 'view':'recent_tv_play',
                           'channelid':channel_id, 'profile_num':pnum})
    return path, li


def _directory(g, pnum):
    response = _rpc(g, 'PVR.GetChannels', {
        'channelgroupid':'alltv',
        'properties':['channel', 'channeltype', 'channelnumber', 'uniqueid',
                      'thumbnail', 'icon', 'hidden', 'broadcastnow', 'broadcastnext'],
        'limits':{'start':0, 'end':10000},
    })
    channels = ordered_channels(_read_uids(g), response.get('channels', [])) \
        if isinstance(response, dict) else []
    plugin, handle = g['xbmcplugin'], g['addon_handle']
    plugin.setContent(handle, 'livetv')
    plugin.setPluginCategory(handle, 'Últimos vistos')
    for channel in channels:
        path, li = _channel_listitem(g, channel, pnum)
        plugin.addDirectoryItem(handle, path, li, False)
    plugin.addSortMethod(handle, plugin.SORT_METHOD_NONE)
    plugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def _play(g, params):
    get = lambda key, default='': params.get(key, [default])[0]
    try:
        channel_id = int(get('channelid'))
    except (TypeError, ValueError, OverflowError):
        channel_id = 0
    uid = None
    if channel_id > 0:
        detail = _rpc(g, 'PVR.GetChannelDetails', {
            'channelid':channel_id, 'properties':['uniqueid', 'channeltype', 'hidden']})
        channel = detail.get('channeldetails', {}) if isinstance(detail, dict) else {}
        if channel.get('channeltype', 'tv') == 'tv' and not channel.get('hidden'):
            try:
                uid = int(channel.get('uniqueid'))
            except (TypeError, ValueError, OverflowError):
                uid = None
    if uid is None or uid not in set(_read_uids(g)):
        g['xbmcplugin'].setResolvedUrl(g['addon_handle'], False, g['_new_listitem'](''))
        return
    result = _rpc(g, 'Player.Open', {'item':{'channelid':channel_id}})
    if result is None:
        g['xbmcplugin'].setResolvedUrl(g['addon_handle'], False, g['_new_listitem'](''))
        return
    g['xbmcplugin'].endOfDirectory(g['addon_handle'], succeeded=True,
                                   updateListing=False, cacheToDisc=False)


def dispatch(g, params, pnum, view):
    if view == 'recent_tv':
        _directory(g, pnum)
    else:
        _play(g, params)
