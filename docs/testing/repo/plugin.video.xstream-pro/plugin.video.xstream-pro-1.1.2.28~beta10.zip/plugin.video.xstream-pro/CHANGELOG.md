# Changelog
IF EPG IS NOT SHOWING AFTER UPDATE GO TO TOOLS/RESET RELOAD/PVR EPG RESET AND RESTART KODI
## 1.1.2

- Added Beta Updates option in settings/updates for online beta updates testing