"""Provider-first, bounded widget endpoints. Never returns a discovery item.

Called with the existing addon's environment; playback/profile/history remain
owned by XStream. Provider IDs, rather than fuzzy titles, bind every selection.
"""
import hashlib
import json
import os
import re
import time
import unicodedata
from urllib.parse import urlparse
import content_state


def _performance_call(g, name, function, *args, **kwargs):
    trace = g.get('_performance')
    if trace is None:
        return function(*args, **kwargs)
    return trace.call(name, function, *args, **kwargs)


def backdrop(value):
    if isinstance(value, list):
        return next((u for u in (backdrop(v) for v in value) if u), '')
    if isinstance(value, str):
        value = value.strip()
        parsed = urlparse(value)
        if parsed.scheme in ('https', 'http') and parsed.netloc:
            return value
    return ''


def number(value):
    try:
        return int(float(value or 0))
    except (ValueError, TypeError, OverflowError):
        return 0


def premiere_year(offset=0, clock=None):
    """Return the current/previous premiere year from an injectable clock."""
    try:
        now = (clock or time).localtime()
        return int(now.tm_year) - number(offset)
    except Exception:
        return int(time.gmtime().tm_year) - number(offset)


def provider_id(item, stype):
    return str(item.get('series_id' if stype == 'series' else 'stream_id') or '')


def resume_key(entry):
    return hashlib.sha256((entry.get('name', '') + '||' + entry.get('url', '')).encode()).hexdigest()


def normalized(title):
    title = re.sub(r'\s*\(\d{4}\)\s*$', '', str(title or ''))
    title = unicodedata.normalize('NFKD', title).casefold()
    return ''.join(c for c in title if c.isalnum())


def ranked_provider_items(g, items, stype, section, *, fast=False):
    """External ranking may order provider records, never manufacture them."""
    key = 'premium_rank_%s_%s_es' % (stype, section)
    cached = g['_cache_load'](key) or {}
    expiry = cached.get('expires', 0)
    # On Home, avoid a synchronous Trakt/TMDb refresh while perfectly usable
    # ranking IDs remain cached. Full browse still refreshes normally.
    if (expiry > time.time() or
            (fast and cached.get('ranks') and expiry > time.time() - 86400)):
        ranks = cached.get('ranks', [])
    else:
        ranks = []
        try:
            import trakt
            import tmdb
            media = 'tv' if stype == 'series' else 'movie'
            source = _performance_call(g, 'external.trakt.public_list', trakt.public_list, section, media).get('results', [])[:20]
            names = {(normalized(s.get('name')), str(s.get('year') or '')) for s in items}
            for index, entry in enumerate(source):
                title, year = entry.get('title', ''), str(entry.get('year') or '')
                titles = [title]
                # Bounded localization of ranking names; not a discovery list.
                if (normalized(title), year) not in names and index < 8:
                    meta = _performance_call(g, 'external.tmdb.details', tmdb.details, media, entry.get('tmdb_id'))
                    titles.append(meta.get('title') or meta.get('name') or '')
                ranks.append({'tmdb_id':str(entry.get('tmdb_id') or ''),
                              'year':year, 'titles':titles})
            g['_cache_save'](key, {'expires':time.time() + 21600, 'ranks':ranks})
        except Exception:
            g['_log']('Premium provider ranking unavailable; no discovery fallback')
    result, used = [], set()
    for rank in ranks:
        target_id = rank.get('tmdb_id')
        titles = {normalized(t) for t in rank.get('titles', []) if t}
        matches = [s for s in items if (
            target_id and str(s.get('tmdb_id') or s.get('tmdb') or '') == target_id)
            or (rank.get('year') and str(s.get('year') or '') == rank['year']
                and normalized(s.get('name')) in titles)]
        # Different editions of one exact title/year are safe; ambiguous titles aren't.
        identities = {(normalized(s.get('name')), str(s.get('year') or '')) for s in matches}
        if len(identities) == 1:
            item = matches[0]
            sid = provider_id(item, stype)
            if sid not in used:
                result.append(item)
                used.add(sid)
    return result


def enrich(g, item, stype, data, budget):
    """Exact ID or unique exact title/year. Never adds titles to a collection."""
    key = 'premium_meta_%s_%s_es' % (stype, provider_id(item, stype))
    cached = g['_cache_load'](key) or {}
    if cached.get('expires', 0) > time.time():
        extra = cached.get('data') or {}
    elif budget[0] > 0:
        budget[0] -= 1
        extra = {}
        try:
            import tmdb
            media = 'tv' if stype == 'series' else 'movie'
            tmdb_id = data.get('tmdb_id')
            matches, query, search_complete = [], '', False
            if not tmdb_id:
                query = re.sub(r'\s*\(\d{4}\)\s*$', '', item.get('name', ''))
                search_result = (_performance_call(g, 'external.tmdb.search', tmdb.paged, '/search/tv', media,
                    params={'query': query, 'first_air_date_year': str(data.get('year') or '')}, ttl=1)
                    if stype == 'series' else _performance_call(g, 'external.tmdb.search', tmdb.search, media, query))
                search_complete = search_result.get('total_pages') == 1
                matches = [m for m in search_result.get('results', [])
                    if normalized(m.get('title')) == normalized(query)
                    and str(m.get('year')) == str(data.get('year'))
                    and number(data.get('year'))]
                if len(matches) == 1:
                    tmdb_id = matches[0].get('tmdb_id')
            if tmdb_id:
                meta = _performance_call(g, 'external.tmdb.details', tmdb.details, media, tmdb_id)
                # ID from provider is authoritative; fuzzy matches never used.
                if meta.get('id'):
                    extra['tmdb_id'] = str(meta['id'])
                    extra['title'] = meta.get('title') or meta.get('name') or ''
                    extra['plot'] = meta.get('overview') or ''
                    extra['genre'] = ', '.join(v['name'] for v in meta.get('genres', []) if v.get('name'))
                    extra['poster_url'] = tmdb.image_url(meta.get('poster_path'))
                    extra['fanart_url'] = tmdb.fanart_url(meta.get('backdrop_path'))
                    extra['imdb_id'] = meta.get('imdb_id') or meta.get('external_ids', {}).get('imdb_id') or ''
                    extra['rating'] = meta.get('vote_average') or ''
                    if stype == 'series' and matches and search_complete:
                        evidence = content_state.series_identity_evidence(query, data.get('year'), matches, meta)
                        if evidence:
                            extra['_identity_evidence'] = evidence
                    extra['tagline'] = meta.get('tagline') or ''
                    extra['cast'] = [{'name':a.get('name', ''), 'role':a.get('character', ''),
                                     'thumbnail':tmdb.image_url(a.get('profile_path'))}
                                    for a in meta.get('credits', {}).get('cast', [])[:10]]
                    videos = meta.get('videos', {}).get('results', [])
                    trailer = next((v for v in videos if v.get('site') == 'YouTube'
                                    and v.get('type') == 'Trailer' and v.get('official')), None)
                    if trailer:
                        extra['trailer'] = 'plugin://plugin.video.youtube/play/?video_id=' + trailer['key']
            g['_cache_save'](key, {'expires':time.time() + (604800 if extra else 86400), 'data':extra})
        except Exception:
            # Metadata failure must not prevent provider playback.
            g['_log']('Premium enrichment unavailable; retaining provider metadata')
    else:
        extra = {}
    provider_fanart = data.get('fanart_url')
    provider_poster = data.get('poster_url')
    for key,value in extra.items():
        if value:
            data[key] = value
    if provider_fanart:
        data['fanart_url'] = provider_fanart
    if not data.get('poster_url'):
        data['poster_url'] = provider_poster
    # Optional exact-ID artwork. One cold request per directory, no discovery.
    if data.get('tmdb_id'):
        art_key = 'premium_logo_%s_%s_es' % (stype, data['tmdb_id'])
        artwork = g['_cache_load'](art_key) or {}
        if artwork.get('expires', 0) <= time.time() and budget[1] > 0:
            budget[1] -= 1
            try:
                import tmdb
                media = 'tv' if stype == 'series' else 'movie'
                images = _performance_call(g, 'external.tmdb.images', tmdb._request, '/%s/%s/images' % (media, data['tmdb_id']),
                    {'include_image_language':'es,null,en'}, ttl=168)
                logos = [a for a in images.get('logos', []) if a.get('file_path')]
                logos.sort(key=lambda a: ({'es':0, None:1, 'en':2}.get(a.get('iso_639_1'), 3),
                                           -float(a.get('vote_average') or 0)))
                artwork = {'expires':time.time() + 604800,
                           'clearlogo':tmdb.image_url(logos[0]['file_path'], 'w500') if logos else ''}
                g['_cache_save'](art_key, artwork)
            except Exception:
                artwork = {'expires':time.time() + 86400, 'clearlogo':''}
                g['_cache_save'](art_key, artwork)
        if artwork.get('expires', 0) > time.time() and artwork.get('clearlogo'):
            data['clearlogo_url'] = artwork['clearlogo']
    return data


def catalog(g, stype, pnum, *, force_refresh=False):
    creds = _performance_call(g, 'provider.credentials', g['_get_credentials_for_profile'], pnum)
    host, user, password = (creds.get(k, '') for k in
                            ('xtream_url', 'xtream_username', 'xtream_password'))
    generation_before = None
    if stype == 'series' and host and user and password:
        try:
            from provider_catalog_index import catalog_generation
            source = '%s|%s|%s' % (host, user, password)
            path_before = g['_cache_path']('xtream_streams_series', profile_num=pnum)
            generation_before = catalog_generation(path_before, source, pnum)
        except Exception:
            pass
    items = _performance_call(g, 'provider.streams', g['_get_cached_xtream_streams'],
        host, user, password, stype, None,
        force_refresh=False, require_fresh=False, profile_num=pnum)
    # Record the unfiltered provider catalogue before UI visibility filters.
    if stype == 'series' and items and host and user and password:
        try:
            generation = None
            if generation_before:
                path_after = g['_cache_path']('xtream_streams_series', profile_num=pnum)
                if path_after == path_before and catalog_generation(path_after, source, pnum) == generation_before:
                    generation = generation_before
            _performance_call(g, 'storage.series_catalog_write', g['series_changes'].record_catalog, g['addon'], pnum, items, provider=(host, user), generation=generation)
        except Exception as exc:
            g['_log']('Series baseline refresh failed: %s' % exc)
    categories = _performance_call(g, 'provider.categories', g['_get_cached_xtream_categories'],
        host, user, password, stype,
        force_refresh=False, require_fresh=False, profile_num=pnum)
    hidden_cats = set(g['_get_hidden_subcats'](stype, pnum))
    # Premium collections do not bypass parental control or hidden categories.
    blocked = hidden_cats | {str(c.get('category_id', '')) for c in categories
                            if g['_is_adult_category'](c.get('category_name', ''))}
    hidden = set(g['_get_hidden_items'](stype, pnum))
    visible = _performance_call(g, 'provider.filter', lambda: [
        s for s in items if isinstance(s, dict)
        and provider_id(s, stype) not in hidden
        and str(s.get('category_id', '')) not in blocked])
    trace = g.get('_performance')
    if trace is not None:
        trace.count('provider.items.input', len(items))
        trace.count('provider.items.visible', len(visible))
    return visible, (host, user, password)


def indexed_movie_page(g, pnum, view, get):
    """Use a derived offset index for warm movie catalogs; None keeps legacy fallback."""
    if view not in ('catalog', 'recent', 'popular', 'trending'):
        return None
    try:
        from provider_catalog_index import CatalogIndex, IndexUnavailable, schedule_rebuild
        creds = g['_get_credentials_for_profile'](pnum)
        host, user, password = (creds.get(key, '') for key in
                                ('xtream_url', 'xtream_username', 'xtream_password'))
        if not all((host, user, password)):
            return None
        cache_key = 'xtream_streams_movie'
        cache_path = g['_cache_path'](cache_key, profile_num=pnum)
        if not os.path.isfile(cache_path):
            return None
        cached_ranks = None
        if view in ('popular', 'trending'):
            rank_key = 'premium_rank_movie_%s_es' % view
            cached_ranks = g['_cache_load'](rank_key) or {}
            if cached_ranks.get('expires', 0) <= time.time() and not (
                    get('actweeter_expand') == '1' and get('browse') != '1'
                    and cached_ranks.get('ranks')
                    and cached_ranks.get('expires', 0) > time.time() - 86400):
                return None
        trace = g.get('_performance')
        source = '%s|%s|%s' % (host, user, password)
        try:
            index = _performance_call(g, 'catalog_index.open', CatalogIndex, cache_path,
                source, pnum, 'movie', trace=trace)
        except IndexUnavailable:
            if trace is not None:
                trace.count('index.fallback.used')
            try:
                schedule_rebuild(cache_path, source, pnum, 'movie', trace)
            except Exception:
                if trace is not None:
                    trace.count('index.rebuild.schedule_failed')
            return None
        categories = g['_get_cached_xtream_categories'](host, user, password, 'movie', profile_num=pnum)
        blocked = set(g['_get_hidden_subcats']('movie', pnum))
        blocked.update(str(category.get('category_id', '')) for category in categories
                       if g['_is_adult_category'](category.get('category_name', '')))
        hidden = set(g['_get_hidden_items']('movie', pnum))
        if trace is not None:
            trace.count('catalog_index.hit' if index.reused else 'catalog_index.build')
            if index.invalidated:
                trace.count('catalog_index.invalidated')
            trace.count('catalog_index.items', index.item_count)
            trace.count('catalog_index.bytes', os.path.getsize(index.path))
        args = {'blocked_categories': blocked, 'hidden_ids': hidden,
                'category': get('cat_id'), 'provider_id': get('id'),
                'browse': get('browse') == '1', 'page': number(get('page', 1)),
                'limit': min(19, number(get('limit', 24))) if get('actweeter_expand') == '1' else number(get('limit', 24))}
        if view in ('popular', 'trending'):
            result = _performance_call(g, 'index.query.duration', index.ranked,
                cached_ranks.get('ranks') or [], **args)
        else:
            result = _performance_call(g, 'index.query.duration', index.page,
                mode='recent' if view == 'recent' else 'catalog', **args)
        if trace is not None:
            trace.count('index.query.rows', len(result[0]))
        return result[0], result[1], (host, user, password)
    except Exception as exc:
        trace = g.get('_performance')
        if trace is not None:
            trace.count('index.fallback.used')
        if 'cache_path' in locals():
            try:
                schedule_rebuild(cache_path, source, pnum, 'movie', trace)
            except Exception:
                if trace is not None:
                    trace.count('index.rebuild.schedule_failed')
        g['_log']('Movie catalog index unavailable; using original path error_type=%s' %
                  type(exc).__name__)
        return None


def indexed_series_page(g, pnum, view, get):
    """Use the derived index only after the active catalog is recorded."""
    if view not in ('catalog', 'popular', 'trending', 'series_recent'):
        return None
    try:
        from provider_catalog_index import CatalogIndex, IndexUnavailable, schedule_rebuild, catalog_generation
        creds = g['_get_credentials_for_profile'](pnum)
        host, user, password = (creds.get(key, '') for key in
                                ('xtream_url', 'xtream_username', 'xtream_password'))
        if not all((host, user, password)):
            return None
        source = '%s|%s|%s' % (host, user, password)
        path = g['_cache_path']('xtream_streams_series', profile_num=pnum)
        generation = catalog_generation(path, source, pnum)
        if not generation or not g['series_changes'].generation_processed(
                g['addon'], pnum, (host, user), generation):
            return None
        trace = g.get('_performance')
        try:
            index = _performance_call(g, 'catalog_index.open', CatalogIndex,
                                      path, source, pnum, 'series', trace=trace)
        except IndexUnavailable:
            schedule_rebuild(path, source, pnum, 'series', trace)
            return None
        categories = g['_get_cached_xtream_categories'](host, user, password, 'series', profile_num=pnum)
        blocked = set(g['_get_hidden_subcats']('series', pnum))
        blocked.update(str(category.get('category_id', '')) for category in categories
                       if g['_is_adult_category'](category.get('category_name', '')))
        args = {'blocked_categories': blocked, 'hidden_ids': set(g['_get_hidden_items']('series', pnum)),
                'category': get('cat_id'), 'provider_id': get('id'),
                'browse': get('browse') == '1', 'page': number(get('page', 1)),
                'limit': min(19, number(get('limit', 24))) if get('actweeter_expand') == '1' else number(get('limit', 24))}
        if view == 'series_recent':
            events = g['series_changes'].recent(g['addon'], pnum, 50)
            result = index.series_events(events, **args)
        elif view in ('popular', 'trending'):
            cached = g['_cache_load']('premium_rank_series_%s_es' % view) or {}
            if cached.get('expires', 0) <= time.time() and not (
                    get('actweeter_expand') == '1' and get('browse') != '1'
                    and cached.get('ranks')
                    and cached.get('expires', 0) > time.time() - 86400):
                return None
            result = index.ranked(cached.get('ranks') or [], **args)
        else:
            result = index.page(**args)
        if g['_cache_path']('xtream_streams_series', profile_num=pnum) != path:
            return None
        return result[0], result[1], (host, user, password)
    except Exception as exc:
        if 'path' in locals() and 'source' in locals():
            try:
                schedule_rebuild(path, source, pnum, 'series', g.get('_performance'))
            except Exception:
                g['_log']('Series catalog index rebuild scheduling failed')
        g['_log']('Series catalog index unavailable; using original path error_type=%s' % type(exc).__name__)
        return None

def metadata(g, item, stype, credentials):
    sid = provider_id(item, stype)
    if stype == 'movie':
        data = _performance_call(g, 'provider.movie_info', g['_enrich_movie_info'], item)
        raw = g['_cache_load']('vod_info_' + sid) or {}
    else:
        data = _performance_call(g, 'provider.series_info', g['_enrich_series_info'], item, *credentials)
        raw = g['_cache_load']('series_info_' + sid) or {}
    cached = raw.get('info') or {}
    if not isinstance(cached, dict):
        cached = {}
    data['year'] = data.get('year') or item.get('year') or str(
        item.get('releaseDate') or item.get('release_date') or '')[:4]
    data['fanart_url'] = backdrop(data.get('fanart_url') or item.get('backdrop_path')
                                   or cached.get('backdrop_path') or raw.get('backdrop_path'))
    data['tmdb_id'] = str(data.get('tmdb_id') or cached.get('tmdb_id') or cached.get('tmdb')
                          or item.get('tmdb_id') or item.get('tmdb') or '')
    data['imdb_id'] = str(data.get('imdb_id') or cached.get('imdb_id') or '')
    data['trailer'] = cached.get('youtube_trailer') or item.get('youtube_trailer') or ''
    data['title'] = item.get('name', '')
    return data


def prepare_series_state_context(g, profile_num):
    """Load existing read-only series stores once for a provider listing."""
    try:
        changes = g['series_changes']
        return {
            'inventory': _performance_call(g, 'storage.series_inventory_read', changes.inventory_map, g['addon'], profile_num),
            'watched': _performance_call(g, 'storage.watched_read', g['WatchedEpisodes'], g['addon'], profile_num=profile_num),
            'tmdb_watched': _performance_call(g, 'storage.watched_tmdb_read', g['WatchedMovies'], g['addon'], profile_num=profile_num),
            'resume': _performance_call(g, 'storage.resume_read', g['ResumePoints'], g['addon'], profile_num=profile_num).get_all(),
        }
    except Exception:
        return None


def listitem(g, item, stype, data, label=None, profile_num=None, play_url='',
             series_context=None):
    li = g['_new_listitem'](label or data['title'])
    data['_verified_tmdb_id'] = content_state.provider_tmdb_id(
        g, stype, provider_id(item, stype), profile_num,
        item.get('tmdb_id') or item.get('tmdb'))
    if stype == 'series' and profile_num is not None and series_context is None:
        contexts = g.setdefault('_actweeter_series_state_context', {})
        if profile_num not in contexts:
            contexts[profile_num] = prepare_series_state_context(g, profile_num)
        series_context = contexts[profile_num]
    if stype == 'series' and series_context and not data['_verified_tmdb_id']:
        sid = provider_id(item, stype)
        if content_state.remember_verified_series(g, item, data, profile_num, series_context['inventory'].get(sid)):
            data['_verified_tmdb_id'] = content_state.provider_tmdb_id(g, stype, sid, profile_num)
    tag = li.getVideoInfoTag()
    tag.setMediaType('tvshow' if stype == 'series' else 'movie')
    tag.setTitle(data['title'])
    tag.setPlot(data.get('plot') or '')
    if data.get('tagline'):
        tag.setTagLine(data['tagline'])
    trailer = data.get('trailer')
    if isinstance(trailer, str) and trailer:
        if re.fullmatch(r'[A-Za-z0-9_-]{11}', trailer):
            trailer = 'plugin://plugin.video.youtube/play/?video_id=' + trailer
        if trailer.startswith(('plugin://plugin.video.youtube/', 'https://www.youtube.com/')):
            tag.setTrailer(trailer)
    if number(data.get('year')):
        tag.setYear(number(data['year']))
    if number(data.get('duration')):
        tag.setDuration(number(data['duration']))
    if data.get('genre'):
        tag.setGenres([s.strip() for s in str(data['genre']).split(',') if s.strip()])
    try:
        if data.get('rating'):
            tag.setRating(float(data['rating']))
    except (ValueError, TypeError):
        pass
    actors = [g['xbmc'].Actor(a.get('name', ''), a.get('role', ''), i,
                            a.get('thumbnail', ''))
              for i, a in enumerate(data.get('cast') or []) if a.get('name')]
    if actors:
        tag.setCast(actors[:10])
    ids = {'tmdb': data['_verified_tmdb_id']} if data['_verified_tmdb_id'] else {}
    if item.get('imdb_id'):
        ids['imdb'] = str(item['imdb_id'])
    if ids:
        tag.setUniqueIDs(ids, 'tmdb' if 'tmdb' in ids else 'imdb')
        for key, value in ids.items():
            li.setProperty(key + '_id', value)
    art = {}
    poster = backdrop(data.get('poster_url') or item.get('cover') or item.get('stream_icon'))
    fanart = backdrop(data.get('fanart_url'))
    if poster:
        art.update(poster=poster, icon=poster, thumb=poster)
    if fanart:
        art.update(fanart=fanart, landscape=fanart)
    if backdrop(data.get('clearlogo_url')):
        art['clearlogo'] = data['clearlogo_url']
    li.setArt(art)
    li.setProperty('XStream.ProviderID', provider_id(item, stype))
    li.setProperty('XStream.ProviderOnly', 'true')
    li.setProperty('IsPlayable', 'false' if stype == 'series' else 'true')
    if stype == 'movie' and profile_num is not None:
        content_state.apply_to_listitem(g, li, 'movie', profile_num,
            data.get('_verified_tmdb_id'), provider_id=provider_id(item, stype), play_url=play_url)
    elif stype == 'series' and profile_num is not None and series_context:
        try:
            sid = provider_id(item, stype)
            record = series_context['inventory'].get(sid)
            state_api = g['series_changes'].series_state
            tmdb_id = state_api.resolve_tmdb_id(record, item, data.get('_verified_tmdb_id', ''))
            state = state_api.derive_series_state(
                tmdb_id, sid, record, series_context['watched'], series_context['resume'],
                tmdb_watched_store=series_context['tmdb_watched'])
            state_api.apply_to_listitem(li, state)
        except Exception:
            g['_log']('Premium series progress unavailable; leaving progress unknown')
    return li


def add_provider_item(g, item, stype, credentials, pnum, budget,
                      series_context=None, pending=None, reconcile_pending=False):
    data = enrich(g, item, stype, metadata(g, item, stype, credentials), budget)
    play_url = (g['IPTV'].build_xtream_stream_url(*credentials, item, 'movie')
                if stype == 'movie' else '')
    li = listitem(g, item, stype, data, profile_num=pnum, play_url=play_url,
                  series_context=series_context)
    sid = provider_id(item, stype)
    if reconcile_pending and pending is not None:
        complete = (content_state.watched_state(
            g, 'movie', data.get('_verified_tmdb_id'), profile_num=pnum) is True
            if stype == 'movie' else
            li.getProperty('XStream.SeriesComplete') == 'true')
        if complete:
            pending.reconcile_completion(stype, sid, True)
            return False
    q = ({'mode':'xtream_series', 'series_id':sid, 'profile_num':pnum}
         if stype == 'series' else {'mode':'premium', 'view':'play', 'stype':stype,
                                   'id':sid, 'profile_num':pnum})
    path = g['build_url'](q)
    favorite_path = (g['IPTV'].build_xtream_stream_url(*credentials, item, 'movie')
                     if stype == 'movie' else path)
    favorite_actions = g['_build_favorite_ctx'](
        sid, item['name'], stype, data.get('poster_url', ''), favorite_path,
        profile_num=pnum, include_download=False)
    watched_actions = (content_state.watched_context(
        g, 'movie', data.get('_verified_tmdb_id'), profile_num=pnum) if stype == 'movie' else [])
    content_state.add_context_actions(li, favorite_actions, watched_actions)
    if stype == 'series':
        status = g['_series_change_status'](sid)
        if status:
            li.setProperty('XStream.ChangeStatus', status)
    _performance_call(g, 'kodi.add_directory_item', g['xbmcplugin'].addDirectoryItem,
                      g['addon_handle'], path, li, stype == 'series')
    return True


def _search_text(value):
    value = unicodedata.normalize('NFKD', str(value or '')).casefold()
    value = ''.join(char for char in value if not unicodedata.combining(char))
    return ' '.join(re.findall(r'[a-z0-9]+', value))


def _search_source_stamp(g, pnum, stype):
    import os
    previous = g['pm'].active
    try:
        g['pm'].active = str(pnum)
        path = g['_cache_path']('xtream_streams_' + stype)
        stat = os.stat(path)
        return '%d:%d' % (stat.st_mtime_ns, stat.st_size)
    except (OSError, AttributeError):
        return 'missing'
    finally:
        g['pm'].active = previous


def _search_filter_stamp(g, pnum):
    def values(method, stype):
        try:
            return tuple(sorted(str(value) for value in method(stype, pnum)))
        except Exception:
            return ()
    addon = g['addon']
    adult = addon.getSetting('hide_adult_categories').lower() == 'true'
    parts = [str(adult)]
    for stype in ('movie', 'series'):
        parts.extend((repr(values(g['_get_hidden_subcats'], stype)),
                      repr(values(g['_get_hidden_items'], stype))))
    return '|'.join(parts)


def _safe_search_art(value):
    """Do not persist artwork URLs containing provider credentials/tokens."""
    url = backdrop(value)
    if not url:
        return ''
    parsed = urlparse(url)
    if parsed.username or parsed.password:
        return ''
    if re.search(r'(?:^|[?&])(username|password|token|auth|api[_-]?key)=',
                 parsed.query, re.IGNORECASE):
        return ''
    return url


def _search_index_path(g, pnum):
    import os
    profile = g['xbmcvfs'].translatePath(g['addon'].getAddonInfo('profile'))
    return os.path.join(profile, 'provider_search_%s.sqlite' % pnum)


def _search_refresh_error(exc):
    import datetime
    import email.utils
    import socket
    import urllib.error
    current = exc
    seen = set()
    status, headers, auth_error = None, None, False
    error_types = set()
    message = ''
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        auth_error = auth_error or type(current).__name__ == 'ProviderAuthError'
        error_types.add(type(current).__name__)
        message += ' ' + str(current).casefold()
        response = getattr(current, 'response', None)
        status = (getattr(current, 'code', None) or
                  getattr(response, 'status_code', None) or status)
        headers = (getattr(current, 'headers', None) or
                   getattr(response, 'headers', None) or headers)
        current = getattr(current, '__cause__', None) or getattr(current, '__context__', None)
    if status is None:
        import re
        match = re.search(r'\b(401|403|408|429|504)\b', message)
        status = int(match.group(1)) if match else None
    if status in (401, 403) or auth_error or any(
            marker in message for marker in ('auth failed', 'auth error', 'expired',
                                             'credentials unavailable', 'banned', 'disabled')):
        category = 'authentication'
    elif status == 429:
        category = 'rate_limited'
    elif (status in (408, 504)
          or error_types.intersection(('Timeout', 'ConnectTimeout', 'ReadTimeout',
                                       'TimeoutError', 'socket.timeout'))
          or isinstance(exc, (TimeoutError, socket.timeout))
          or 'timed out' in message or 'timeout' in message):
        category = 'timeout'
    elif (isinstance(exc, urllib.error.URLError)
          or error_types.intersection(('ConnectionError', 'ConnectError',
                                       'NameResolutionError', 'URLError'))
          or 'connectionerror' in message or 'failed to establish a new connection' in message
          or 'name resolution' in message):
        category = 'connection'
    else:
        category = 'incomplete'
    retry_after = 0
    value = headers.get('Retry-After') if headers is not None else None
    if value:
        try:
            retry_after = max(0, int(float(value)))
        except (TypeError, ValueError):
            try:
                target = email.utils.parsedate_to_datetime(value)
                if target.tzinfo is None:
                    target = target.replace(tzinfo=datetime.timezone.utc)
                retry_after = max(0, int((target - datetime.datetime.now(
                    datetime.timezone.utc)).total_seconds()))
            except (TypeError, ValueError, OverflowError):
                retry_after = 0
    return category, retry_after


def _ensure_search_index(g, pnum, *, force_provider_refresh=False):
    import os
    import sqlite3
    profile = g['xbmcvfs'].translatePath(g['addon'].getAddonInfo('profile'))
    os.makedirs(profile, exist_ok=True)
    path = _search_index_path(g, pnum)
    filter_stamp = _search_filter_stamp(g, pnum)
    conn = sqlite3.connect(path, timeout=10)
    conn.execute('CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT)')
    conn.execute('''CREATE TABLE IF NOT EXISTS items (
        stype TEXT NOT NULL, provider_id TEXT NOT NULL, title TEXT NOT NULL,
        norm TEXT NOT NULL, year TEXT, poster TEXT, fanart TEXT, plot TEXT,
        genre TEXT, rating TEXT, category_id TEXT, category_name TEXT,
        PRIMARY KEY(stype, provider_id))''')
    conn.execute('CREATE INDEX IF NOT EXISTS items_type_norm ON items(stype, norm)')
    results = []
    snapshots = {}
    saved_meta = dict(conn.execute('SELECT key, value FROM meta'))
    if force_provider_refresh:
        try:
            g['_refresh_catalog_generation'](pnum, force=True)
        except Exception as exc:
            g['_log']('provider catalog generation refresh failed error_type=%s' % type(exc).__name__)
            category, retry_after = _search_refresh_error(exc)
            conn.rollback()
            results = [{'scanned':0, 'added':0, 'changed':0, 'removed':0,
                        'status':'error', 'error_category':category,
                        'retry_after':retry_after} for _ in ('movie', 'series')]
            return conn, results
    for stype in ('movie', 'series'):
        source_stamp = _search_source_stamp(g, pnum, stype)
        saved = saved_meta.get(stype)
        saved_filters = saved_meta.get('filters')
        if (not force_provider_refresh and saved == source_stamp
                and saved_filters == filter_stamp and source_stamp != 'missing'):
            results.append({'scanned':0, 'added':0, 'changed':0, 'removed':0,
                            'status':'unchanged'})
            continue
        started = time.perf_counter()
        try:
            items, credentials = catalog(g, stype, pnum, force_refresh=False)
        except Exception as exc:
            g['_log']('provider search refresh type=%s status=error error_type=%s' %
                      (stype, type(exc).__name__))
            category, retry_after = _search_refresh_error(exc)
            results.append({'scanned':0, 'added':0, 'changed':0, 'removed':0,
                            'status':'error', 'error_category':category,
                            'retry_after':retry_after})
            continue
        if not all(credentials) or not isinstance(items, list):
            g['_log']('provider search refresh type=%s status=error reason=catalog_unavailable' % stype)
            results.append({'scanned':0, 'added':0, 'changed':0, 'removed':0,
                            'status':'error', 'error_category':'incomplete',
                            'retry_after':0})
            continue
        rows = {}
        for item in items:
            sid = provider_id(item, stype)
            title = str(item.get('name') or item.get('title') or '').strip()
            norm = _search_text(title)
            if not sid or not title or not norm:
                continue
            rows[sid] = (stype, sid, title, norm,
                str(item.get('year') or item.get('releaseDate') or '')[:4],
                _safe_search_art(item.get('stream_icon') or item.get('cover')),
                _safe_search_art(item.get('backdrop_path')),
                str(item.get('plot') or ''), str(item.get('genre') or ''),
                str(item.get('rating') or ''), str(item.get('category_id') or ''),
                str(item.get('category_name') or ''))
        old_ids = {str(row[0]) for row in conn.execute(
            'SELECT provider_id FROM items WHERE stype=?', (stype,))}
        if old_ids and not rows and saved_filters == filter_stamp:
            g['_log']('provider search refresh type=%s status=error reason=empty_snapshot_rejected' % stype)
            results.append({'scanned':0, 'added':0, 'changed':0, 'removed':0,
                            'status':'error'})
            continue
        new_stamp = _search_source_stamp(g, pnum, stype)
        if new_stamp == 'missing':
            g['_log']('provider search refresh type=%s status=error reason=cache_unavailable' % stype)
            results.append({'scanned':0, 'added':0, 'changed':0, 'removed':0,
                            'status':'error'})
            continue
        snapshots[stype] = (rows, new_stamp, started)

    if any(result.get('status') == 'error' for result in results):
        return conn, results

    # Complete both provider snapshots before taking the SQLite write lock.
    # A Movies success followed by a Series failure therefore commits neither.
    try:
        conn.execute('BEGIN IMMEDIATE')
        for stype, (rows, new_stamp, started) in snapshots.items():
            added = changed = 0
            old_rows = {str(row[1]): tuple(row) for row in conn.execute(
                'SELECT stype,provider_id,title,norm,year,poster,fanart,plot,genre,rating,category_id,category_name '
                'FROM items WHERE stype=?', (stype,))}
            for sid, row in rows.items():
                previous = old_rows.get(sid)
                if previous is None:
                    added += 1
                    conn.execute('INSERT INTO items VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', row)
                elif tuple(previous) != row:
                    changed += 1
                    conn.execute('INSERT OR REPLACE INTO items VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', row)
            removed_ids = set(old_rows) - set(rows)
            if removed_ids:
                conn.executemany('DELETE FROM items WHERE stype=? AND provider_id=?',
                                 ((stype, sid) for sid in removed_ids))
            conn.execute('INSERT OR REPLACE INTO meta(key,value) VALUES (?,?)',
                         (stype, new_stamp))
            conn.execute('INSERT OR REPLACE INTO meta(key,value) VALUES (?,?)',
                         ('filters', filter_stamp))
            result = {'scanned':len(rows), 'added':added, 'changed':changed,
                      'removed':len(removed_ids),
                      'duration_ms':int((time.perf_counter() - started) * 1000),
                      'status':'success'}
            results.append(result)
            g['_log']('provider search delta type=%s scanned=%d added=%d changed=%d removed=%d ms=%d' %
                      (stype, result['scanned'], added, changed, len(removed_ids), result['duration_ms']))
        conn.commit()
    except Exception:
        conn.rollback()
        conn.close()
        raise
    return conn, results


def _search_rows(conn, query):
    terms = _search_text(query).split()
    if not terms:
        return []
    clauses = ' AND '.join('norm LIKE ?' for _ in terms)
    phrase = ' '.join(terms)
    rows = conn.execute(
        'SELECT stype,provider_id,title,norm,year,poster,fanart,plot,genre,rating '
        'FROM items WHERE ' + clauses +
        ' ORDER BY CASE WHEN norm=? THEN 0 WHEN norm LIKE ? THEN 1 ELSE 2 END,'
        ' title COLLATE NOCASE LIMIT 800',
        tuple('%%%s%%' % term for term in terms) + (phrase, phrase + '%')).fetchall()
    def rank(row):
        title = row[3]
        if title == ' '.join(terms):
            score = 0
        elif title.startswith(' '.join(terms)):
            score = 1
        else:
            words = title.split()
            score = 2 if all(any(word.startswith(term) for word in words)
                             for term in terms) else 3
        return score, 0 if row[0] == 'movie' else 1, title
    return sorted(rows, key=rank)[:24]


def _add_search_result(g, row, pnum):
    stype, sid, title, _norm, year, poster, fanart, plot, genre, rating = row
    item = {'stream_id' if stype == 'movie' else 'series_id': sid,
            'name': title, 'year': year, 'stream_icon': poster, 'cover': poster,
            'backdrop_path': fanart, 'plot': plot, 'genre': genre, 'rating': rating}
    data = {'title': title, 'year': year, 'poster_url': poster, 'fanart_url': fanart,
            'plot': plot, 'genre': genre, 'rating': rating}
    raw = g['_cache_load'](('vod_info_' if stype == 'movie' else 'series_info_') + sid) or {}
    if not isinstance(raw, dict):
        raw = {}
    provider_info = raw.get('info') if isinstance(raw, dict) else {}
    if not isinstance(provider_info, dict):
        provider_info = {}
    provider_fanart = backdrop(item.get('backdrop_path') or
                               provider_info.get('backdrop_path') or
                               raw.get('backdrop_path'))
    if provider_fanart:
        data['fanart_url'] = provider_fanart
    cached = g['_cache_load']('premium_meta_%s_%s_es' % (stype, sid)) or {}
    extra = cached.get('data') if cached.get('expires', 0) > time.time() else {}
    if isinstance(extra, dict):
        for key in ('title', 'plot', 'year', 'genre', 'rating', 'duration', 'tagline',
                    'cast', 'tmdb_id', 'imdb_id', 'trailer', 'poster_url', 'fanart_url',
                    'clearlogo_url'):
            if extra.get(key):
                data[key] = extra[key]
    if provider_fanart:
        data['fanart_url'] = provider_fanart
    if not data.get('poster_url'):
        data['poster_url'] = poster
    li = listitem(g, item, stype, data, profile_num=pnum)
    if stype == 'series':
        path = g['build_url']({'mode':'xtream_series', 'series_id':sid,
                               'profile_num':pnum})
        status = g['_series_change_status'](sid)
        if status:
            li.setProperty('XStream.ChangeStatus', status)
    else:
        path = g['build_url']({'mode':'premium', 'view':'play', 'stype':'movie',
                               'id':sid, 'profile_num':pnum})
    li.setProperty('path', path)
    favorite_actions = g['_build_favorite_ctx'](
        sid, title, stype, poster, path, profile_num=pnum, include_download=False)
    watched_actions = (content_state.watched_context(
        g, 'movie', data.get('_verified_tmdb_id'), profile_num=pnum) if stype == 'movie' else [])
    content_state.add_context_actions(li, favorite_actions, watched_actions)
    _performance_call(g, 'kodi.add_directory_item', g['xbmcplugin'].addDirectoryItem,
                      g['addon_handle'], path, li, stype == 'series')


def _indexed_continue_movies(g, pnum, entries):
    """Use active provider's immutable indexed byte ranges for exact resume IDs.

    No fuzzy identity, no restored progress writes, and no full catalog decode
    for the common case where every local movie resume URL has a stream ID.
    Recheck hidden/adult categories; any unavailable index falls back intact.
    """
    try:
        from provider_catalog_index import CatalogIndex
        creds = g['_get_credentials_for_profile'](pnum)
        host, user, password = (creds.get(key, '') for key in
                                ('xtream_url', 'xtream_username', 'xtream_password'))
        if not all((host, user, password)):
            return None
        chosen = [entry for entry in entries if entry.get('stype') == 'movie']
        if not chosen:
            return None
        # A single legacy title-only entry must not make all exact-ID
        # movies decode the entire 26k-item provider catalogue again.
        # Unknown or ambiguous names still use the complete legacy resolver.
        path = g['_cache_path']('xtream_streams_movie', profile_num=pnum)
        index = CatalogIndex(path, '%s|%s|%s' % (host, user, password),
                             pnum, 'movie', trace=g.get('_performance'))
        categories = g['_get_cached_xtream_categories'](
            host, user, password, 'movie', profile_num=pnum)
        blocked = set(g['_get_hidden_subcats']('movie', pnum))
        blocked.update(str(c.get('category_id', '')) for c in categories
                       if g['_is_adult_category'](c.get('category_name', '')))
        hidden = set(g['_get_hidden_items']('movie', pnum))
        found_items = []
        unique_ids = set()
        for entry in chosen:
            found = re.search(r'/([0-9]+)\.[A-Za-z0-9]+$',
                              urlparse(entry.get('url', '')).path)
            if found:
                matched, more = index.page(provider_id=found.group(1), browse=True,
                                           blocked_categories=blocked,
                                           hidden_ids=hidden, limit=2)
                if more or len(matched) > 1:
                    return None
            else:
                # Same strict identity predicate as the full-catalog path.
                # The SQLite search narrows candidates without changing
                # title matching, sort order or provider eligibility.
                title = entry.get('title') or entry.get('name', '')
                if not title:
                    return None
                candidates = index.search(title, blocked_categories=blocked,
                                          hidden_ids=hidden, limit=100)
                matched = [item for item in candidates
                           if item.get('name') in (title, entry.get('name'))
                           or entry.get('name', '').startswith(item.get('name', '') + ' - ')]
                if len(matched) != 1:
                    return None
            for item in matched:
                sid = provider_id(item, 'movie')
                if sid not in unique_ids:
                    unique_ids.add(sid)
                    found_items.append(item)
        return found_items, (host, user, password)
    except Exception as exc:
        trace = g.get('_performance')
        if trace is not None:
            trace.count('continue.index.fallback')
        g['_log']('Continue indexed movie lookup fallback: %s' % type(exc).__name__)
        return None


def _trakt_continue_extra(g, stype, seen, limit):
    """Read-only remote-only cards when local URLs are unavailable.

    A remote percentage is NOT a duration or safe seek offset. Cards open the
    existing TMDb provider selector; local verified ResumePoints remain the
    only direct resume playback source. No writes, credentials or fuzzy joins.
    """
    if limit < 1 or stype not in ('movie', 'series', 'both'):
        return []
    try:
        import trakt
        if not trakt.authorized():
            return []
        if not g['_setup_tmdb_routes']():
            return []
        routes = g.get('_tmdb_routes')
        if routes is None:
            return []
        wanted = ('movies', 'episodes') if stype == 'both' else (
            ('movies',) if stype == 'movie' else ('episodes',))
        pending = []
        for media_kind in wanted:
            data = trakt.playback(media_kind, cached=True)
            for item in data.get('results', []):
                kind, tmdb_id = item.get('tmdb_type'), str(item.get('tmdb_id') or '')
                season, episode = str(item.get('season') or ''), str(item.get('episode') or '')
                raw = item.get('raw')
                if (kind not in ('movie', 'tv') or not tmdb_id.isdigit()
                        or not isinstance(raw, dict) or not isinstance(raw.get('progress'), (int, float))):
                    continue
                identifier = (kind, tmdb_id, season if kind == 'tv' else '',
                              episode if kind == 'tv' else '')
                if identifier in seen:
                    continue
                seen.add(identifier)
                pending.append(item)
        # Match exact TMDb IDs against the existing provider's ES metadata
        # cache. This cache is already populated by provider search and avoids
        # displaying Trakt's English-only synopsis or placeholder artwork.
        # Do not guess from a similar title or construct a playback URL.
        import glob
        import os
        from urllib.parse import urlparse
        base = g['xbmcvfs'].translatePath(g['addon'].getAddonInfo('profile'))
        pnum = str(g['pm'].active)
        matched = {}
        for path in glob.glob(os.path.join(base,
                'data_cache_p%s_premium_meta_movie_*_es.json' % pnum)):
            try:
                with open(path, encoding='utf-8') as stream:
                    cache = json.load(stream)
                meta = cache.get('data') or {}
                tmdb_id = str(meta.get('tmdb_id') or '')
                sid = os.path.basename(path).split('premium_meta_movie_', 1)[1].split('_es.json')[0]
                if (not tmdb_id.isdigit() or not sid.isdigit()
                        or cache.get('expires', 0) <= time.time()):
                    continue
                if tmdb_id in matched:
                    matched[tmdb_id] = None  # ambiguous ID: never auto-select
                else:
                    matched[tmdb_id] = (sid, meta)
            except (OSError, ValueError, TypeError, KeyError):
                continue
        catalog = g['_cache_load']('xtream_streams_movie') or {}
        by_sid = {str(entry.get('stream_id')): entry
                  for entry in catalog.get('_data', []) if isinstance(entry, dict)}
        pending = routes._hydrate_from_tmdb_meta_cache(pending)
        results = []
        remote_metadata_fetches = 0
        for item in pending[:limit]:
            tmdb_id = str(item.get('tmdb_id') or '')
            candidate = matched.get(tmdb_id) if item.get('tmdb_type') == 'movie' else None
            if candidate and candidate[0] in by_sid:
                sid, meta = candidate
                provider = by_sid[sid]
                # The provider metadata is already keyed to a verified TMDb
                # ID, and the same stream ID must exist in this profile.
                data = dict(meta)
                data['title'] = data.get('title') or provider.get('name') or item.get('title') or ''
                data['plot'] = data.get('plot') or provider.get('plot') or ''
                data['poster_url'] = data.get('poster_url') or provider.get('stream_icon') or ''
                data['fanart_url'] = data.get('fanart_url') or provider.get('backdrop_path') or ''
                li = listitem(g, provider, 'movie', data, profile_num=pnum)
                url = g['build_url']({'mode':'premium','view':'play','stype':'movie',
                                      'id':sid,'profile_num':pnum})
                li.setProperty('XStream.ProviderMatched', 'true')
                li.setProperty('XStream.TraktProgress', str(item['raw']['progress']))
                li.setProperty('path', url)
                folder = False
            else:
                # An exact Trakt TMDb ID is sufficient to retrieve its Spanish
                # poster and overview even if no provider metadata was cached.
                # Bound cold-start network work to three titles per render.
                if remote_metadata_fetches < 3:
                    remote_metadata_fetches += 1
                    try:
                        import tmdb
                        detail = tmdb.meta_summary_cached(item['tmdb_type'], tmdb_id)
                        if isinstance(detail, dict):
                            for field in ('poster', 'fanart', 'plot', 'title', 'year'):
                                if detail.get(field):
                                    item[field] = detail[field]
                    except Exception:
                        pass
                url, li, folder = routes._media_item(item)
                li.setProperty('XStream.RemoteOnly', 'true')
            li.setProperty('XStream.ResumeOrigin', 'Trakt')
            if url:
                results.append((url, li, folder))
        return results
    except Exception as exc:
        logger = g.get('_log')
        if callable(logger):
            logger('Trakt continue remote overlay unavailable: %s' % type(exc).__name__)
        return []


def dispatch(g, params):
    get = lambda key, default='': params.get(key, [default])[0]
    pnum = number(get('profile_num', g['pm'].active)) or 1
    g['pm'].active = str(pnum)
    stype = get('stype', 'movie')
    view = get('view', 'catalog')
    handle, plugin = g['addon_handle'], g['xbmcplugin']
    build = g['build_url']
    # Widget first paint is not a metadata-enrichment task. Provider
    # rows have titles and artwork; warm TMDb cache still supplies the extra
    # values. Full-screen browse keeps the original enrichment budget.
    fast_widget = get('actweeter_expand') == '1' and get('browse') != '1'
    budget = [0, 0] if fast_widget else [4, 1]
    if view in ('recent_tv', 'recent_tv_play'):
        import recent_tv_ui
        recent_tv_ui.dispatch(g, params, pnum, view)
        return
    if view == 'search_input':
        # Use BINGIE's native search window so its provider-backed results
        # container can refresh while the user edits the query.
        g['xbmc'].executebuiltin('ActivateWindow(1109)')
        return
    if view == 'collections_root':
        if stype not in ('movie', 'series'):
            plugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
            return
        plugin.setContent(handle, 'videos')
        plugin.setPluginCategory(handle, 'Mis Colecciones')
        for collection, label in (('favorites', 'Favoritos'),
                                  ('pending', 'Pendientes')):
            li = g['_new_listitem'](label)
            li.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png',
                       'poster': 'DefaultFolder.png'})
            li.setProperty('AcTweeteR.CollectionFolder', '1')
            plugin.addDirectoryItem(handle, build({'mode': 'premium',
                'view': collection, 'stype': stype, 'profile_num': pnum,
                'browse': '1'}), li, True)
        custom = g['_new_listitem']('Mis listas')
        custom.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
        custom.setProperty('AcTweeteR.CollectionFolder', '1')
        plugin.addDirectoryItem(handle,
            'plugin://service.actweeter/?action=collections', custom, True)
        _performance_call(g, 'kodi.end_directory', plugin.endOfDirectory, handle, cacheToDisc=False)
        return
    if view == 'favorites_root':
        plugin.setContent(handle, 'videos')
        plugin.setPluginCategory(handle, 'Favoritos')
        for kind, label in (('movie', 'Películas'), ('series', 'Series')):
            li = g['_new_listitem'](label)
            plugin.addDirectoryItem(handle, build({'mode':'premium',
                'view':'favorites', 'stype':kind, 'profile_num':pnum}), li, True)
        _performance_call(g, 'kodi.end_directory', plugin.endOfDirectory, handle, cacheToDisc=False)
        return
    if view == 'pending_root':
        plugin.setContent(handle, 'videos')
        plugin.setPluginCategory(handle, 'Pendiente')
        for kind, label in (('movie', 'Películas'), ('series', 'Series')):
            li = g['_new_listitem'](label)
            plugin.addDirectoryItem(handle, build({'mode':'premium',
                'view':'pending', 'stype':kind, 'profile_num':pnum}), li, True)
        _performance_call(g, 'kodi.end_directory', plugin.endOfDirectory, handle, cacheToDisc=False)
        return
    if view == 'pending_toggle':
        if stype not in ('movie', 'series'):
            plugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
            return
        sid = get('id')
        favorites_api = g['_get_profile_fav'](pnum)
        pending_module = g.get('pending_adapter')
        if pending_module is None:
            plugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
            return
        pending = pending_module.PendingAdapter(favorites_api)
        if pending.contains(stype, sid):
            pending.remove(stype, sid)
        else:
            available, credentials = catalog(g, stype, pnum)
            item = next((row for row in available if provider_id(row, stype) == sid), None)
            if item is None:
                plugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
                return
            icon = item.get('cover') or item.get('stream_icon') or ''
            if stype == 'movie':
                target = g['IPTV'].build_xtream_stream_url(*credentials, item, 'movie')
            else:
                target = build({'mode':'xtream_series', 'series_id':sid,
                                'profile_num':pnum})
            pending.add(stype, {'id':sid, 'name':item.get('name', ''),
                'stype':stype, 'icon':icon, 'url':target})
        g['xbmcgui'].Window(10000).setProperty('Premium.CollectionsRefresh', str(time.time_ns()))
        g['xbmc'].executebuiltin('Container.Refresh')
        _performance_call(g, 'kodi.end_directory', plugin.endOfDirectory, handle, cacheToDisc=False)
        return
    if view == 'remove_resume':
        # Continue Watching is backed by ResumePoints only.  Keep WatchHistory
        # untouched: it is a separate "recent/history" store, not resume state.
        resume_points = g['ResumePoints'](g['addon'], profile_num=pnum)
        key = get('key')
        entries_before = resume_points.get_all()
        entry = next((e for e in entries_before if resume_key(e) == key), None)
        removed = False
        if entry:
            resume_points.remove(entry.get('name', ''), entry.get('url', ''))
            removed = not any(resume_key(e) == key for e in resume_points.get_all())
        g['_log']('REMOVE_CONTINUE handler_called=1 key=%s found=%s removed=%s '
                  'resume_before=%d resume_after=%d history_untouched=1 cache=none'
                  % (key, bool(entry), removed, len(entries_before),
                     len(resume_points.get_all())))
        # RunPlugin is dispatched while Kodi is still closing the context menu;
        # Container.Refresh sent here can be ignored during that modal animation.
        # Defer one light container refresh until the menu has closed.  Do not
        # Container.Update to the plugin path: that can navigate away from Home.
        g['xbmc'].executebuiltin(
            'AlarmClock(XStreamContinueRefresh,Container.Refresh,00:00:02,silent)'
        )
        return
    if view == 'search_sync':
        started = time.perf_counter()
        g['_log']('SEARCH_REFRESH_START profile=%s' % pnum)
        conn = None
        callback = get('actweeter_callback')
        success = False
        error_category, retry_after = 'incomplete', 0
        try:
            force_provider_refresh = get('force_provider_refresh') == '1'
            if not force_provider_refresh:
                creds = g['_get_credentials_for_profile'](pnum)
                source = '|'.join(creds.get(key, '') for key in
                                  ('xtream_url', 'xtream_username', 'xtream_password'))
                for key in ('xtream_streams_movie', 'xtream_cats_movie',
                            'xtream_streams_series', 'xtream_cats_series'):
                    cached = g['_cache_load'](key)
                    if (not g['_cache_valid'](key) or not isinstance(cached, dict)
                            or not g['catalog_cache'].source_matches(cached, source)):
                        force_provider_refresh = True
                        break
            conn, results = _ensure_search_index(
                g, pnum, force_provider_refresh=force_provider_refresh)
            if any(result.get('status') == 'error' for result in results):
                priorities = {'authentication': 5, 'rate_limited': 4, 'timeout': 3,
                              'connection': 2, 'incomplete': 1}
                failures = [result for result in results if result.get('status') == 'error']
                error_category = max(
                    (item.get('error_category', 'incomplete') for item in failures),
                    key=lambda category: priorities.get(category, 0))
                retry_after = max(int(item.get('retry_after', 0) or 0) for item in failures)
                conn.close()
                conn = None
                g['_log']('SEARCH_REFRESH_END status=error reason=provider_snapshot_incomplete duration_ms=%d' %
                          int((time.perf_counter() - started) * 1000))
                if (len(callback) == 32
                        and all(char in '0123456789abcdef' for char in callback.lower())):
                    g['xbmc'].executebuiltin(
                        'RunScript(service.actweeter,catalog_refresh_result,%s,error,%s,%d)' %
                        (callback, error_category, retry_after), False)
                plugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
                return
            conn.execute('BEGIN IMMEDIATE')
            conn.execute('INSERT OR REPLACE INTO meta(key,value) VALUES (?,?)',
                         ('last_successful_sync', str(time.time())))
            conn.execute('INSERT OR REPLACE INTO meta(key,value) VALUES (?,?)',
                         ('schema_version', '1'))
            conn.commit()
            conn.close()
            conn = None
            success = True
            totals = {key:sum(row.get(key, 0) for row in results)
                      for key in ('scanned', 'added', 'changed', 'removed')}
            g['_log']('SEARCH_REFRESH_END scanned=%d added=%d changed=%d removed=%d duration_ms=%d status=success' %
                      (totals['scanned'], totals['added'], totals['changed'], totals['removed'],
                       int((time.perf_counter() - started) * 1000)))
        except Exception as exc:
            if conn is not None:
                conn.rollback()
                conn.close()
            g['_log']('SEARCH_REFRESH_END status=error error_type=%s duration_ms=%d' %
                      (type(exc).__name__, int((time.perf_counter() - started) * 1000)))
            error_category, retry_after = _search_refresh_error(exc)
        if (len(callback) == 32
                and all(char in '0123456789abcdef' for char in callback.lower())):
            g['xbmc'].executebuiltin(
                'RunScript(service.actweeter,catalog_refresh_result,%s,%s,%s,%d)' %
                (callback, 'success' if success else 'error', error_category, retry_after), False)
        plugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return
    if view == 'search':
        query = get('query')
        plugin.setContent(handle, 'videos')
        plugin.setPluginCategory(handle, 'Buscar')
        if query:
            import os
            import sqlite3
            started = time.perf_counter()
            conn = None
            try:
                path = _search_index_path(g, pnum)
                if os.path.isfile(path):
                    conn = sqlite3.connect('file:%s?mode=ro' % os.path.abspath(path),
                                            uri=True, timeout=3)
                    rows = _search_rows(conn, query)
                else:
                    rows = []
                for row in rows:
                    _add_search_result(g, row, pnum)
                g['_log']('provider search query chars=%d results=%d ms=%d status=local' %
                          (len(query), len(rows), int((time.perf_counter() - started) * 1000)))
            except Exception as exc:
                g['_log']('provider search query chars=%d status=error error_type=%s' %
                          (len(query), type(exc).__name__))
            finally:
                if conn is not None:
                    conn.close()
        plugin.addSortMethod(handle, plugin.SORT_METHOD_NONE)
        _performance_call(g, 'kodi.end_directory', plugin.endOfDirectory, handle, cacheToDisc=False)
        return
    if view in ('continue', 'resume'):
        entries = g['ResumePoints'](g['addon'], profile_num=pnum).get_all()
        if stype != 'both':
            entries = [e for e in entries if e.get('stype') == stype]
        if view == 'resume':
            entry = next((e for e in entries if resume_key(e) == get('key')), None)
            if entry:
                kind = entry.get('stype')
                available, credentials = catalog(g, kind, pnum) if kind in ('movie', 'series') else ([], ())
                title = entry.get('title') or entry.get('name', '')
                matched_item = next((s for s in available if s.get('name') in
                    (title, entry.get('name')) or entry.get('name', '').startswith(
                        s.get('name', '') + ' - ')), None)
                if not matched_item:
                    entry = None
            if entry:
                kind = entry.get('stype', 'movie')
                item_data = metadata(g, matched_item, kind, credentials)
                show_ids = {}
                episode_data, episode_num = {}, entry.get('episode_num', entry.get('episode', ''))
                episode_title = entry.get('title') or entry.get('name', '')
                show_title = item_data.get('title', '')
                if kind == 'series':
                    raw = g['_cache_load']('series_info_' + provider_id(matched_item, kind)) or {}
                    series_data = raw if isinstance(raw, dict) else {}
                    raw = series_data.get('info') if isinstance(series_data.get('info'), dict) else {}
                    show_title = show_title or raw.get('name', '')
                    season_items = (series_data.get('episodes') or {}).get(str(entry.get('season_num', '')), [])
                    episode_data = next((ep for ep in season_items if str(ep.get('id', '')) == str(entry.get('ep_id', ''))), {})
                    episode_title = episode_data.get('title') or episode_title
                    episode_num = episode_num or episode_data.get('episode_num', '')
                    show_ids = {key: value for key, value in {
                        'tmdb': item_data.get('tmdb_id') or raw.get('tmdb'),
                        'imdb': item_data.get('imdb_id') or raw.get('imdb_id') or raw.get('imdb'),
                        'tvdb': raw.get('tvdb_id') or raw.get('tvdb'),
                    }.items() if value}
                video_ids = ({key: value for key, value in {
                    'tmdb': item_data.get('tmdb_id'), 'imdb': item_data.get('imdb_id')
                }.items() if value} if kind == 'movie' else {})
                g['play_stream'](entry['url'], entry['name'], title=episode_title,
                    plot=entry.get('plot', ''), icon=entry.get('icon', ''),
                    stype=kind, profile_num=pnum,
                    series_id=entry.get('series_id', ''), season_num=entry.get('season_num', ''),
                    ep_id=entry.get('ep_id', ''), resume_pos=entry.get('position', 0),
                    resume_total=entry.get('duration', 0), tmdb_id=item_data.get('tmdb_id', ''),
                    year=item_data.get('year', ''), video_ids=video_ids, show_ids=show_ids,
                    episode_num=episode_num, show_title=show_title)
            else:
                plugin.setResolvedUrl(handle, False, g['_new_listitem'](''))
            return
        plugin.setContent(handle, 'videos')
        catalogs = {}
        limit = min(48, max(1, number(get('limit', 24))))
        if get('actweeter_expand') == '1':
            limit = min(19, limit)
        page = max(1, number(get('page', 1)))
        offset = (page - 1) * limit
        valid_count = 0
        has_more = False
        local_shown = 0
        seen_resume_ids = set()
        for entry in entries:
            kind = entry.get('stype')
            if kind not in ('movie', 'series'):
                continue
            if kind not in catalogs:
                # Preserve full-catalog fallback whenever a verified source
                # index is unavailable or legacy resume URLs lack exact IDs.
                accelerated = (_indexed_continue_movies(g, pnum, entries)
                               if kind == 'movie' else None)
                catalogs[kind] = accelerated if accelerated is not None else catalog(g, kind, pnum)
            items, credentials = catalogs[kind]
            # Match exact provider movie IDs from the saved URI first. A
            # title is not reliable after metadata/language changes.
            title = entry.get('title') or entry.get('name', '')
            candidates = [s for s in items if s.get('name') in (title, entry.get('name'))
                          or entry.get('name', '').startswith(s.get('name', '') + ' - ')]
            provider_match = re.search(r'/([0-9]+)\.[A-Za-z0-9]+$',
                                       urlparse(entry.get('url', '')).path)
            if provider_match and kind == 'movie':
                exact = [s for s in items if provider_id(s, kind) == provider_match.group(1)]
                if len(exact) == 1:
                    candidates = exact
                elif len(exact) > 1:
                    continue
            if len(candidates) != 1:
                continue
            if valid_count < offset:
                valid_count += 1
                continue
            if valid_count >= offset + limit:
                has_more = True
                break
            valid_count += 1
            item = candidates[0]
            data = enrich(g, item, kind, metadata(g, item, kind, credentials), budget)
            display_name = data['title']
            if kind == 'series':
                episode = re.search(r'(S\d+E\d+.*)$', entry.get('name', ''), re.I)
                if episode:
                    display_name += ' · ' + episode.group(1)
            li = listitem(g, item, kind, data, label=display_name,
                          profile_num=pnum, play_url=entry.get('url', ''))
            if data.get('fanart_url'):
                # LandscapeImage prioritizes episode thumb over landscape.
                li.setArt({'thumb': data['fanart_url']})
            tag = li.getVideoInfoTag()
            tag.setMediaType('episode' if kind == 'series' else 'movie')
            tag.setTitle(display_name)
            tag.setDuration(number(entry.get('duration')))
            tag.setResumePoint(float(entry.get('position') or 0), float(entry.get('duration') or 0))
            if kind == 'series':
                tag.setTvShowTitle(data['title'])
                match = re.search(r'S(\d+)E(\d+)', entry.get('name', ''), re.I)
                if match:
                    tag.setSeason(int(match[1]))
                    tag.setEpisode(int(match[2]))
            li.setProperty('IsPlayable', 'true')
            li.setProperty('ResumeTime', str(entry.get('position') or 0))
            li.setProperty('TotalTime', str(entry.get('duration') or 0))
            context_actions = [('Eliminar de continuar viendo',
                'RunPlugin(%s)' % build({'mode':'premium', 'view':'remove_resume',
                    'stype':stype, 'key':resume_key(entry), 'profile_num':pnum}))]
            watched_actions = (content_state.watched_context(
                g, 'movie', data.get('_verified_tmdb_id'), profile_num=pnum)
                if kind == 'movie' else [])
            content_state.add_context_actions(li, context_actions, watched_actions)
            plugin.addDirectoryItem(handle, build({'mode':'premium', 'view':'resume',
                'stype':kind, 'key':resume_key(entry), 'profile_num':pnum}), li, False)
            local_shown += 1
            remote_type = 'movie' if kind == 'movie' else 'tv'
            verified = str(data.get('_verified_tmdb_id') or '')
            episode_match = re.search(r'S(\d+)E(\d+)', entry.get('name', ''), re.I)
            if verified.isdigit() and (kind == 'movie' or episode_match):
                seen_resume_ids.add((remote_type, verified,
                    episode_match.group(1) if episode_match else '',
                    episode_match.group(2) if episode_match else ''))
        if view == 'continue' and page == 1:
            for extra_url, extra_li, extra_folder in _trakt_continue_extra(
                    g, stype, seen_resume_ids, limit - local_shown):
                plugin.addDirectoryItem(handle, extra_url, extra_li, extra_folder)
        if has_more and get('actweeter_expand') == '1':
            query = {key: values[0] for key, values in params.items() if values}
            query.pop('actweeter_expand', None)
            query.update({'browse': '1', 'page': '1', 'limit': '48'})
            li = g['_new_listitem']('[COLOR FFE50914]EXPANDIR[/COLOR]')
            li.setProperty('AcTweeteR.Expand', '1')
            plugin.addDirectoryItem(handle, build(query), li, True)
        elif has_more and get('browse') == '1':
            query = {key: values[0] for key, values in params.items() if values}
            query['page'] = str(page + 1)
            plugin.addDirectoryItem(handle, build(query),
                                    g['_new_listitem']('Más títulos'), True)
        _performance_call(g, 'kodi.end_directory', plugin.endOfDirectory, handle, cacheToDisc=False)
        return
    if view in ('favorites', 'pending') and stype == 'both':
        if view == 'pending':
            plugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
            return
        favorites = g['_get_profile_fav'](pnum).get_favorites()
        plugin.setContent(handle, 'videos')
        rows = []
        for kind in ('movie', 'series'):
            ids = {str(f.get('id')) for f in favorites if f.get('stype') == kind}
            if not ids:
                continue
            items, credentials = catalog(g, kind, pnum)
            series_context = prepare_series_state_context(g, pnum) if kind == 'series' else None
            rows.extend((kind, item, credentials, series_context)
                        for item in items if provider_id(item, kind) in ids)
        limit = min(48, max(1, number(get('limit', 24))))
        if get('actweeter_expand') == '1':
            limit = min(19, limit)
        page = max(1, number(get('page', 1)))
        offset = (page - 1) * limit
        selected = rows[offset:offset + limit]
        for kind, item, credentials, series_context in selected:
            add_provider_item(g, item, kind, credentials, pnum, budget,
                              series_context=series_context)
        if len(rows) > offset + len(selected) and get('actweeter_expand') == '1':
            query = {key: values[0] for key, values in params.items() if values}
            query.pop('actweeter_expand', None)
            query.update({'browse': '1', 'page': '1', 'limit': '48'})
            li = g['_new_listitem']('[COLOR FFE50914]EXPANDIR[/COLOR]')
            li.setProperty('AcTweeteR.Expand', '1')
            plugin.addDirectoryItem(handle, build(query), li, True)
        elif len(rows) > offset + len(selected) and get('browse') == '1':
            query = {key: values[0] for key, values in params.items() if values}
            query['page'] = str(page + 1)
            plugin.addDirectoryItem(handle, build(query),
                                    g['_new_listitem']('Más títulos'), True)
        plugin.addSortMethod(handle, plugin.SORT_METHOD_NONE)
        _performance_call(g, 'kodi.end_directory', plugin.endOfDirectory, handle, cacheToDisc=False)
        return
    if stype not in ('movie', 'series'):
        plugin.endOfDirectory(handle, succeeded=False)
        return
    indexed = (indexed_movie_page(g, pnum, view, get) if stype == 'movie'
               else indexed_series_page(g, pnum, view, get))
    if indexed is None:
        items, credentials = catalog(g, stype, pnum)
        has_more = False
    else:
        items, has_more, credentials = indexed
    if view == 'play':
        item = next((s for s in items if provider_id(s, stype) == get('id')), None)
        if not item or stype != 'movie':
            plugin.setResolvedUrl(handle, False, g['_new_listitem'](''))
            return
        data = metadata(g, item, stype, credentials)
        url = g['IPTV'].build_xtream_stream_url(*credentials, item, 'movie')
        g['play_stream'](url, item['name'], title=data['title'], plot=data.get('plot', ''),
                         icon=data.get('poster_url', ''), stype='movie', profile_num=pnum,
                         tmdb_id=data.get('tmdb_id', ''), year=data.get('year', ''),
                         video_ids={key: value for key, value in {
                             'tmdb': data.get('tmdb_id'), 'imdb': data.get('imdb_id')
                         }.items() if value})
        return
    pending_module = g.get('pending_adapter')
    pending = (pending_module.PendingAdapter(g['_get_profile_fav'](pnum))
               if pending_module is not None else None)
    if indexed is None and view == 'favorites':
        favorites = g['_get_profile_fav'](pnum).get_favorites(stype)
        ids = {str(f.get('id')) for f in favorites if f.get('stype') == stype}
        items = [s for s in items if provider_id(s, stype) in ids]
    elif indexed is None and view == 'pending':
        if pending is None:
            plugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
            return
        ids = {str(row.get('id')) for row in pending.list_items(stype)}
        items = [s for s in items if provider_id(s, stype) in ids]
    elif indexed is None and view == 'series_recent' and stype == 'series':
        events = g['series_changes'].recent(g['addon'], pnum, 50)
        by_id = {provider_id(item, stype):item for item in items}
        ordered = []
        for event in events:
            item = by_id.get(str(event.get('series_id')))
            if item:
                ordered.append(item)
        items = ordered
    elif indexed is None and view in ('trending', 'popular'):
        full_provider_catalog_count = len(items)
        items = ranked_provider_items(g, items, stype, view, fast=fast_widget)
    elif indexed is None and view == 'recent':
        # Series last_modified is NOT an addition date. No invented recency.
        items = [s for s in items if number(s.get('added')) > 0]
        items.sort(key=lambda s: number(s.get('added')), reverse=True)
    elif indexed is None and view in ('year', 'premiere'):
        year = str(premiere_year(get('offset'))) if view == 'premiere' else get('year')
        items = [s for s in items if str(s.get('year') or '') == year]
        if view == 'premiere':
            plugin.setPluginCategory(handle, 'Estrenos ' + year)
    elif indexed is None and view == 'genre':
        genre = get('genre').casefold()
        items = [s for s in items if genre and genre in str(s.get('genre') or '').casefold()]
    if indexed is None and get('cat_id'):
        items = [s for s in items if str(s.get('category_id')) == get('cat_id')]
    if indexed is None and get('id'):
        items = [s for s in items if provider_id(s, stype) == get('id')]
    if indexed is None and view in ('favorites', 'pending'):
        # Xtream may expose duplicate catalog rows for the same provider ID.
        # A collection has one saved membership per typed ID, so render one
        # poster per ID on BOTH expanded (browse=1) and widget routes.
        seen_collection_ids = set()
        unique_collection_items = []
        for item in items:
            sid = provider_id(item, stype)
            if sid not in seen_collection_ids:
                seen_collection_ids.add(sid)
                unique_collection_items.append(item)
        items = unique_collection_items
    if indexed is None and get('browse') != '1' and not get('id'):
        # One card per exact title/year; retain the first provider edition.
        seen = set()
        unique = []
        for item in items:
            identity = (normalized(item.get('name')), str(item.get('year') or ''))
            if identity not in seen:
                seen.add(identity)
                unique.append(item)
        items = unique
    page = max(1, number(get('page', 1)))
    limit = min(19 if get('actweeter_expand') == '1' else 48, max(1, number(get('limit', 24))))
    offset = (page - 1) * limit
    if indexed is None:
        selected = items[offset:offset + limit]
        has_more = len(items) > offset + len(selected)
    else:
        selected = items
    plugin.setContent(handle, 'movies' if stype == 'movie' else 'tvshows')
    series_context = (prepare_series_state_context(g, pnum)
                      if stype == 'series' and selected else None)
    visible_items = 0
    for item in selected:
        result = add_provider_item(g, item, stype, credentials, pnum, budget,
                                   series_context=series_context, pending=pending,
                                   reconcile_pending=(view == 'pending'))
        # False means Pending was positively completed and removed.
        if result is not False:
            visible_items += 1
    if view in ('favorites', 'pending') and not visible_items and page == 1:
        # Native Kodi directory entry, not an overlay dependent on NumItems=0.
        has_members = (bool(g['_get_profile_fav'](pnum).get_favorites(stype))
                       if view == 'favorites' else
                       bool(pending and pending.list_items(stype)))
        message = ('No disponible' if has_members else
                   'Sin favoritos' if view == 'favorites' else 'Sin pendientes')
        empty_item = g['_new_listitem'](message)
        empty_item.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
        empty_item.setProperty('AcTweeteR.EmptyCollection', '1')
        plugin.addDirectoryItem(handle, build({'mode': 'premium',
            'view': 'collections_root', 'stype': stype, 'profile_num': pnum}),
            empty_item, True)
    expandable_views = {'catalog', 'recent', 'popular', 'trending', 'favorites',
                        'pending', 'continue', 'series_recent', 'year', 'premiere', 'genre'}
    ranked_has_more = (indexed is None and view in ('trending', 'popular')
                       and full_provider_catalog_count > len(items))
    if (get('actweeter_expand') == '1' and stype in ('movie', 'series')
            and view in expandable_views and (has_more or ranked_has_more)):
        query = {key: values[0] for key, values in params.items() if values}
        query.pop('actweeter_expand', None)
        query['browse'] = '1'
        query['page'] = '1'
        query['limit'] = '48'
        if ranked_has_more and not has_more:
            query['view'] = 'catalog'
        li = g['_new_listitem']('[COLOR FFE50914]EXPANDIR[/COLOR]')
        li.setProperty('AcTweeteR.Expand', '1')
        plugin.addDirectoryItem(handle, build(query), li, True)
    if get('browse') == '1' and has_more:
        q = {key:values[0] for key,values in params.items()}
        q['page'] = page + 1
        li = g['_new_listitem']('Más títulos')
        plugin.addDirectoryItem(handle, build(q), li, True)
    plugin.addSortMethod(handle, plugin.SORT_METHOD_NONE)
    _performance_call(g, 'kodi.end_directory', plugin.endOfDirectory, handle, cacheToDisc=False)


def _instrument_phase(name, function):
    def measured(g, *args, **kwargs):
        trace = g.get('_performance')
        if trace is None:
            return function(g, *args, **kwargs)
        return trace.call(name, function, g, *args, **kwargs)
    return measured


for _function_name, _phase_name in (
        ('dispatch', 'directory.dispatch'),
        ('catalog', 'provider.catalog'),
        ('ranked_provider_items', 'provider.ranking'),
        ('metadata', 'metadata.provider'),
        ('enrich', 'metadata.tmdb_enrichment'),
        ('listitem', 'listitem.build'),
        ('add_provider_item', 'listitem.complete'),
        ('prepare_series_state_context', 'storage.series_state_read')):
    globals()[_function_name] = _instrument_phase(
        _phase_name, globals()[_function_name])
