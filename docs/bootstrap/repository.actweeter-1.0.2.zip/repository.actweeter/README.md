# repository.actweeter 1.0.2

Kodi's native repository bootstrap add-on for AcTweeteR. It exposes the AcTweeteR
index and the live Omega add-on index from the original Matke BINGIE repository,
needed for the skin's declared dependencies. Kodi downloads helper ZIPs
directly from the upstream Bingie datadir. No helper binaries or metadata
snapshots are redistributed here.

The AcTweeteR index and all releases are built and published manually only after
explicit owner authorization. This build does not upload or publish anything.
See the repository changelog for the live-upstream metadata change.
